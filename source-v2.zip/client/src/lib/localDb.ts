import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import LZString from 'lz-string';
import { getTimeType, getBusinessDayRange, getBusinessDay, calculateAdditionalFee } from '@shared/businessDay';

let SQL: SqlJsStatic | null = null;
let db: Database | null = null;

const DB_NAME = 'rest_hotel_db';

// 스킨별 앱 식별자 (빌드 시 VITE_SKIN으로 결정)
const _SKIN = import.meta.env.VITE_SKIN || 'v1';
const APP_SYSTEM_NAME = _SKIN === 'v2' ? 'HIZZ Hotel Management System' : 'EQUUS Hotel Management System';
const BACKUP_PREFIX = _SKIN === 'v2' ? 'hizz' : 'equus';

// ── IndexedDB 설정 (메인 저장소: 비동기, 압축 불필요, UI 블로킹 없음) ──
const IDB_NAME = 'hotel_idb';
const IDB_VERSION = 1;
const IDB_STORE = 'database';
const IDB_KEY = 'main';

function _openIDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(IDB_NAME, IDB_VERSION);
    req.onupgradeneeded = (e) => {
      (e.target as IDBOpenDBRequest).result.createObjectStore(IDB_STORE);
    };
    req.onsuccess = (e) => resolve((e.target as IDBOpenDBRequest).result);
    req.onerror = () => reject(req.error);
  });
}

async function _saveToIDB(data: Uint8Array): Promise<void> {
  const idb = await _openIDB();
  return new Promise((resolve, reject) => {
    const tx = idb.transaction(IDB_STORE, 'readwrite');
    // slice(0): ArrayBuffer를 복사하여 Transferable로 전달
    tx.objectStore(IDB_STORE).put(data.buffer.slice(0), IDB_KEY);
    tx.oncomplete = () => { idb.close(); resolve(); };
    tx.onerror = () => { idb.close(); reject(tx.error); };
  });
}

async function _loadFromIDB(): Promise<Uint8Array | null> {
  try {
    const idb = await _openIDB();
    return new Promise((resolve) => {
      const tx = idb.transaction(IDB_STORE, 'readonly');
      const req = tx.objectStore(IDB_STORE).get(IDB_KEY);
      req.onsuccess = () => {
        idb.close();
        resolve(req.result ? new Uint8Array(req.result as ArrayBuffer) : null);
      };
      req.onerror = () => { idb.close(); resolve(null); };
    });
  } catch {
    return null;
  }
}

// ── localStorage 동기 저장 (beforeunload 안전망 전용) ──
function _saveDatabaseToLocalStorage(data: Uint8Array) {
  const chunkSize = 65535;
  let binary = '';
  for (let i = 0; i < data.length; i += chunkSize) {
    const chunk = data.subarray(i, i + chunkSize);
    binary += String.fromCharCode.apply(null, Array.from(chunk));
  }
  const base64 = btoa(binary);
  const compressed = LZString.compressToUTF16(base64);
  try {
    localStorage.setItem(DB_NAME, compressed);
  } catch {
    try { localStorage.setItem(DB_NAME, base64); } catch {}
  }
}

// Initialize SQL.js and load database
export async function initDatabase(): Promise<Database> {
  if (db) return db;

  if (!SQL) {
    SQL = await initSqlJs({
      locateFile: (file: string) => `/${file}`
    });
  }

  // 1순위: IndexedDB (비동기 저장소, 기존 데이터가 있으면 우선 사용)
  const idbData = await _loadFromIDB();
  if (idbData && idbData.length > 0) {
    db = new SQL.Database(idbData);
    migrateDatabase();
    return db;
  }

  // 2순위: localStorage (기존 사용자 자동 마이그레이션)
  const savedDb = localStorage.getItem(DB_NAME);
  if (savedDb) {
    let base64: string;
    try {
      const decompressed = LZString.decompressFromUTF16(savedDb);
      base64 = decompressed || savedDb;
    } catch {
      base64 = savedDb;
    }
    const buf = Uint8Array.from(atob(base64), c => c.charCodeAt(0));
    db = new SQL.Database(buf);
    migrateDatabase(); // 마이그레이션 끝에 saveDatabase() 호출 → IndexedDB에 저장됨
    return db;
  }

  // 신규 DB
  db = new SQL.Database();
  createTables();
  return db;
}

// ── Debounced save (고빈도 쓰기 코일레센스) ──
let _saveDebouncedTimer: ReturnType<typeof setTimeout> | null = null;
function saveDatabaseDebounced() {
  if (_saveDebouncedTimer) clearTimeout(_saveDebouncedTimer);
  _saveDebouncedTimer = setTimeout(() => {
    saveDatabase();
    _saveDebouncedTimer = null;
  }, 500);
}

// 페이지 닫힐 때: pending 저장을 동기 localStorage로 즉시 flush (안전망)
if (typeof window !== 'undefined') {
  window.addEventListener('beforeunload', () => {
    if (_saveDebouncedTimer) {
      clearTimeout(_saveDebouncedTimer);
      _saveDebouncedTimer = null;
    }
    // IndexedDB는 비동기라 beforeunload에서 완료 보장 불가 → localStorage 동기 저장
    if (db) {
      _saveDatabaseToLocalStorage(db.export());
    }
  });
}

// ── saveDatabase: IndexedDB에 비동기 저장 (메인 스레드 블로킹 없음) ──
export function saveDatabase() {
  if (!db) return;
  const data = db.export();
  _saveToIDB(data).catch(err => {
    // IndexedDB 실패 시(사생활 보호 모드 등) localStorage로 폴백
    console.warn('[DB] IndexedDB save failed, falling back to localStorage:', err);
    _saveDatabaseToLocalStorage(data);
  });
}

// Migrate existing database schema
function migrateDatabase() {
  if (!db) return;
  
  try {
    // Step 1: Ensure all tables exist first (before any ALTER operations)
    db.run(`
      CREATE TABLE IF NOT EXISTS system_metadata (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    `);
    
    db.run(`
      CREATE TABLE IF NOT EXISTS locker_groups (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        start_number INTEGER NOT NULL,
        end_number INTEGER NOT NULL,
        sort_order INTEGER NOT NULL DEFAULT 0
      )
    `);
    
    db.run(`
      CREATE TABLE IF NOT EXISTS locker_daily_summaries (
        business_day TEXT PRIMARY KEY,
        total_visitors INTEGER NOT NULL DEFAULT 0,
        total_sales INTEGER NOT NULL DEFAULT 0,
        cancellations INTEGER NOT NULL DEFAULT 0,
        total_discount INTEGER NOT NULL DEFAULT 0,
        foreigner_count INTEGER NOT NULL DEFAULT 0,
        foreigner_sales INTEGER NOT NULL DEFAULT 0,
        day_visitors INTEGER NOT NULL DEFAULT 0,
        night_visitors INTEGER NOT NULL DEFAULT 0
      )
    `);
    
    // Step 2: Migrate locker_logs table if needed
    const result = db.exec(`SELECT sql FROM sqlite_master WHERE type='table' AND name='locker_logs'`);
    
    if (result.length > 0 && result[0].values.length > 0) {
      const createSql = result[0].values[0][0] as string;
      
      // Check if 'direct_price', 'transfer', 'customer_memo', and 'free' are already in the CHECK constraints
      const needsMigration = !createSql.includes('direct_price') || !createSql.includes('transfer') || !createSql.includes('customer_memo') || !createSql.includes("'free'");
      
      if (needsMigration) {
        console.log('Migrating locker_logs table to add direct_price option and transfer payment method...');
        
        try {
          // Create backup table
          db.run(`CREATE TABLE locker_logs_backup AS SELECT * FROM locker_logs`);
          
          // Drop old table
          db.run(`DROP TABLE locker_logs`);
          
          // Create new table with updated CHECK constraints
          db.run(`
            CREATE TABLE locker_logs (
              id TEXT PRIMARY KEY,
              locker_number INTEGER NOT NULL,
              entry_time TEXT NOT NULL,
              exit_time TEXT,
              business_day TEXT NOT NULL,
              time_type TEXT NOT NULL CHECK(time_type IN ('주간', '야간')),
              base_price INTEGER NOT NULL,
              option_type TEXT NOT NULL CHECK(option_type IN ('none', 'discount', 'custom', 'foreigner', 'direct_price', 'free')),
              option_amount INTEGER,
              final_price INTEGER NOT NULL,
              status TEXT NOT NULL CHECK(status IN ('in_use', 'checked_out', 'cancelled')),
              cancelled INTEGER NOT NULL DEFAULT 0,
              notes TEXT,
              payment_method TEXT CHECK(payment_method IN ('card', 'cash', 'transfer')),
              payment_cash INTEGER,
              payment_card INTEGER,
              payment_transfer INTEGER,
              rental_items TEXT,
              additional_fees INTEGER DEFAULT 0,
              additional_fee_paid INTEGER DEFAULT 0,
              additional_fee_paid_amount INTEGER DEFAULT 0,
              parent_locker INTEGER,
              deferred_payment INTEGER DEFAULT 0,
              customer_memo TEXT
            )
          `);
          
          // Copy data back (explicitly map columns to handle schema changes)
          db.run(`INSERT INTO locker_logs (id, locker_number, entry_time, exit_time, business_day, time_type, base_price, option_type, option_amount, final_price, status, cancelled, notes, payment_method, payment_cash, payment_card, payment_transfer, rental_items, additional_fees, additional_fee_paid, additional_fee_paid_amount, parent_locker, deferred_payment, customer_memo) 
            SELECT id, locker_number, entry_time, exit_time, business_day, time_type, base_price, option_type, option_amount, final_price, status, cancelled, notes, payment_method, 
              COALESCE(payment_cash, 0), COALESCE(payment_card, 0), COALESCE(payment_transfer, 0), rental_items, COALESCE(additional_fees, 0), 0, 0, parent_locker, COALESCE(deferred_payment, 0), customer_memo 
            FROM locker_logs_backup`);
          
          // Drop backup table
          db.run(`DROP TABLE locker_logs_backup`);
          
          console.log('Migration completed successfully!');
          saveDatabase();
        } catch (migrationError) {
          console.error('Locker logs migration failed:', migrationError);
          // Try to restore from backup if it exists
          try {
            db.run(`DROP TABLE IF EXISTS locker_logs`);
            db.run(`ALTER TABLE locker_logs_backup RENAME TO locker_logs`);
            console.log('Rollback successful');
          } catch (rollbackError) {
            console.error('Rollback failed:', rollbackError);
          }
          throw migrationError;
        }
      }
    }
    
    // Step 3: Add missing columns to daily summaries (safe now that table exists)
    try {
      db.run(`ALTER TABLE locker_daily_summaries ADD COLUMN day_visitors INTEGER NOT NULL DEFAULT 0`);
    } catch (e) {
      // Column already exists, ignore
    }
    try {
      db.run(`ALTER TABLE locker_daily_summaries ADD COLUMN night_visitors INTEGER NOT NULL DEFAULT 0`);
    } catch (e) {
      // Column already exists, ignore
    }
    
    // Step 4: Add rental_items column to locker_logs (for tracking blanket/towel rentals)
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN rental_items TEXT`);
      console.log('Added rental_items column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }
    
    // Step 4.5: Add mixed payment columns to all tables
    // locker_logs
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN payment_cash INTEGER`);
      console.log('Added payment_cash column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN payment_card INTEGER`);
      console.log('Added payment_card column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN payment_transfer INTEGER`);
      console.log('Added payment_transfer column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }
    
    // Step 4.6: Add additional_fees column to locker_logs (for tracking overtime fees on same business day)
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN additional_fees INTEGER DEFAULT 0`);
      console.log('Added additional_fees column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }
    
    // Step 4.6.1: Add additional_fee_paid column to locker_logs (for tracking if additional fee was paid before checkout)
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN additional_fee_paid INTEGER DEFAULT 0`);
      console.log('Added additional_fee_paid column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }
    
    // Step 4.6.2: Add additional_fee_paid_amount column to locker_logs (cumulative paid amount for tracking new accruals)
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN additional_fee_paid_amount INTEGER DEFAULT 0`);
      console.log('Added additional_fee_paid_amount column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }
    
    // additional_fee_events
    try {
      db.run(`ALTER TABLE additional_fee_events ADD COLUMN payment_cash INTEGER`);
    } catch (e) {}
    try {
      db.run(`ALTER TABLE additional_fee_events ADD COLUMN payment_card INTEGER`);
    } catch (e) {}
    try {
      db.run(`ALTER TABLE additional_fee_events ADD COLUMN payment_transfer INTEGER`);
    } catch (e) {}
    
    // rental_transactions
    try {
      db.run(`ALTER TABLE rental_transactions ADD COLUMN payment_cash INTEGER`);
    } catch (e) {}
    try {
      db.run(`ALTER TABLE rental_transactions ADD COLUMN payment_card INTEGER`);
    } catch (e) {}
    try {
      db.run(`ALTER TABLE rental_transactions ADD COLUMN payment_transfer INTEGER`);
    } catch (e) {}
    try {
      db.run(`ALTER TABLE rental_transactions ADD COLUMN return_completed INTEGER DEFAULT 0`);
      console.log('Added return_completed column to rental_transactions');
    } catch (e) {}
    
    // expenses
    try {
      db.run(`ALTER TABLE expenses ADD COLUMN payment_cash INTEGER`);
    } catch (e) {}
    try {
      db.run(`ALTER TABLE expenses ADD COLUMN payment_card INTEGER`);
    } catch (e) {}
    try {
      db.run(`ALTER TABLE expenses ADD COLUMN payment_transfer INTEGER`);
    } catch (e) {}
    
    // Step 4.6: Backfill existing records with mixed payment data based on legacy payment_method
    console.log('[Migration] Backfilling mixed payment columns for existing records...');
    
    // Backfill locker_logs
    try {
      db.run(`
        UPDATE locker_logs
        SET payment_cash = CASE 
              WHEN payment_method = 'cash' THEN final_price 
              WHEN payment_method IS NULL AND final_price > 0 THEN final_price
              ELSE NULL 
            END,
            payment_card = CASE WHEN payment_method = 'card' THEN final_price ELSE NULL END,
            payment_transfer = CASE WHEN payment_method = 'transfer' THEN final_price ELSE NULL END
        WHERE payment_cash IS NULL AND payment_card IS NULL AND payment_transfer IS NULL
      `);
      console.log('[Migration] Backfilled locker_logs');
    } catch (e) {
      console.error('[Migration] Failed to backfill locker_logs:', e);
    }
    
    // Backfill additional_fee_events
    try {
      db.run(`
        UPDATE additional_fee_events
        SET payment_cash = CASE 
              WHEN payment_method = 'cash' THEN fee_amount 
              WHEN payment_method IS NULL AND fee_amount > 0 THEN fee_amount
              ELSE NULL 
            END,
            payment_card = CASE WHEN payment_method = 'card' THEN fee_amount ELSE NULL END,
            payment_transfer = CASE WHEN payment_method = 'transfer' THEN fee_amount ELSE NULL END
        WHERE payment_cash IS NULL AND payment_card IS NULL AND payment_transfer IS NULL
      `);
      console.log('[Migration] Backfilled additional_fee_events');
    } catch (e) {
      console.error('[Migration] Failed to backfill additional_fee_events:', e);
    }
    
    // Backfill rental_transactions
    try {
      db.run(`
        UPDATE rental_transactions
        SET payment_cash = CASE 
              WHEN payment_method = 'cash' THEN revenue 
              WHEN payment_method IS NULL AND revenue > 0 THEN revenue
              ELSE NULL 
            END,
            payment_card = CASE WHEN payment_method = 'card' THEN revenue ELSE NULL END,
            payment_transfer = CASE WHEN payment_method = 'transfer' THEN revenue ELSE NULL END
        WHERE payment_cash IS NULL AND payment_card IS NULL AND payment_transfer IS NULL
      `);
      console.log('[Migration] Backfilled rental_transactions');
    } catch (e) {
      console.error('[Migration] Failed to backfill rental_transactions:', e);
    }
    
    // Backfill expenses
    try {
      db.run(`
        UPDATE expenses
        SET payment_cash = CASE 
              WHEN payment_method = 'cash' THEN amount 
              WHEN payment_method IS NULL AND amount > 0 THEN amount
              ELSE NULL 
            END,
            payment_card = CASE WHEN payment_method = 'card' THEN amount ELSE NULL END,
            payment_transfer = CASE WHEN payment_method = 'transfer' THEN amount ELSE NULL END
        WHERE payment_cash IS NULL AND payment_card IS NULL AND payment_transfer IS NULL
      `);
      console.log('[Migration] Backfilled expenses');
    } catch (e) {
      console.error('[Migration] Failed to backfill expenses:', e);
    }
    
    console.log('[Migration] Backfill complete');
    
    // Step 4.65: Normalize all timestamps to ISO-8601 UTC format
    console.log('[Migration] Normalizing all timestamps to ISO-8601 UTC format...');
    
    try {
      // Check if migration has already been run
      const migrationCheck = db.exec(`SELECT value FROM system_metadata WHERE key = 'timestamp_normalized'`);
      const alreadyNormalized = migrationCheck.length > 0 && migrationCheck[0].values.length > 0;
      
      if (!alreadyNormalized) {
        // Normalize locker_logs timestamps
        db.run(`
          UPDATE locker_logs
          SET entry_time = strftime('%Y-%m-%dT%H:%M:%S.000Z', datetime(entry_time))
          WHERE entry_time NOT LIKE '%T%'
        `);
        
        db.run(`
          UPDATE locker_logs
          SET exit_time = strftime('%Y-%m-%dT%H:%M:%S.000Z', datetime(exit_time))
          WHERE exit_time IS NOT NULL AND exit_time NOT LIKE '%T%'
        `);
        
        console.log('[Migration] Normalized locker_logs timestamps');
        
        // Normalize additional_fee_events timestamps
        db.run(`
          UPDATE additional_fee_events
          SET checkout_time = strftime('%Y-%m-%dT%H:%M:%S.000Z', datetime(checkout_time))
          WHERE checkout_time NOT LIKE '%T%'
        `);
        
        db.run(`
          UPDATE additional_fee_events
          SET created_at = strftime('%Y-%m-%dT%H:%M:%S.000Z', datetime(created_at))
          WHERE created_at IS NOT NULL AND created_at NOT LIKE '%T%'
        `);
        
        console.log('[Migration] Normalized additional_fee_events timestamps');
        
        // Normalize rental_transactions timestamps
        db.run(`
          UPDATE rental_transactions
          SET rental_time = strftime('%Y-%m-%dT%H:%M:%S.000Z', datetime(rental_time))
          WHERE rental_time NOT LIKE '%T%'
        `);
        
        db.run(`
          UPDATE rental_transactions
          SET return_time = strftime('%Y-%m-%dT%H:%M:%S.000Z', datetime(return_time))
          WHERE return_time IS NOT NULL AND return_time NOT LIKE '%T%'
        `);
        
        console.log('[Migration] Normalized rental_transactions timestamps');
        
        // Normalize expenses timestamps
        db.run(`
          UPDATE expenses
          SET created_at = strftime('%Y-%m-%dT%H:%M:%S.000Z', datetime(created_at))
          WHERE created_at IS NOT NULL AND created_at NOT LIKE '%T%'
        `);
        
        console.log('[Migration] Normalized expenses timestamps');
        
        // Normalize closing_days timestamps
        db.run(`
          UPDATE closing_days
          SET start_time = strftime('%Y-%m-%dT%H:%M:%S.000Z', datetime(start_time))
          WHERE start_time NOT LIKE '%T%'
        `);
        
        db.run(`
          UPDATE closing_days
          SET end_time = strftime('%Y-%m-%dT%H:%M:%S.000Z', datetime(end_time))
          WHERE end_time NOT LIKE '%T%'
        `);
        
        db.run(`
          UPDATE closing_days
          SET created_at = strftime('%Y-%m-%dT%H:%M:%S.000Z', datetime(created_at))
          WHERE created_at IS NOT NULL AND created_at NOT LIKE '%T%'
        `);
        
        db.run(`
          UPDATE closing_days
          SET updated_at = strftime('%Y-%m-%dT%H:%M:%S.000Z', datetime(updated_at))
          WHERE updated_at IS NOT NULL AND updated_at NOT LIKE '%T%'
        `);
        
        db.run(`
          UPDATE closing_days
          SET confirmed_at = strftime('%Y-%m-%dT%H:%M:%S.000Z', datetime(confirmed_at))
          WHERE confirmed_at IS NOT NULL AND confirmed_at NOT LIKE '%T%'
        `);
        
        console.log('[Migration] Normalized closing_days timestamps');
        
        // Mark migration as complete
        db.run(`
          INSERT OR REPLACE INTO system_metadata (key, value)
          VALUES ('timestamp_normalized', 'true')
        `);
        
        console.log('[Migration] Timestamp normalization complete - all timestamps now in ISO-8601 UTC format');
        saveDatabase();
      } else {
        console.log('[Migration] Timestamp normalization already completed, skipping');
      }
    } catch (e) {
      console.error('[Migration] Failed to normalize timestamps:', e);
    }
    
    // Step 4.7: Add discount fields to additional_fee_events
    try {
      db.run(`ALTER TABLE additional_fee_events ADD COLUMN original_fee_amount INTEGER`);
      console.log('Added original_fee_amount column to additional_fee_events');
    } catch (e) {
      // Column already exists, ignore
    }
    try {
      db.run(`ALTER TABLE additional_fee_events ADD COLUMN discount_amount INTEGER DEFAULT 0`);
      console.log('Added discount_amount column to additional_fee_events');
    } catch (e) {
      // Column already exists, ignore
    }
    
    // Step 5: Create additional_fee_events table (Stage 1 migration)
    db.run(`
      CREATE TABLE IF NOT EXISTS additional_fee_events (
        id TEXT PRIMARY KEY,
        locker_log_id TEXT NOT NULL,
        locker_number INTEGER NOT NULL,
        checkout_time TEXT NOT NULL,
        fee_amount INTEGER NOT NULL,
        original_fee_amount INTEGER,
        discount_amount INTEGER DEFAULT 0,
        business_day TEXT NOT NULL,
        payment_method TEXT NOT NULL CHECK(payment_method IN ('card', 'cash', 'transfer')),
        payment_cash INTEGER,
        payment_card INTEGER,
        payment_transfer INTEGER,
        created_at TEXT NOT NULL
      )
    `);
    
    // Step 6: Create additional_revenue_items table (rental items)
    db.run(`
      CREATE TABLE IF NOT EXISTS additional_revenue_items (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        rental_fee INTEGER NOT NULL DEFAULT 0,
        deposit_amount INTEGER NOT NULL DEFAULT 0,
        billing_type TEXT NOT NULL DEFAULT 'rental' CHECK(billing_type IN ('rental', 'simple')),
        sort_order INTEGER NOT NULL DEFAULT 0,
        is_default INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    `);
    
    // Add billing_type column if it doesn't exist (migration for existing tables)
    try {
      db.run(`ALTER TABLE additional_revenue_items ADD COLUMN billing_type TEXT NOT NULL DEFAULT 'rental' CHECK(billing_type IN ('rental', 'simple'))`);
      console.log('Added billing_type column to additional_revenue_items');
    } catch (e) {
      // Column already exists, ignore
    }
    
    // Step 7: Migrate rental_transactions table (one-time migration)
    // Check if migration has already been done
    const migrationCheck = db.exec(`
      SELECT name FROM sqlite_master 
      WHERE type='table' AND name='rental_transactions'
    `);
    
    if (migrationCheck.length > 0) {
      // Table exists, check if it has the new schema
      const schemaCheck = db.exec(`PRAGMA table_info(rental_transactions)`);
      const columns = schemaCheck.length > 0 && schemaCheck[0].values ? schemaCheck[0].values : [];
      const hasRevenueColumn = columns.some((row: any) => row[1] === 'revenue');
      
      // Check if return_time is nullable (notnull = 0 means nullable, notnull = 1 means NOT NULL)
      const returnTimeInfo = columns.find((row: any) => row[1] === 'return_time');
      const isReturnTimeNullable = returnTimeInfo ? returnTimeInfo[3] === 0 : false; // row[3] is the 'notnull' field
      
      // Check if deposit_status CHECK constraint includes 'none'
      const tableCheck = db.exec(`SELECT sql FROM sqlite_master WHERE type='table' AND name='rental_transactions'`);
      const tableSql = tableCheck.length > 0 && tableCheck[0].values.length > 0 ? tableCheck[0].values[0][0] as string : '';
      const hasNoneDepositStatus = tableSql.includes("'none'");
      
      console.log('[Migration] rental_transactions check:', { 
        hasRevenueColumn, 
        isReturnTimeNullable,
        hasNoneDepositStatus,
        returnTimeInfo: returnTimeInfo ? `notnull=${returnTimeInfo[3]}` : 'not found'
      });
      
      // Need migration if missing revenue column OR return_time is not nullable OR missing 'none' deposit status
      if (!hasRevenueColumn || !isReturnTimeNullable || !hasNoneDepositStatus) {
        console.log('[Migration] Starting rental_transactions migration...');
        // Old schema detected, need to migrate
        // Since SQLite doesn't support easy column rename/restructure, we need to:
        // 1. Rename old table
        // 2. Create new table
        // 3. Copy data (if any)
        // 4. Drop old table
        
        db.run('ALTER TABLE rental_transactions RENAME TO rental_transactions_old');
        
        db.run(`
          CREATE TABLE rental_transactions (
            id TEXT PRIMARY KEY,
            locker_log_id TEXT NOT NULL,
            item_id TEXT NOT NULL,
            item_name TEXT NOT NULL,
            locker_number INTEGER NOT NULL,
            rental_time TEXT NOT NULL,
            return_time TEXT,
            business_day TEXT NOT NULL,
            rental_fee INTEGER NOT NULL,
            deposit_amount INTEGER NOT NULL,
            payment_method TEXT NOT NULL CHECK(payment_method IN ('card', 'cash', 'transfer')),
            deposit_status TEXT NOT NULL CHECK(deposit_status IN ('received', 'refunded', 'forfeited', 'none')),
            revenue INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
          )
        `);
        
        // Try to migrate existing data (best effort)
        // Old schema had: id, locker_log_id, item_id, locker_number, rental_date, rental_time, 
        //                 rental_fee, deposit_amount, payment_method, deposit_status, deposit_revenue
        // New schema needs: id, locker_log_id, item_id, item_name, locker_number, rental_time, return_time,
        //                   business_day, rental_fee, deposit_amount, payment_method, deposit_status, revenue
        let migrationSuccess = false;
        try {
          db.run(`
            INSERT INTO rental_transactions 
            (id, locker_log_id, item_id, item_name, locker_number, rental_time, return_time, 
             business_day, rental_fee, deposit_amount, payment_method, deposit_status, revenue, created_at, updated_at)
            SELECT 
              id, 
              locker_log_id, 
              item_id,
              '',  -- item_name didn't exist in old schema, use empty string
              locker_number,
              rental_time,  -- rental_time existed in old schema
              rental_date,  -- Use rental_date as return_time (best guess)
              rental_date,  -- Use rental_date as business_day
              rental_fee,
              deposit_amount,
              payment_method,
              deposit_status,
              rental_fee + CASE 
                WHEN deposit_status IN ('received', 'forfeited') THEN deposit_amount 
                ELSE 0 
              END,  -- Calculate revenue from rental_fee and deposit_status
              created_at,
              updated_at
            FROM rental_transactions_old
          `);
          migrationSuccess = true;
        } catch (e) {
          console.error('Failed to migrate rental transaction data. Old table will be kept as rental_transactions_old for manual recovery:', e);
          // Don't drop the old table - keep it as rental_transactions_old for manual recovery
        }
        
        // Only drop the old table if migration was successful
        if (migrationSuccess) {
          db.run('DROP TABLE rental_transactions_old');
          console.log('[Migration] rental_transactions migration completed successfully');
        } else {
          console.warn('[Migration] rental_transactions migration failed - old table preserved as rental_transactions_old');
        }
      } else {
        console.log('[Migration] rental_transactions schema is up-to-date');
      }
    } else {
      console.log('[Migration] rental_transactions table does not exist, creating new...');
      // Table doesn't exist, create it with new schema
      db.run(`
        CREATE TABLE rental_transactions (
          id TEXT PRIMARY KEY,
          locker_log_id TEXT NOT NULL,
          item_id TEXT NOT NULL,
          item_name TEXT NOT NULL,
          locker_number INTEGER NOT NULL,
          rental_time TEXT NOT NULL,
          return_time TEXT,
          business_day TEXT NOT NULL,
          rental_fee INTEGER NOT NULL,
          deposit_amount INTEGER NOT NULL,
          payment_method TEXT NOT NULL CHECK(payment_method IN ('card', 'cash', 'transfer')),
          deposit_status TEXT NOT NULL CHECK(deposit_status IN ('received', 'refunded', 'forfeited', 'none')),
          revenue INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        )
      `);
    }
    
    // Step 8: No default rental items - user will add their own items in settings
    
    // Step 9: Create expense_categories table if not exists
    db.run(`
      CREATE TABLE IF NOT EXISTS expense_categories (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        is_default INTEGER NOT NULL DEFAULT 0,
        sort_order INTEGER NOT NULL DEFAULT 999,
        created_at TEXT NOT NULL
      )
    `);
    
    // Step 9.5: Initialize default expense categories if not exist
    const expenseCategoryCountResult = db.exec(`SELECT COUNT(*) FROM expense_categories`);
    const categoryCount = expenseCategoryCountResult.length > 0 && expenseCategoryCountResult[0].values.length > 0 ? expenseCategoryCountResult[0].values[0][0] : 0;
    
    if (categoryCount === 0) {
      console.log('Initializing default expense categories...');
      const now = new Date().toISOString();
      const defaultCategories = [
        { name: '인건비', sortOrder: 0 },
        { name: '공과금', sortOrder: 1 },
        { name: '식자재', sortOrder: 2 },
        { name: '소모품', sortOrder: 3 },
        { name: '수리비', sortOrder: 4 },
        { name: '통신비', sortOrder: 5 },
        { name: '보증금환급', sortOrder: 6 },
        { name: '기타', sortOrder: 999 }
      ];
      
      for (const category of defaultCategories) {
        const id = crypto.randomUUID();
        db.run(`
          INSERT INTO expense_categories (id, name, is_default, sort_order, created_at)
          VALUES (?, ?, 1, ?, ?)
        `, [id, category.name, category.sortOrder, now]);
      }
      
      console.log('Default expense categories created');
      saveDatabase();
    }
    
    // Step 10: Create expenses table if not exists
    db.run(`
      CREATE TABLE IF NOT EXISTS expenses (
        id TEXT PRIMARY KEY,
        date TEXT NOT NULL,
        time TEXT NOT NULL,
        category TEXT NOT NULL,
        amount INTEGER NOT NULL,
        quantity INTEGER DEFAULT 1,
        payment_method TEXT NOT NULL CHECK(payment_method IN ('card', 'cash', 'transfer')),
        business_day TEXT NOT NULL,
        notes TEXT,
        created_at TEXT NOT NULL
      )
    `);
    
    // Step 11: Create closing_days table if not exists
    db.run(`
      CREATE TABLE IF NOT EXISTS closing_days (
        id TEXT PRIMARY KEY,
        business_day TEXT NOT NULL UNIQUE,
        start_time TEXT NOT NULL,
        end_time TEXT NOT NULL,
        opening_float INTEGER NOT NULL,
        target_float INTEGER NOT NULL,
        actual_cash INTEGER,
        expected_cash INTEGER,
        discrepancy INTEGER DEFAULT 0,
        bank_deposit INTEGER,
        notes TEXT,
        is_confirmed INTEGER NOT NULL DEFAULT 0,
        confirmed_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    `);
    
    // Step 11: Add memo column to closing_days table for daily notes
    try {
      db.run(`ALTER TABLE closing_days ADD COLUMN memo TEXT`);
      console.log('Added memo column to closing_days');
    } catch (e) {
      // Column already exists, ignore
    }
    
    // Step 12: Add parent_locker column to locker_logs for locker linking
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN parent_locker INTEGER`);
      console.log('Added parent_locker column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }
    
    // Step 13: Create barcode_mappings table if not exists
    db.run(`
      CREATE TABLE IF NOT EXISTS barcode_mappings (
        id TEXT PRIMARY KEY,
        barcode TEXT NOT NULL UNIQUE,
        locker_number INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    `);
    
    // Step 14: Create scan_logs table for tracking all barcode scans
    db.run(`
      CREATE TABLE IF NOT EXISTS scan_logs (
        id TEXT PRIMARY KEY,
        locker_number INTEGER NOT NULL,
        scan_time TEXT NOT NULL,
        business_day TEXT NOT NULL,
        processed INTEGER NOT NULL DEFAULT 0
      )
    `);
    
    // Step 15: Create rfid_mappings table for RFID tag mappings
    db.run(`
      CREATE TABLE IF NOT EXISTS rfid_mappings (
        id TEXT PRIMARY KEY,
        rfid_uid TEXT NOT NULL UNIQUE,
        locker_number INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    `);
    
    // Step 16: Add deferred_payment column to locker_logs (후불결제 여부)
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN deferred_payment INTEGER DEFAULT 0`);
      console.log('Added deferred_payment column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }
    
    // Step 17: Add customer_memo column to locker_logs (손님 메모)
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN customer_memo TEXT`);
      console.log('Added customer_memo column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }
    
    // Step 18: Clean up invalid daily summaries with NULL or empty business_day
    try {
      const invalidResult = db.exec(`SELECT COUNT(*) FROM locker_daily_summaries WHERE business_day IS NULL OR business_day = ''`);
      const invalidCount = invalidResult.length > 0 ? invalidResult[0].values[0][0] : 0;
      if (invalidCount && Number(invalidCount) > 0) {
        db.run(`DELETE FROM locker_daily_summaries WHERE business_day IS NULL OR business_day = ''`);
        console.log(`Cleaned up ${invalidCount} invalid daily summary records with NULL business_day`);
      }
    } catch (e) {
      console.error('Failed to cleanup invalid daily summaries:', e);
    }
    
    // Step 19: Create pricing_options table for customizable pricing options
    db.run(`
      CREATE TABLE IF NOT EXISTS pricing_options (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        option_type TEXT NOT NULL CHECK(option_type IN ('discount', 'surcharge', 'fixed')),
        amount INTEGER NOT NULL,
        sort_order INTEGER NOT NULL DEFAULT 0,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    `);
    
    // Step 20: Add no_additional_fee column to locker_logs (무료입장 손님 추가요금 면제)
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN no_additional_fee INTEGER DEFAULT 0`);
      console.log('Added no_additional_fee column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }
    
    // Step 21: Add prepaid_additional_fee column to locker_logs (추가요금 선지급)
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN prepaid_additional_fee INTEGER DEFAULT 0`);
      console.log('Added prepaid_additional_fee column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }
    
    // Step 22: Add is_cash_receipt column to locker_logs (현금영수증 발행 여부)
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN is_cash_receipt INTEGER DEFAULT 0`);
      console.log('Added is_cash_receipt column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }
    
    // Step 23: Add additional_fee_payment_method column to locker_logs (추가요금 결제방식)
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN additional_fee_payment_method TEXT CHECK(additional_fee_payment_method IN ('card', 'cash', 'transfer'))`);
      console.log('Added additional_fee_payment_method column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }

    // Step 24: Add refund columns to locker_logs (환불 처리)
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN refund_amount INTEGER DEFAULT 0`);
      console.log('Added refund_amount column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN refund_note TEXT`);
      console.log('Added refund_note column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN refund_time TEXT`);
      console.log('Added refund_time column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }

    // Step 25: Add refund_method column to locker_logs (환불 결제수단)
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN refund_method TEXT DEFAULT 'cash'`);
      console.log('Added refund_method column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }

    // Step 26: Add is_outing column to locker_logs (외출 중 여부)
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN is_outing INTEGER DEFAULT 0`);
      console.log('Added is_outing column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }

    // Step 27: Add is_staff column to locker_logs (직원 입실 여부)
    try {
      db.run(`ALTER TABLE locker_logs ADD COLUMN is_staff INTEGER DEFAULT 0`);
      console.log('Added is_staff column to locker_logs');
    } catch (e) {
      // Column already exists, ignore
    }

    // Step 28: Create performance indexes (IF NOT EXISTS → 기존 DB에도 안전하게 적용)
    // 쿼리 속도 최적화: 기존 DB에 인덱스가 없으면 매 쿼리마다 전체 테이블 스캔 발생
    try {
      db.run(`CREATE INDEX IF NOT EXISTS idx_locker_logs_status ON locker_logs(status)`);
      db.run(`CREATE INDEX IF NOT EXISTS idx_locker_logs_business_day ON locker_logs(business_day)`);
      db.run(`CREATE INDEX IF NOT EXISTS idx_locker_logs_entry_time ON locker_logs(entry_time)`);
      db.run(`CREATE INDEX IF NOT EXISTS idx_locker_logs_locker_number ON locker_logs(locker_number)`);
      db.run(`CREATE INDEX IF NOT EXISTS idx_scan_logs_business_day ON scan_logs(business_day)`);
      db.run(`CREATE INDEX IF NOT EXISTS idx_scan_logs_scan_time ON scan_logs(scan_time)`);
      db.run(`CREATE INDEX IF NOT EXISTS idx_additional_fee_events_business_day ON additional_fee_events(business_day)`);
      db.run(`CREATE INDEX IF NOT EXISTS idx_rental_transactions_business_day ON rental_transactions(business_day)`);
      console.log('Created performance indexes (Step 28)');
    } catch (e) {
      // Ignore errors (table may not exist yet)
    }

    // Step 28 후처리: VACUUM으로 DB 크기 축소 후 즉시 저장
    // 최초 1회만 실행 (매 시작마다 VACUUM 방지 → localStorage 플래그 사용)
    const vacuumDone = localStorage.getItem('db_vacuum_step28');
    if (!vacuumDone) {
      try {
        db.run('VACUUM');
        localStorage.setItem('db_vacuum_step28', '1');
        console.log('VACUUM completed after Step 28 migration (one-time)');
      } catch (e) {
        // VACUUM 실패해도 계속 진행
      }
    }
    saveDatabase();

    // Step 29: 직원관리 테이블 추가 (staff, staff_work_logs, staff_ratings)
    try {
      db.run(`CREATE TABLE IF NOT EXISTS staff (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        phone TEXT DEFAULT '',
        address TEXT DEFAULT '',
        hire_date TEXT DEFAULT '',
        hourly_pay INTEGER DEFAULT 0,
        part_time_hours REAL DEFAULT 0,
        pin TEXT DEFAULT '',
        is_active INTEGER DEFAULT 1,
        notes TEXT DEFAULT '',
        created_at TEXT DEFAULT ''
      )`);
      db.run(`CREATE TABLE IF NOT EXISTS staff_work_logs (
        id TEXT PRIMARY KEY,
        staff_id TEXT NOT NULL,
        work_date TEXT NOT NULL,
        start_time TEXT DEFAULT '',
        end_time TEXT DEFAULT '',
        break_minutes INTEGER DEFAULT 0,
        work_minutes INTEGER DEFAULT 0,
        daily_pay INTEGER DEFAULT 0,
        notes TEXT DEFAULT '',
        created_at TEXT DEFAULT '',
        updated_at TEXT DEFAULT ''
      )`);
      db.run(`CREATE TABLE IF NOT EXISTS staff_ratings (
        id TEXT PRIMARY KEY,
        staff_id TEXT NOT NULL,
        rating_date TEXT NOT NULL,
        rating TEXT NOT NULL,
        note TEXT DEFAULT '',
        created_at TEXT DEFAULT ''
      )`);
      console.log('Created staff management tables (Step 29)');
    } catch (e) {
      // 이미 존재하면 무시
    }

    // Step 30: 직원 사진 및 합의 근무시간 컬럼 추가
    try {
      db.run(`ALTER TABLE staff ADD COLUMN photo TEXT DEFAULT ''`);
      console.log('Added photo column to staff (Step 30)');
    } catch (e) { /* 이미 존재하면 무시 */ }
    try {
      db.run(`ALTER TABLE staff_work_logs ADD COLUMN agreed_start_time TEXT DEFAULT ''`);
      console.log('Added agreed_start_time column to staff_work_logs (Step 30)');
    } catch (e) { /* 이미 존재하면 무시 */ }
    try {
      db.run(`ALTER TABLE staff_work_logs ADD COLUMN agreed_end_time TEXT DEFAULT ''`);
      console.log('Added agreed_end_time column to staff_work_logs (Step 30)');
    } catch (e) { /* 이미 존재하면 무시 */ }

    // Step 31: 근무구간 페이타입 및 직접입력 금액 컬럼 추가
    try {
      db.run(`ALTER TABLE staff_work_logs ADD COLUMN pay_type TEXT DEFAULT '주간'`);
      console.log('Added pay_type column to staff_work_logs (Step 31)');
    } catch (e) { /* 이미 존재하면 무시 */ }
    try {
      db.run(`ALTER TABLE staff_work_logs ADD COLUMN segment_pay INTEGER DEFAULT 0`);
      console.log('Added segment_pay column to staff_work_logs (Step 31)');
    } catch (e) { /* 이미 존재하면 무시 */ }

    // Step 32: 시간당 페이 컬럼 추가 (총액 역산 없이 원래 입력값 보존)
    try {
      db.run(`ALTER TABLE staff_work_logs ADD COLUMN hourly_rate INTEGER DEFAULT 0`);
      console.log('Added hourly_rate column to staff_work_logs (Step 32)');
    } catch (e) { /* 이미 존재하면 무시 */ }

    saveDatabase();

  } catch (error) {
    console.error('Migration error:', error);
    throw error;
  }
}

// Create all tables
function createTables() {
  if (!db) return;

  // Locker logs table
  db.run(`
    CREATE TABLE IF NOT EXISTS locker_logs (
      id TEXT PRIMARY KEY,
      locker_number INTEGER NOT NULL,
      entry_time TEXT NOT NULL,
      exit_time TEXT,
      business_day TEXT NOT NULL,
      time_type TEXT NOT NULL CHECK(time_type IN ('주간', '야간')),
      base_price INTEGER NOT NULL,
      option_type TEXT NOT NULL CHECK(option_type IN ('none', 'discount', 'custom', 'foreigner', 'direct_price', 'free')),
      option_amount INTEGER,
      final_price INTEGER NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('in_use', 'checked_out', 'cancelled')),
      cancelled INTEGER NOT NULL DEFAULT 0,
      notes TEXT,
      payment_method TEXT CHECK(payment_method IN ('card', 'cash', 'transfer')),
      payment_cash INTEGER,
      payment_card INTEGER,
      payment_transfer INTEGER,
      rental_items TEXT,
      additional_fees INTEGER DEFAULT 0,
      additional_fee_paid INTEGER DEFAULT 0,
      additional_fee_paid_amount INTEGER DEFAULT 0,
      parent_locker INTEGER,
      deferred_payment INTEGER DEFAULT 0,
      customer_memo TEXT,
      no_additional_fee INTEGER DEFAULT 0,
      prepaid_additional_fee INTEGER DEFAULT 0,
      is_cash_receipt INTEGER DEFAULT 0,
      additional_fee_payment_method TEXT CHECK(additional_fee_payment_method IN ('card', 'cash', 'transfer')),
      refund_amount INTEGER DEFAULT 0,
      refund_note TEXT,
      refund_time TEXT,
      refund_method TEXT DEFAULT 'cash',
      is_outing INTEGER DEFAULT 0,
      is_staff INTEGER DEFAULT 0
    )
  `);

  // Daily summaries table
  db.run(`
    CREATE TABLE IF NOT EXISTS locker_daily_summaries (
      business_day TEXT PRIMARY KEY,
      total_visitors INTEGER NOT NULL DEFAULT 0,
      total_sales INTEGER NOT NULL DEFAULT 0,
      cancellations INTEGER NOT NULL DEFAULT 0,
      total_discount INTEGER NOT NULL DEFAULT 0,
      foreigner_count INTEGER NOT NULL DEFAULT 0,
      foreigner_sales INTEGER NOT NULL DEFAULT 0,
      day_visitors INTEGER NOT NULL DEFAULT 0,
      night_visitors INTEGER NOT NULL DEFAULT 0
    )
  `);

  // Locker groups table
  db.run(`
    CREATE TABLE IF NOT EXISTS locker_groups (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      start_number INTEGER NOT NULL,
      end_number INTEGER NOT NULL,
      sort_order INTEGER NOT NULL DEFAULT 0
    )
  `);

  // System metadata table
  db.run(`
    CREATE TABLE IF NOT EXISTS system_metadata (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    )
  `);

  // Additional fee events table (Stage 1: fees recorded at checkout)
  db.run(`
    CREATE TABLE IF NOT EXISTS additional_fee_events (
      id TEXT PRIMARY KEY,
      locker_log_id TEXT NOT NULL,
      locker_number INTEGER NOT NULL,
      checkout_time TEXT NOT NULL,
      fee_amount INTEGER NOT NULL,
      original_fee_amount INTEGER,
      discount_amount INTEGER DEFAULT 0,
      business_day TEXT NOT NULL,
      payment_method TEXT NOT NULL CHECK(payment_method IN ('card', 'cash', 'transfer')),
      payment_cash INTEGER,
      payment_card INTEGER,
      payment_transfer INTEGER,
      created_at TEXT NOT NULL
    )
  `);

  // Additional revenue items table (rental items: 롱타올, 담요 등)
  db.run(`
    CREATE TABLE IF NOT EXISTS additional_revenue_items (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      rental_fee INTEGER NOT NULL DEFAULT 0,
      deposit_amount INTEGER NOT NULL DEFAULT 0,
      billing_type TEXT NOT NULL DEFAULT 'rental' CHECK(billing_type IN ('rental', 'simple')),
      sort_order INTEGER NOT NULL DEFAULT 0,
      is_default INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
  `);

  // Rental transactions table (대여 거래 기록)
  db.run(`
    CREATE TABLE IF NOT EXISTS rental_transactions (
      id TEXT PRIMARY KEY,
      locker_log_id TEXT NOT NULL,
      item_id TEXT NOT NULL,
      item_name TEXT NOT NULL,
      locker_number INTEGER NOT NULL,
      rental_time TEXT NOT NULL,
      return_time TEXT,
      business_day TEXT NOT NULL,
      rental_fee INTEGER NOT NULL,
      deposit_amount INTEGER NOT NULL,
      payment_method TEXT NOT NULL CHECK(payment_method IN ('card', 'cash', 'transfer')),
      payment_cash INTEGER,
      payment_card INTEGER,
      payment_transfer INTEGER,
      deposit_status TEXT NOT NULL CHECK(deposit_status IN ('received', 'refunded', 'forfeited', 'none')),
      revenue INTEGER NOT NULL DEFAULT 0,
      return_completed INTEGER DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
  `);

  // Expenses table (지출 기록)
  db.run(`
    CREATE TABLE IF NOT EXISTS expenses (
      id TEXT PRIMARY KEY,
      date TEXT NOT NULL,
      time TEXT NOT NULL,
      category TEXT NOT NULL,
      amount INTEGER NOT NULL,
      quantity INTEGER DEFAULT 1,
      payment_method TEXT NOT NULL CHECK(payment_method IN ('card', 'cash', 'transfer')),
      payment_cash INTEGER,
      payment_card INTEGER,
      payment_transfer INTEGER,
      business_day TEXT NOT NULL,
      notes TEXT,
      created_at TEXT NOT NULL
    )
  `);

  // Closing days table (정산 기록)
  db.run(`
    CREATE TABLE IF NOT EXISTS closing_days (
      id TEXT PRIMARY KEY,
      business_day TEXT NOT NULL UNIQUE,
      start_time TEXT NOT NULL,
      end_time TEXT NOT NULL,
      opening_float INTEGER NOT NULL,
      target_float INTEGER NOT NULL,
      actual_cash INTEGER,
      expected_cash INTEGER,
      discrepancy INTEGER DEFAULT 0,
      bank_deposit INTEGER,
      notes TEXT,
      is_confirmed INTEGER NOT NULL DEFAULT 0,
      confirmed_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
  `);

  // Barcode mappings table (바코드 매핑: 락카키 바코드 ↔ 락카번호)
  db.run(`
    CREATE TABLE IF NOT EXISTS barcode_mappings (
      id TEXT PRIMARY KEY,
      barcode TEXT NOT NULL UNIQUE,
      locker_number INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
  `);

  // RFID mappings table (RFID 매핑: 락카키 RFID ↔ 락카번호)
  db.run(`
    CREATE TABLE IF NOT EXISTS rfid_mappings (
      id TEXT PRIMARY KEY,
      rfid_uid TEXT NOT NULL UNIQUE,
      locker_number INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
  `);

  // Scan logs table (바코드/RFID 스캔 기록 추적)
  db.run(`
    CREATE TABLE IF NOT EXISTS scan_logs (
      id TEXT PRIMARY KEY,
      locker_number INTEGER NOT NULL,
      scan_time TEXT NOT NULL,
      business_day TEXT NOT NULL,
      processed INTEGER NOT NULL DEFAULT 0
    )
  `);

  // Pricing options table (요금옵션: 할인/할증/지정)
  db.run(`
    CREATE TABLE IF NOT EXISTS pricing_options (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      option_type TEXT NOT NULL CHECK(option_type IN ('discount', 'surcharge', 'fixed')),
      amount INTEGER NOT NULL,
      sort_order INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
  `);

  // Staff management tables (직원관리)
  db.run(`CREATE TABLE IF NOT EXISTS staff (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    phone TEXT DEFAULT '',
    address TEXT DEFAULT '',
    hire_date TEXT DEFAULT '',
    hourly_pay INTEGER DEFAULT 0,
    part_time_hours REAL DEFAULT 0,
    pin TEXT DEFAULT '',
    is_active INTEGER DEFAULT 1,
    notes TEXT DEFAULT '',
    created_at TEXT DEFAULT '',
    photo TEXT DEFAULT ''
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS staff_work_logs (
    id TEXT PRIMARY KEY,
    staff_id TEXT NOT NULL,
    work_date TEXT NOT NULL,
    start_time TEXT DEFAULT '',
    end_time TEXT DEFAULT '',
    break_minutes INTEGER DEFAULT 0,
    work_minutes INTEGER DEFAULT 0,
    daily_pay INTEGER DEFAULT 0,
    notes TEXT DEFAULT '',
    created_at TEXT DEFAULT '',
    updated_at TEXT DEFAULT '',
    agreed_start_time TEXT DEFAULT '',
    agreed_end_time TEXT DEFAULT ''
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS staff_ratings (
    id TEXT PRIMARY KEY,
    staff_id TEXT NOT NULL,
    rating_date TEXT NOT NULL,
    rating TEXT NOT NULL,
    note TEXT DEFAULT '',
    created_at TEXT DEFAULT ''
  )`);

  // 성능 인덱스: 자주 사용되는 쿼리 최적화
  db.run(`CREATE INDEX IF NOT EXISTS idx_locker_logs_status ON locker_logs(status)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_locker_logs_business_day ON locker_logs(business_day)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_locker_logs_entry_time ON locker_logs(entry_time)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_locker_logs_locker_number ON locker_logs(locker_number)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_scan_logs_business_day ON scan_logs(business_day)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_scan_logs_scan_time ON scan_logs(scan_time)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_additional_fee_events_business_day ON additional_fee_events(business_day)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_rental_transactions_business_day ON rental_transactions(business_day)`);

  saveDatabase();
}

// Force database regeneration (drops all tables and recreates them)
export function forceRegenerateDatabase() {
  if (!db) {
    console.error('Database not initialized');
    return false;
  }
  
  try {
    console.log('[Force Regenerate] Starting database regeneration...');
    
    // Drop all existing tables
    const tables = ['locker_logs', 'locker_daily_summaries', 'locker_groups', 
                   'system_metadata', 'additional_fee_events', 'additional_revenue_items', 
                   'rental_transactions', 'expenses', 'closing_days', 'barcode_mappings', 
                   'rfid_mappings', 'scan_logs', 'pricing_options'];
    
    tables.forEach(table => {
      try {
        db!.run(`DROP TABLE IF EXISTS ${table}`);
        console.log(`[Force Regenerate] Dropped table: ${table}`);
      } catch (e) {
        console.error(`[Force Regenerate] Failed to drop table ${table}:`, e);
      }
    });
    
    // Recreate all tables with correct schema
    createTables();
    
    // No default rental items - user will add their own items in settings
    
    // VACUUM: 삭제된 페이지 공간 회수 → saveDatabase() 크기/속도 정상화
    db!.run('VACUUM');
    console.log('[Force Regenerate] Database regeneration completed successfully');
    saveDatabase();
    return true;
  } catch (error) {
    console.error('[Force Regenerate] Error during database regeneration:', error);
    return false;
  }
}

// Generate UUID
function generateId(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// Entry operations
// entryTime: 옵션창이 열린 시간 (스캔 시간). 지정하지 않으면 현재 시간 사용
export function createEntry(entry: {
  lockerNumber: number;
  timeType: string;
  basePrice: number;
  finalPrice: number;
  businessDay: string;
  optionType: string;
  optionAmount?: number;
  notes?: string;
  paymentMethod?: string;
  paymentCash?: number;
  paymentCard?: number;
  paymentTransfer?: number;
  rentalItems?: string[];
  entryTime?: Date;  // 입실시간 (옵션창 열린 시간으로 기록, 미지정 시 현재시간)
  deferredPayment?: boolean;  // 후불결제 여부
  customerMemo?: string;  // 손님 메모
  noAdditionalFee?: boolean;  // 추가요금없음 (VIP 등)
  prepaidAdditionalFee?: number;  // 추가요금 선지급 금액
  isCashReceipt?: boolean;  // 현금영수증 발행 여부
  additionalFeePaymentMethod?: string;  // 추가요금 결제방식
  isStaff?: boolean;  // 직원 입실 여부
}): string {
  if (!db) throw new Error('Database not initialized');

  const id = generateId();
  // 입실시간: 지정된 시간(옵션창 열린 시간) 또는 현재 시간
  const entryTimeISO = entry.entryTime ? entry.entryTime.toISOString() : new Date().toISOString();
  const rentalItemsJson = entry.rentalItems && entry.rentalItems.length > 0 
    ? JSON.stringify(entry.rentalItems) 
    : null;

  db.run(
    `INSERT INTO locker_logs 
    (id, locker_number, entry_time, business_day, time_type, base_price, 
     option_type, option_amount, final_price, status, cancelled, notes, payment_method, 
     payment_cash, payment_card, payment_transfer, rental_items, deferred_payment, customer_memo, no_additional_fee, prepaid_additional_fee, is_cash_receipt, additional_fee_payment_method, is_staff)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'in_use', 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      id,
      entry.lockerNumber,
      entryTimeISO,
      entry.businessDay,
      entry.timeType,
      entry.basePrice,
      entry.optionType,
      entry.optionAmount || null,
      entry.finalPrice,
      entry.notes || null,
      entry.paymentMethod || null,
      entry.paymentCash || null,
      entry.paymentCard || null,
      entry.paymentTransfer || null,
      rentalItemsJson,
      entry.deferredPayment ? 1 : 0,
      entry.customerMemo || null,
      entry.noAdditionalFee ? 1 : 0,
      entry.prepaidAdditionalFee || 0,
      entry.isCashReceipt ? 1 : 0,
      entry.additionalFeePaymentMethod || null,
      entry.isStaff ? 1 : 0
    ]
  );

  // Update daily summary
  updateDailySummary(entry.businessDay);
  saveDatabaseDebounced();
  
  return id;
}

export function updateEntry(id: string, updates: any) {
  if (!db) throw new Error('Database not initialized');

  const sets: string[] = [];
  const values: any[] = [];

  if (updates.optionType !== undefined) {
    sets.push('option_type = ?');
    values.push(updates.optionType);
  }
  if (updates.optionAmount !== undefined) {
    sets.push('option_amount = ?');
    values.push(updates.optionAmount);
  }
  if (updates.finalPrice !== undefined) {
    sets.push('final_price = ?');
    values.push(updates.finalPrice);
  }
  if (updates.notes !== undefined) {
    sets.push('notes = ?');
    values.push(updates.notes);
  }
  if (updates.paymentMethod !== undefined) {
    sets.push('payment_method = ?');
    values.push(updates.paymentMethod);
  }
  if (updates.paymentCash !== undefined) {
    sets.push('payment_cash = ?');
    values.push(updates.paymentCash);
  }
  if (updates.paymentCard !== undefined) {
    sets.push('payment_card = ?');
    values.push(updates.paymentCard);
  }
  if (updates.paymentTransfer !== undefined) {
    sets.push('payment_transfer = ?');
    values.push(updates.paymentTransfer);
  }
  if (updates.status !== undefined) {
    sets.push('status = ?');
    values.push(updates.status);
  }
  if (updates.exitTime !== undefined) {
    sets.push('exit_time = ?');
    values.push(new Date(updates.exitTime).toISOString());
  }
  if (updates.cancelled !== undefined) {
    sets.push('cancelled = ?');
    values.push(updates.cancelled ? 1 : 0);
  }
  if (updates.rentalItems !== undefined) {
    sets.push('rental_items = ?');
    const rentalItemsJson = updates.rentalItems && updates.rentalItems.length > 0
      ? JSON.stringify(updates.rentalItems)
      : null;
    values.push(rentalItemsJson);
  }
  if (updates.additionalFees !== undefined) {
    sets.push('additional_fees = ?');
    values.push(updates.additionalFees);
  }
  if (updates.deferredPayment !== undefined) {
    sets.push('deferred_payment = ?');
    values.push(updates.deferredPayment ? 1 : 0);
  }
  if (updates.customerMemo !== undefined) {
    sets.push('customer_memo = ?');
    values.push(updates.customerMemo || null);
  }
  if (updates.noAdditionalFee !== undefined) {
    sets.push('no_additional_fee = ?');
    values.push(updates.noAdditionalFee ? 1 : 0);
  }
  if (updates.prepaidAdditionalFee !== undefined) {
    sets.push('prepaid_additional_fee = ?');
    values.push(updates.prepaidAdditionalFee || 0);
  }
  if (updates.isCashReceipt !== undefined) {
    sets.push('is_cash_receipt = ?');
    values.push(updates.isCashReceipt ? 1 : 0);
  }
  if (updates.additionalFeePaymentMethod !== undefined) {
    sets.push('additional_fee_payment_method = ?');
    values.push(updates.additionalFeePaymentMethod || null);
  }
  if (updates.isStaff !== undefined) {
    sets.push('is_staff = ?');
    values.push(updates.isStaff ? 1 : 0);
  }
  if (updates.refundAmount !== undefined) {
    sets.push('refund_amount = ?');
    values.push(updates.refundAmount || 0);
  }
  if (updates.refundNote !== undefined) {
    sets.push('refund_note = ?');
    values.push(updates.refundNote || null);
  }
  if (updates.refundTime !== undefined) {
    sets.push('refund_time = ?');
    values.push(updates.refundTime || null);
  }
  if (updates.refundMethod !== undefined) {
    sets.push('refund_method = ?');
    values.push(updates.refundMethod || 'cash');
  }
  if (updates.isOuting !== undefined) {
    sets.push('is_outing = ?');
    values.push(updates.isOuting ? 1 : 0);
  }

  if (sets.length > 0) {
    values.push(id);
    db.run(
      `UPDATE locker_logs SET ${sets.join(', ')} WHERE id = ?`,
      values
    );

    // Get business day for this entry and update summary
    const result = db.exec('SELECT business_day FROM locker_logs WHERE id = ?', [id]);
    if (result.length > 0 && result[0].values.length > 0) {
      const businessDay = result[0].values[0][0] as string;
      updateDailySummary(businessDay);
    }

    saveDatabaseDebounced();
  }
}

// 퇴실 취소 (퇴실 처리된 락카를 다시 사용 중 상태로 복구)
export function reverseCheckout(logId: string): { success: boolean; message: string; deletedAdditionalFee?: number } {
  if (!db) throw new Error('Database not initialized');
  
  try {
    // 1. 해당 로그 조회
    const result = db.exec(
      `SELECT * FROM locker_logs WHERE id = ?`,
      [logId]
    );
    
    if (result.length === 0 || result[0].values.length === 0) {
      return { success: false, message: '해당 기록을 찾을 수 없습니다.' };
    }
    
    const columns = result[0].columns;
    const row = result[0].values[0];
    const logData: any = {};
    columns.forEach((col, idx) => {
      logData[col] = row[idx];
    });
    
    // 2. 이미 체크아웃된 상태인지 확인
    if (logData.status !== 'checked_out') {
      return { success: false, message: '이미 사용 중인 락카입니다.' };
    }
    
    const lockerNumber = logData.locker_number;
    const businessDay = logData.business_day;
    
    // 3. 해당 락카에 이미 다른 손님이 입실했는지 확인
    const newEntryResult = db.exec(
      `SELECT id FROM locker_logs 
       WHERE locker_number = ? AND status = 'in_use'`,
      [lockerNumber]
    );
    
    if (newEntryResult.length > 0 && newEntryResult[0].values.length > 0) {
      return { success: false, message: '해당 락카에 새로운 손님이 이미 입실했습니다.' };
    }
    
    // 4. 추가요금 이벤트 조회 및 삭제 (퇴실 시 기록된 추가요금)
    // 추가요금은 퇴실 시점의 영업일에 기록되므로 해당 영업일도 업데이트 필요
    let deletedAdditionalFee = 0;
    let additionalFeeBusinessDay: string | null = null;
    
    const additionalFeeResult = db.exec(
      `SELECT fee_amount, business_day FROM additional_fee_events WHERE locker_log_id = ?`,
      [logId]
    );
    
    if (additionalFeeResult.length > 0 && additionalFeeResult[0].values.length > 0) {
      deletedAdditionalFee = additionalFeeResult[0].values[0][0] as number;
      additionalFeeBusinessDay = additionalFeeResult[0].values[0][1] as string;
      db.run(`DELETE FROM additional_fee_events WHERE locker_log_id = ?`, [logId]);
    }
    
    // 4-1. 퇴실 취소 시 자동입력된 추가요금 할인 메모 삭제
    // (락카 교체/묶기 메모는 보존)
    let updatedCustomerMemo = logData.customer_memo || '';
    if (updatedCustomerMemo) {
      const lines = updatedCustomerMemo.split('\n');
      updatedCustomerMemo = lines
        .filter((line: string) => {
          const hasAdditionalFee = line.includes('추가요금');
          const hasFullDiscount = line.includes('전액할인');
          const hasPartialDiscount = line.includes('할인 받음');
          
          // 추가요금 할인 메모면 제거 (전액할인 또는 일부할인)
          if (hasAdditionalFee && (hasFullDiscount || hasPartialDiscount)) {
            return false;
          }
          return true;
        })
        .join('\n')
        .replace(/\n\n+/g, '\n')
        .trim();
    }
    
    // 5. 상태를 in_use로 변경하고 exit_time을 null로 설정
    // CRITICAL FIX: 같은 영업일 추가요금의 경우, finalPrice에서 추가요금을 차감해야 함
    // (같은 영업일 퇴실 시 finalPrice에 추가요금이 포함되어 있음)
    const isSameDayAdditionalFee = deletedAdditionalFee > 0 && additionalFeeBusinessDay === businessDay;
    
    if (isSameDayAdditionalFee) {
      // 같은 영업일: finalPrice에서 추가요금 차감
      const currentFinalPrice = logData.final_price as number;
      const revertedFinalPrice = currentFinalPrice - deletedAdditionalFee;
      db.run(
        `UPDATE locker_logs 
         SET status = 'in_use', exit_time = NULL, final_price = ?, customer_memo = ?
         WHERE id = ?`,
        [revertedFinalPrice, updatedCustomerMemo || null, logId]
      );
    } else {
      // 다른 영업일 또는 추가요금 없음: finalPrice 유지
      db.run(
        `UPDATE locker_logs 
         SET status = 'in_use', exit_time = NULL, customer_memo = ?
         WHERE id = ?`,
        [updatedCustomerMemo || null, logId]
      );
    }
    
    // 6. 일일 요약 업데이트 (입실 영업일)
    updateDailySummary(businessDay);
    
    // 7. 추가요금이 있었다면 퇴실 영업일 요약도 업데이트 (입실/퇴실 영업일이 다른 경우)
    if (additionalFeeBusinessDay && additionalFeeBusinessDay !== businessDay) {
      updateDailySummary(additionalFeeBusinessDay);
    }
    
    saveDatabaseDebounced();
    
    return { 
      success: true, 
      message: `${lockerNumber}번 락카의 퇴실이 취소되었습니다.`,
      deletedAdditionalFee
    };
    
  } catch (error) {
    console.error('퇴실 취소 오류:', error);
    return { success: false, message: '퇴실 취소 중 오류가 발생했습니다.' };
  }
}

// 후불결제 완료 처리 (deferredPayment를 false로 변경)
export function completeDeferredPayment(logId: string, paymentInfo?: {
  paymentMethod?: string;
  paymentCash?: number;
  paymentCard?: number;
  paymentTransfer?: number;
}): { success: boolean; message: string } {
  if (!db) throw new Error('Database not initialized');
  
  try {
    // 1. 해당 로그 조회
    const result = db.exec(
      `SELECT * FROM locker_logs WHERE id = ?`,
      [logId]
    );
    
    if (result.length === 0 || result[0].values.length === 0) {
      return { success: false, message: '해당 기록을 찾을 수 없습니다.' };
    }
    
    const columns = result[0].columns;
    const row = result[0].values[0];
    const logData: any = {};
    columns.forEach((col, idx) => {
      logData[col] = row[idx];
    });
    
    // 2. 후불결제 상태인지 확인
    if (!logData.deferred_payment) {
      return { success: false, message: '후불결제 상태가 아닙니다.' };
    }
    
    // 3. 후불결제 해제 및 결제 정보 업데이트
    let updateQuery = `UPDATE locker_logs SET deferred_payment = 0`;
    const params: any[] = [];
    
    if (paymentInfo?.paymentMethod) {
      updateQuery += `, payment_method = ?`;
      params.push(paymentInfo.paymentMethod);
    }
    if (paymentInfo?.paymentCash !== undefined) {
      updateQuery += `, payment_cash = ?`;
      params.push(paymentInfo.paymentCash);
    }
    if (paymentInfo?.paymentCard !== undefined) {
      updateQuery += `, payment_card = ?`;
      params.push(paymentInfo.paymentCard);
    }
    if (paymentInfo?.paymentTransfer !== undefined) {
      updateQuery += `, payment_transfer = ?`;
      params.push(paymentInfo.paymentTransfer);
    }
    
    updateQuery += ` WHERE id = ?`;
    params.push(logId);
    
    db.run(updateQuery, params);
    
    // 4. 일일 요약 업데이트
    const businessDay = logData.business_day;
    updateDailySummary(businessDay);
    saveDatabaseDebounced();
    
    return { 
      success: true, 
      message: `${logData.locker_number}번 락카의 결제가 완료되었습니다.`
    };
    
  } catch (error) {
    console.error('결제 완료 처리 오류:', error);
    return { success: false, message: '결제 완료 처리 중 오류가 발생했습니다.' };
  }
}

export function swapLockers(fromLockerNumber: number, toLockerNumber: number): { success: boolean; message: string; type: 'move' | 'swap' | 'error' } {
  if (!db) throw new Error('Database not initialized');

  // 유효성 검사
  if (fromLockerNumber === toLockerNumber) {
    return { success: false, message: '같은 락카 번호입니다.', type: 'error' };
  }

  // 설정된 락카 그룹 번호만 허용
  const groupResult = db.exec('SELECT start_number, end_number FROM locker_groups');
  const configuredNumbers = new Set<number>();
  if (groupResult.length > 0) {
    groupResult[0].values.forEach((row: any) => {
      const start = row[0] as number;
      const end = row[1] as number;
      for (let i = start; i <= end; i++) configuredNumbers.add(i);
    });
  }
  if (!configuredNumbers.has(fromLockerNumber) || !configuredNumbers.has(toLockerNumber)) {
    return { success: false, message: '유효하지 않은 락카 번호입니다.', type: 'error' };
  }

  try {
    // Begin transaction
    db.run('BEGIN TRANSACTION');
    // 두 락카의 현재 상태 확인
    const fromResult = db.exec(
      `SELECT * FROM locker_logs WHERE locker_number = ? AND status = 'in_use'`,
      [fromLockerNumber]
    );
    
    const toResult = db.exec(
      `SELECT * FROM locker_logs WHERE locker_number = ? AND status = 'in_use'`,
      [toLockerNumber]
    );

    const fromInUse = fromResult.length > 0 && fromResult[0].values.length > 0;
    const toInUse = toResult.length > 0 && toResult[0].values.length > 0;

    if (!fromInUse) {
      db.run('ROLLBACK');
      return { success: false, message: `${fromLockerNumber}번 락카가 사용 중이 아닙니다.`, type: 'error' };
    }

    // 안전한 임시 번호 계산 (현재 사용 중인 최대 락카 번호 + 10000)
    const tempNumber = 10000 + fromLockerNumber;

    if (!toInUse) {
      // 시나리오 1: 이동 (from만 사용중, to는 비어있음)
      
      // 1. locker_logs 업데이트
      db.run(
        `UPDATE locker_logs SET locker_number = ? WHERE locker_number = ? AND status = 'in_use'`,
        [toLockerNumber, fromLockerNumber]
      );
      const changes1 = db.exec('SELECT changes() as count')[0]?.values[0]?.[0];
      if (changes1 !== 1) {
        db.run('ROLLBACK');
        return { success: false, message: 'locker_logs 업데이트 실패', type: 'error' };
      }

      // 2. 자식 락카들의 parentLocker 업데이트 (부모 락카가 이동하면 자식들도 따라감)
      db.run(
        `UPDATE locker_logs SET parent_locker = ? 
         WHERE parent_locker = ? AND status = 'in_use'`,
        [toLockerNumber, fromLockerNumber]
      );

      // 3. rental_transactions 업데이트
      db.run(
        `UPDATE rental_transactions SET locker_number = ? 
         WHERE locker_number = ? AND return_time IS NULL`,
        [toLockerNumber, fromLockerNumber]
      );
      // rental_transactions는 0개 이상일 수 있으므로 검증 안함

      // 4. additional_fee_events 업데이트 (해당 locker_log_id에 연결된 것만)
      const fromData = rowsToObjects(fromResult[0])[0];
      if (fromData && fromData.id) {
        db.run(
          `UPDATE additional_fee_events SET locker_number = ? 
           WHERE locker_log_id = ?`,
          [toLockerNumber, fromData.id]
        );
        // additional_fee_events도 0개 이상일 수 있으므로 검증 안함
      }

      // Add note about the move to the customer's customer_memo (메모 아이콘으로만 표시됨)
      const timestamp = new Date().toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' });
      const moveNote = `[${timestamp}] 락카이동: ${fromLockerNumber}번 → ${toLockerNumber}번`;
      const existingMemo = fromData?.customerMemo || '';
      const updatedMemo = existingMemo ? `${existingMemo}\n${moveNote}` : moveNote;
      
      db.run(
        `UPDATE locker_logs SET customer_memo = ? WHERE locker_number = ? AND status = 'in_use'`,
        [updatedMemo, toLockerNumber]
      );

      // Commit transaction
      db.run('COMMIT');
      
      // 영업일 요약 업데이트
      if (fromData && fromData.business_day) {
        updateDailySummary(fromData.business_day);
      }

      saveDatabaseDebounced();
      return { 
        success: true, 
        message: `${fromLockerNumber}번 락카의 내용이 ${toLockerNumber}번 락카로 이동되었습니다.`, 
        type: 'move' 
      };
    } else {
      // 시나리오 2: 교환 (둘 다 사용중)
      
      const fromData = rowsToObjects(fromResult[0])[0];
      const toData = rowsToObjects(toResult[0])[0];

      // 1. locker_logs 교환
      db.run(
        `UPDATE locker_logs SET locker_number = ? WHERE locker_number = ? AND status = 'in_use'`,
        [tempNumber, fromLockerNumber]
      );
      const swap1 = db.exec('SELECT changes() as count')[0]?.values[0]?.[0];
      if (swap1 !== 1) {
        db.run('ROLLBACK');
        return { success: false, message: 'locker_logs 교환 실패 (step 1)', type: 'error' };
      }
      
      db.run(
        `UPDATE locker_logs SET locker_number = ? WHERE locker_number = ? AND status = 'in_use'`,
        [fromLockerNumber, toLockerNumber]
      );
      const swap2 = db.exec('SELECT changes() as count')[0]?.values[0]?.[0];
      if (swap2 !== 1) {
        db.run('ROLLBACK');
        return { success: false, message: 'locker_logs 교환 실패 (step 2)', type: 'error' };
      }
      
      db.run(
        `UPDATE locker_logs SET locker_number = ? WHERE locker_number = ? AND status = 'in_use'`,
        [toLockerNumber, tempNumber]
      );
      const swap3 = db.exec('SELECT changes() as count')[0]?.values[0]?.[0];
      if (swap3 !== 1) {
        db.run('ROLLBACK');
        return { success: false, message: 'locker_logs 교환 실패 (step 3)', type: 'error' };
      }

      // 2. 자식 락카들의 parentLocker 교환 (부모 락카가 교환되면 자식들도 따라감)
      // 임시 번호를 사용하여 3-way swap
      db.run(
        `UPDATE locker_logs SET parent_locker = ? 
         WHERE parent_locker = ? AND status = 'in_use'`,
        [tempNumber, fromLockerNumber]
      );
      db.run(
        `UPDATE locker_logs SET parent_locker = ? 
         WHERE parent_locker = ? AND status = 'in_use'`,
        [fromLockerNumber, toLockerNumber]
      );
      db.run(
        `UPDATE locker_logs SET parent_locker = ? 
         WHERE parent_locker = ? AND status = 'in_use'`,
        [toLockerNumber, tempNumber]
      );

      // 3. rental_transactions 교환
      db.run(
        `UPDATE rental_transactions SET locker_number = ? 
         WHERE locker_number = ? AND return_time IS NULL`,
        [tempNumber, fromLockerNumber]
      );
      db.run(
        `UPDATE rental_transactions SET locker_number = ? 
         WHERE locker_number = ? AND return_time IS NULL`,
        [fromLockerNumber, toLockerNumber]
      );
      db.run(
        `UPDATE rental_transactions SET locker_number = ? 
         WHERE locker_number = ? AND return_time IS NULL`,
        [toLockerNumber, tempNumber]
      );

      // 3. additional_fee_events 교환
      if (fromData && fromData.id) {
        db.run(
          `UPDATE additional_fee_events SET locker_number = ? 
           WHERE locker_log_id = ?`,
          [tempNumber, fromData.id]
        );
      }
      if (toData && toData.id) {
        db.run(
          `UPDATE additional_fee_events SET locker_number = ? 
           WHERE locker_log_id = ?`,
          [fromLockerNumber, toData.id]
        );
      }
      if (fromData && fromData.id) {
        db.run(
          `UPDATE additional_fee_events SET locker_number = ? 
           WHERE locker_log_id = ?`,
          [toLockerNumber, fromData.id]
        );
      }

      // Add notes about the swap to both customers' customer_memo (메모 아이콘으로만 표시됨)
      const timestamp = new Date().toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' });
      
      // Update customer_memo for the locker that was originally at fromLockerNumber (now at toLockerNumber)
      const fromSwapNote = `[${timestamp}] 락카교환: ${fromLockerNumber}번 ↔ ${toLockerNumber}번`;
      const fromExistingMemo = fromData?.customerMemo || '';
      const fromUpdatedMemo = fromExistingMemo ? `${fromExistingMemo}\n${fromSwapNote}` : fromSwapNote;
      db.run(
        `UPDATE locker_logs SET customer_memo = ? WHERE locker_number = ? AND status = 'in_use'`,
        [fromUpdatedMemo, toLockerNumber]
      );
      
      // Update customer_memo for the locker that was originally at toLockerNumber (now at fromLockerNumber)
      const toSwapNote = `[${timestamp}] 락카교환: ${toLockerNumber}번 ↔ ${fromLockerNumber}번`;
      const toExistingMemo = toData?.customerMemo || '';
      const toUpdatedMemo = toExistingMemo ? `${toExistingMemo}\n${toSwapNote}` : toSwapNote;
      db.run(
        `UPDATE locker_logs SET customer_memo = ? WHERE locker_number = ? AND status = 'in_use'`,
        [toUpdatedMemo, fromLockerNumber]
      );

      // Commit transaction
      db.run('COMMIT');
      
      // 두 영업일 요약 업데이트
      if (fromData && fromData.business_day) {
        updateDailySummary(fromData.business_day);
      }
      if (toData && toData.business_day && toData.business_day !== fromData?.business_day) {
        updateDailySummary(toData.business_day);
      }

      saveDatabaseDebounced();
      return { 
        success: true, 
        message: `${fromLockerNumber}번과 ${toLockerNumber}번 락카의 내용이 서로 교환되었습니다.`, 
        type: 'swap' 
      };
    }
  } catch (error) {
    console.error('Locker swap error:', error);
    // Rollback on any error
    try {
      db.run('ROLLBACK');
    } catch (rollbackError) {
      console.error('Rollback error:', rollbackError);
    }
    return { 
      success: false, 
      message: '락카 교체 중 오류가 발생했습니다.', 
      type: 'error' 
    };
  }
}

// Link child lockers to a parent locker
export function linkLockers(parentLockerNumber: number, childLockerNumbers: number[]): { success: boolean; message: string } {
  if (!db) throw new Error('Database not initialized');

  let transactionStarted = false;
  try {
    db.run('BEGIN TRANSACTION');
    transactionStarted = true;

    // Check if parent locker is in use (all queries inside transaction)
    const parentResult = db.exec(
      `SELECT * FROM locker_logs WHERE locker_number = ? AND status = 'in_use'`,
      [parentLockerNumber]
    );

    if (parentResult.length === 0 || parentResult[0].values.length === 0) {
      db.run('ROLLBACK');
      transactionStarted = false;
      return { success: false, message: '부모 락카가 사용중이 아닙니다.' };
    }

    const parentData = rowsToObjects(parentResult[0])[0];

    // Check if all child lockers are truly vacant
    // Get the latest log for each child locker and ensure it's checked_out or doesn't exist
    for (const childNumber of childLockerNumbers) {
      const latestLogResult = db.exec(
        `SELECT * FROM locker_logs 
         WHERE locker_number = ? 
         ORDER BY entry_time DESC 
         LIMIT 1`,
        [childNumber]
      );
      
      if (latestLogResult.length > 0 && latestLogResult[0].values.length > 0) {
        const latestLog = rowsToObjects(latestLogResult[0])[0];
        // Locker is occupied if latest log is in_use OR cancelled without checkout
        if (latestLog.status === 'in_use' || (latestLog.status === 'cancelled' && !latestLog.exitTime)) {
          db.run('ROLLBACK');
          transactionStarted = false;
          return { success: false, message: `${childNumber}번 락카는 이미 사용중입니다.` };
        }
      }
    }

    // Create child locker entries using parent's metadata
    for (const childNumber of childLockerNumbers) {
      db.run(
        `INSERT INTO locker_logs (
          id, locker_number, entry_time, business_day, time_type,
          base_price, option_type, final_price, status, cancelled, parent_locker
        ) VALUES (?, ?, ?, ?, ?, 0, 'none', 0, 'in_use', 0, ?)`,
        [
          `${childNumber}-${Date.now()}-${Math.random()}`,
          childNumber,
          parentData.entryTime,  // Use parent's entry_time
          parentData.businessDay,
          parentData.timeType,
          parentLockerNumber
        ]
      );
    }

    db.run('COMMIT');
    transactionStarted = false;
    saveDatabaseDebounced();

    return { 
      success: true, 
      message: `${parentLockerNumber}번 락카에 ${childLockerNumbers.join(', ')}번 락카가 묶였습니다.` 
    };
  } catch (error) {
    console.error('Locker linking error:', error);
    if (transactionStarted) {
      try {
        db.run('ROLLBACK');
      } catch (rollbackError) {
        console.error('Rollback error:', rollbackError);
      }
    }
    return { success: false, message: '락카묶기 중 오류가 발생했습니다.' };
  }
}

// Unlink a single child locker (manual unlink)
export function unlinkChildLocker(childLockerNumber: number): { success: boolean; message: string } {
  if (!db) throw new Error('Database not initialized');

  try {
    db.run('BEGIN TRANSACTION');

    // Check if child locker exists and is in use
    const childResult = db.exec(
      `SELECT * FROM locker_logs WHERE locker_number = ? AND status = 'in_use'`,
      [childLockerNumber]
    );

    if (childResult.length === 0 || childResult[0].values.length === 0) {
      db.run('ROLLBACK');
      return { success: false, message: '해당 락카가 사용중이 아닙니다.' };
    }

    const childData = rowsToObjects(childResult[0])[0];

    // Check if this locker is actually a child locker
    if (!childData.parentLocker) {
      db.run('ROLLBACK');
      return { success: false, message: '부모 락카에 연결되지 않은 락카입니다.' };
    }

    const parentNumber = childData.parentLocker;
    const checkoutTime = new Date().toISOString();

    // Unlink and check out the child locker so it becomes vacant
    db.run(
      `UPDATE locker_logs SET parent_locker = NULL, status = 'checked_out', exit_time = ? WHERE locker_number = ? AND status = 'in_use'`,
      [checkoutTime, childLockerNumber]
    );

    const changes = db.exec('SELECT changes() as count')[0]?.values[0]?.[0];
    if (changes !== 1) {
      db.run('ROLLBACK');
      return { success: false, message: '락카 해제 실패' };
    }

    db.run('COMMIT');
    saveDatabaseDebounced();

    return { 
      success: true, 
      message: `${childLockerNumber}번 락카가 ${parentNumber}번 부모 락카에서 해제되었습니다.` 
    };
  } catch (error) {
    console.error('Child locker unlink error:', error);
    try {
      db.run('ROLLBACK');
    } catch (rollbackError) {
      console.error('Rollback error:', rollbackError);
    }
    return { success: false, message: '락카 해제 중 오류가 발생했습니다.' };
  }
}

// Change parent of a child locker
export function changeChildParent(childLockerNumber: number, newParentLockerNumber: number): { success: boolean; message: string } {
  if (!db) throw new Error('Database not initialized');

  try {
    db.run('BEGIN TRANSACTION');

    // Check if child locker exists and is in use
    const childResult = db.exec(
      `SELECT * FROM locker_logs WHERE locker_number = ? AND status = 'in_use'`,
      [childLockerNumber]
    );

    if (childResult.length === 0 || childResult[0].values.length === 0) {
      db.run('ROLLBACK');
      return { success: false, message: '해당 락카가 사용중이 아닙니다.' };
    }

    const childData = rowsToObjects(childResult[0])[0];

    // Check if this locker is actually a child locker
    if (!childData.parentLocker) {
      db.run('ROLLBACK');
      return { success: false, message: '부모 락카에 연결되지 않은 락카입니다.' };
    }

    // Check if new parent locker exists and is in use
    const newParentResult = db.exec(
      `SELECT * FROM locker_logs WHERE locker_number = ? AND status = 'in_use'`,
      [newParentLockerNumber]
    );

    if (newParentResult.length === 0 || newParentResult[0].values.length === 0) {
      db.run('ROLLBACK');
      return { success: false, message: '새 부모 락카가 사용중이 아닙니다.' };
    }

    const newParentData = rowsToObjects(newParentResult[0])[0];

    // Prevent linking to itself
    if (childLockerNumber === newParentLockerNumber) {
      db.run('ROLLBACK');
      return { success: false, message: '자기 자신을 부모 락카로 설정할 수 없습니다.' };
    }

    // Prevent linking to another child locker
    if (newParentData.parentLocker) {
      db.run('ROLLBACK');
      return { success: false, message: '이미 다른 락카에 연결된 락카는 부모 락카로 설정할 수 없습니다.' };
    }

    const oldParentNumber = childData.parentLocker;

    // Update parent_locker to new parent
    db.run(
      `UPDATE locker_logs SET parent_locker = ? WHERE locker_number = ? AND status = 'in_use'`,
      [newParentLockerNumber, childLockerNumber]
    );

    const changes = db.exec('SELECT changes() as count')[0]?.values[0]?.[0];
    if (changes !== 1) {
      db.run('ROLLBACK');
      return { success: false, message: '부모 락카 변경 실패' };
    }

    db.run('COMMIT');
    saveDatabaseDebounced();

    return { 
      success: true, 
      message: `${childLockerNumber}번 락카의 부모가 ${oldParentNumber}번에서 ${newParentLockerNumber}번으로 변경되었습니다.` 
    };
  } catch (error) {
    console.error('Parent change error:', error);
    try {
      db.run('ROLLBACK');
    } catch (rollbackError) {
      console.error('Rollback error:', rollbackError);
    }
    return { success: false, message: '부모 락카 변경 중 오류가 발생했습니다.' };
  }
}

// Get child lockers for a parent locker
export function getChildLockers(parentLockerNumber: number) {
  if (!db) throw new Error('Database not initialized');

  const result = db.exec(
    `SELECT * FROM locker_logs WHERE parent_locker = ? AND status = 'in_use'`,
    [parentLockerNumber]
  );

  if (result.length === 0) return [];

  return rowsToObjects(result[0]);
}

// Unlink (checkout) child lockers when parent is checked out
// Only affects active child lockers to avoid corrupting history
export function unlinkChildLockers(parentLockerNumber: number, exitTime?: string) {
  if (!db) throw new Error('Database not initialized');

  const checkoutTime = exitTime || new Date().toISOString();

  // Only update child lockers that are currently in_use
  db.run(
    `UPDATE locker_logs 
     SET status = 'checked_out', exit_time = ? 
     WHERE parent_locker = ? AND status = 'in_use'`,
    [checkoutTime, parentLockerNumber]
  );

  saveDatabaseDebounced();
}

// Cancel child lockers when parent is cancelled
// Mirrors parent cancellation: sets cancelled=1, status='cancelled', exit_time=NULL
export function cancelChildLockers(parentLockerNumber: number) {
  if (!db) throw new Error('Database not initialized');

  // Only cancel child lockers that are currently in_use
  // Match parent cancellation behavior: set cancelled=1, don't set exit_time
  db.run(
    `UPDATE locker_logs 
     SET status = 'cancelled', cancelled = 1, exit_time = NULL
     WHERE parent_locker = ? AND status = 'in_use'`,
    [parentLockerNumber]
  );

  saveDatabaseDebounced();
}

// Atomically update parent-child locker relationships
// Used when user selects/deselects child lockers in the link dialog
export function setParentChildLinks(
  parentLockerNumber: number, 
  newChildLockerNumbers: number[]
): { success: boolean; message: string } {
  if (!db) throw new Error('Database not initialized');

  let transactionStarted = false;
  try {
    db.run('BEGIN TRANSACTION');
    transactionStarted = true;

    // Validate parent locker exists and is in use
    const parentResult = db.exec(
      `SELECT * FROM locker_logs WHERE locker_number = ? AND status = 'in_use'`,
      [parentLockerNumber]
    );

    if (parentResult.length === 0 || parentResult[0].values.length === 0) {
      db.run('ROLLBACK');
      transactionStarted = false;
      return { success: false, message: '부모 락카가 사용중이 아닙니다.' };
    }

    const parentData = rowsToObjects(parentResult[0])[0];

    // Get current child lockers
    const currentChildren = getChildLockers(parentLockerNumber);
    const currentChildNumbers = currentChildren.map(c => c.lockerNumber);

    // Calculate changes
    const toAdd = newChildLockerNumbers.filter(num => !currentChildNumbers.includes(num));
    const toRemove = currentChildNumbers.filter(num => !newChildLockerNumbers.includes(num));

    // ========== PHASE 1: VALIDATE ALL CHANGES (no mutations yet) ==========
    
    // Validate all removals first
    for (const childNumber of toRemove) {
      const childResult = db.exec(
        `SELECT * FROM locker_logs WHERE locker_number = ? AND status = 'in_use'`,
        [childNumber]
      );
      
      if (childResult.length > 0 && childResult[0].values.length > 0) {
        const allChildData = rowsToObjects(childResult[0]);
        
        // Find any row with conflicting parent ownership
        const conflictingRow = allChildData.find(
          (row: any) => row.parentLocker && row.parentLocker !== parentLockerNumber
        );
        
        if (conflictingRow) {
          db.run('ROLLBACK');
          transactionStarted = false;
          return {
            success: false,
            message: `${childNumber}번 락카는 ${conflictingRow.parentLocker}번에 묶여있습니다. 작업을 중단했습니다.`
          };
        }
      }
    }
    
    // Validate all additions
    for (const childNumber of toAdd) {
      const childResult = db.exec(
        `SELECT * FROM locker_logs WHERE locker_number = ? AND status = 'in_use'`,
        [childNumber]
      );

      if (childResult.length > 0 && childResult[0].values.length > 0) {
        const allChildData = rowsToObjects(childResult[0]);
        
        // Check each row for conflicts
        for (const childData of allChildData) {
          if (childData.basePrice > 0) {
            db.run('ROLLBACK');
            transactionStarted = false;
            return { 
              success: false, 
              message: `${childNumber}번 락카는 이미 사용 중입니다.` 
            };
          }
          
          if (childData.basePrice === 0 && childData.parentLocker && childData.parentLocker !== parentLockerNumber) {
            db.run('ROLLBACK');
            transactionStarted = false;
            return { 
              success: false, 
              message: `${childNumber}번 락카는 이미 ${childData.parentLocker}번에 묶여있습니다.` 
            };
          }
        }
      }
    }
    
    // ========== PHASE 2: APPLY ALL CHANGES (validation passed) ==========
    
    // Remove children (safe: all validated)
    for (const childNumber of toRemove) {
      db.run(
        `DELETE FROM locker_logs 
         WHERE locker_number = ? 
         AND status = 'in_use' 
         AND base_price = 0 
         AND parent_locker = ?`,
        [childNumber, parentLockerNumber]
      );
      
      db.run(
        `UPDATE locker_logs 
         SET parent_locker = NULL 
         WHERE locker_number = ? 
         AND status = 'in_use' 
         AND base_price > 0 
         AND parent_locker = ?`,
        [childNumber, parentLockerNumber]
      );
    }

    // Add children (safe: all validated)
    for (const childNumber of toAdd) {
      db.run(
        `DELETE FROM locker_logs 
         WHERE locker_number = ? 
         AND status = 'in_use' 
         AND base_price = 0 
         AND (parent_locker IS NULL OR parent_locker = ?)`,
        [childNumber, parentLockerNumber]
      );
      
      const id = generateId();
      
      db.run(
        `INSERT INTO locker_logs 
        (id, locker_number, entry_time, business_day, time_type, base_price, final_price, 
         option_type, status, cancelled, parent_locker)
        VALUES (?, ?, ?, ?, ?, 0, 0, 'none', 'in_use', 0, ?)`,
        [
          id,
          childNumber,
          parentData.entryTime,
          parentData.businessDay,
          parentData.timeType,
          parentLockerNumber
        ]
      );
    }

    // Add note about linking/unlinking to parent locker's customer_memo (메모 아이콘으로만 표시됨)
    if (toAdd.length > 0 || toRemove.length > 0) {
      const timestamp = new Date().toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' });
      const linkNotes: string[] = [];
      
      if (toAdd.length > 0) {
        linkNotes.push(`[${timestamp}] 락카묶기: ${toAdd.join(', ')}번 추가`);
      }
      if (toRemove.length > 0) {
        linkNotes.push(`[${timestamp}] 락카묶기해제: ${toRemove.join(', ')}번 해제`);
      }
      
      const existingMemo = parentData?.customerMemo || '';
      const newNoteText = linkNotes.join('\n');
      const updatedMemo = existingMemo ? `${existingMemo}\n${newNoteText}` : newNoteText;
      
      db.run(
        `UPDATE locker_logs SET customer_memo = ? WHERE locker_number = ? AND status = 'in_use'`,
        [updatedMemo, parentLockerNumber]
      );
    }

    db.run('COMMIT');
    transactionStarted = false;
    saveDatabaseDebounced();

    if (toAdd.length > 0 && toRemove.length > 0) {
      return { 
        success: true, 
        message: `${toAdd.join(', ')}번 락카가 추가되고, ${toRemove.join(', ')}번 락카가 해제되었습니다.` 
      };
    } else if (toAdd.length > 0) {
      return { 
        success: true, 
        message: `${toAdd.join(', ')}번 락카가 추가되었습니다.` 
      };
    } else if (toRemove.length > 0) {
      return { 
        success: true, 
        message: `${toRemove.join(', ')}번 락카가 해제되었습니다.` 
      };
    } else {
      return { success: true, message: '변경사항이 없습니다.' };
    }
  } catch (error) {
    console.error('Parent-child link update error:', error);
    if (transactionStarted) {
      try {
        db.run('ROLLBACK');
      } catch (rollbackError) {
        console.error('Rollback error:', rollbackError);
      }
    }
    return { success: false, message: '락카 링크 업데이트 중 오류가 발생했습니다.' };
  }
}

export function getActiveLockers() {
  if (!db) throw new Error('Database not initialized');

  const result = db.exec(
    `SELECT * FROM locker_logs WHERE status = 'in_use' ORDER BY COALESCE(exit_time, entry_time) DESC`
  );

  if (result.length === 0) return [];

  return rowsToObjects(result[0]);
}

export function getTodayEntries(businessDay: string) {
  if (!db) throw new Error('Database not initialized');

  const result = db.exec(
    `SELECT * FROM locker_logs 
     WHERE business_day = ? 
     ORDER BY COALESCE(exit_time, entry_time) DESC`,
    [businessDay]
  );

  if (result.length === 0) return [];

  return rowsToObjects(result[0]);
}

/**
 * 날짜 범위로 입실 기록 조회 (entry_time 기준)
 * 입출기록 페이지의 날짜 필터링용 - 해당 기간에 입실한 기록만 반환
 */
export function getEntriesByDateRange(startDate: string, endDate: string) {
  if (!db) throw new Error('Database not initialized');

  // Parse dates and convert to ISO
  // Input format: YYYY-MM-DD
  // Append time component for local timezone parsing
  const start = new Date(`${startDate}T00:00:00`);
  const end = new Date(`${endDate}T23:59:59.999`);
  
  // Validate dates
  if (isNaN(start.getTime()) || isNaN(end.getTime())) {
    console.error('Invalid date format:', { startDate, endDate });
    return [];
  }
  
  const startDateTime = start.toISOString();
  const endDateTime = end.toISOString();

  // Entry time based filtering: Include only records that entered within the period
  const result = db.exec(
    `SELECT * FROM locker_logs 
     WHERE entry_time >= ? AND entry_time <= ?
     ORDER BY entry_time DESC`,
    [startDateTime, endDateTime]
  );

  if (result.length === 0) return [];

  return rowsToObjects(result[0]);
}

/**
 * 시간 범위로 입실 기록 조회 (entry_time 기준)
 * 입출기록 페이지의 시간 필터링용 - 해당 시간대에 입실한 기록만 반환
 */
export function getEntriesByDateTimeRange(startDateTime: string, endDateTime: string) {
  if (!db) throw new Error('Database not initialized');

  // Entry time based filtering: Include only records that entered within the period
  const result = db.exec(
    `SELECT * FROM locker_logs 
     WHERE entry_time >= ? AND entry_time <= ?
     ORDER BY entry_time DESC`,
    [startDateTime, endDateTime]
  );

  if (result.length === 0) return [];

  return rowsToObjects(result[0]);
}

/**
 * 특정 비즈니스 데이의 모든 입실 기록 조회 (interval overlap 로직)
 * 영업일 범위와 겹치는 모든 기록 반환 - 사용 중인 락커 조회용
 * @param businessDay YYYY-MM-DD 형식의 비즈니스 데이
 * @param businessDayStartHour 비즈니스 데이 시작 시각 (기본값: 10)
 */
export function getEntriesByBusinessDayRange(businessDay: string, businessDayStartHour: number = 10) {
  if (!db) throw new Error('Database not initialized');
  
  // 비즈니스 데이 범위 계산 - 영업일 시작 시각을 기준 시간으로 사용 (T12:00:00 고정값은 영업일이 12시 이후 시작인 경우 오동작)
  const { start, end } = getBusinessDayRange(new Date(businessDay + 'T' + String(businessDayStartHour).padStart(2, '0') + ':00:00'), businessDayStartHour);
  
  // Convert to Unix timestamps (seconds) for reliable numeric comparison
  const startUnix = Math.floor(start.getTime() / 1000);
  const endUnix = Math.floor(end.getTime() / 1000);
  
  // Interval overlap logic: includes entries that overlap with the business day range
  const result = db.exec(
    `SELECT * FROM locker_logs 
     WHERE (strftime('%s', entry_time) >= ? AND strftime('%s', entry_time) <= ?)
        OR (strftime('%s', exit_time) >= ? AND strftime('%s', exit_time) <= ?)
        OR (strftime('%s', entry_time) < ? AND (exit_time IS NULL OR strftime('%s', exit_time) > ?))
     ORDER BY COALESCE(exit_time, entry_time) DESC`,
    [startUnix.toString(), endUnix.toString(), startUnix.toString(), endUnix.toString(), startUnix.toString(), endUnix.toString()]
  );

  if (result.length === 0) return [];

  return rowsToObjects(result[0]);
}

/**
 * 특정 비즈니스 데이에 입실한 기록만 조회 (entry_time 기준)
 * 방문자 수 및 입실 매출 계산용
 * @param businessDay YYYY-MM-DD 형식의 비즈니스 데이
 * @param businessDayStartHour 비즈니스 데이 시작 시각 (기본값: 10)
 */
export function getEntriesByEntryTime(businessDay: string, businessDayStartHour: number = 10) {
  if (!db) throw new Error('Database not initialized');
  
  // 비즈니스 데이 범위 계산 - 영업일 시작 시각을 기준 시간으로 사용 (T12:00:00 고정값은 영업일이 12시 이후 시작인 경우 오동작)
  const { start, end } = getBusinessDayRange(new Date(businessDay + 'T' + String(businessDayStartHour).padStart(2, '0') + ':00:00'), businessDayStartHour);
  
  // Convert to Unix timestamps (seconds) for reliable numeric comparison
  const startUnix = Math.floor(start.getTime() / 1000);
  const endUnix = Math.floor(end.getTime() / 1000);
  
  // Filter by entry_time only
  const result = db.exec(
    `SELECT * FROM locker_logs 
     WHERE strftime('%s', entry_time) >= ? AND strftime('%s', entry_time) <= ?
     ORDER BY entry_time DESC`,
    [startUnix.toString(), endUnix.toString()]
  );

  if (result.length === 0) return [];

  return rowsToObjects(result[0]);
}

/**
 * 영업일 기준 환불 합계 조회 (entry_time 기준, 취소 제외)
 * 결제수단별 환불 금액 반환 (현금/카드/이체)
 */
export function getRefundSummaryByBusinessDay(businessDay: string, businessDayStartHour: number): { total: number; count: number; cash: number; card: number; transfer: number } {
  if (!db) throw new Error('Database not initialized');
  const { start, end } = getBusinessDayRange(new Date(businessDay + 'T' + String(businessDayStartHour).padStart(2, '0') + ':00:00'), businessDayStartHour);
  const startUnix = Math.floor(start.getTime() / 1000);
  const endUnix = Math.floor(end.getTime() / 1000);
  const result = db.exec(
    `SELECT 
       COALESCE(SUM(refund_amount), 0) as total,
       COUNT(*) as count,
       COALESCE(SUM(CASE WHEN COALESCE(refund_method, 'cash') = 'cash' THEN refund_amount ELSE 0 END), 0) as cash,
       COALESCE(SUM(CASE WHEN refund_method = 'card' THEN refund_amount ELSE 0 END), 0) as card,
       COALESCE(SUM(CASE WHEN refund_method = 'transfer' THEN refund_amount ELSE 0 END), 0) as transfer
     FROM locker_logs
     WHERE cancelled = 0
       AND refund_amount > 0
       AND strftime('%s', entry_time) >= ? AND strftime('%s', entry_time) <= ?`,
    [startUnix.toString(), endUnix.toString()]
  );
  if (result.length === 0 || result[0].values.length === 0) return { total: 0, count: 0, cash: 0, card: 0, transfer: 0 };
  const row = result[0].values[0];
  return {
    total: (row[0] as number) || 0,
    count: (row[1] as number) || 0,
    cash: (row[2] as number) || 0,
    card: (row[3] as number) || 0,
    transfer: (row[4] as number) || 0,
  };
}

/**
 * 모든 입실 기록 조회 (전체)
 */
export function getAllEntries() {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec('SELECT * FROM locker_logs ORDER BY entry_time DESC');
  
  if (result.length === 0) return [];
  
  return rowsToObjects(result[0]);
}

export function getDailySummary(businessDay: string) {
  if (!db) throw new Error('Database not initialized');

  const result = db.exec(
    'SELECT * FROM locker_daily_summaries WHERE business_day = ?',
    [businessDay]
  );

  if (result.length === 0 || result[0].values.length === 0) {
    return {
      businessDay,
      totalVisitors: 0,
      totalSales: 0,
      cancellations: 0,
      totalDiscount: 0,
      foreignerCount: 0,
      foreignerSales: 0,
      dayVisitors: 0,
      nightVisitors: 0
    };
  }

  return rowsToObjects(result[0])[0];
}

export function updateDailySummary(businessDay: string) {
  if (!db) throw new Error('Database not initialized');

  // Get locker logs summary
  // 후불결제(deferred_payment = 1)인 경우 매출에서 제외
  // NULL은 후불결제가 아닌 것으로 처리 (이전 데이터 호환성)
  // 참고: final_price에는 이미 선지급금(prepaid_additional_fee)이 포함되어 있음
  const result = db.exec(
    `SELECT 
      COUNT(CASE WHEN (is_staff IS NULL OR is_staff = 0) THEN 1 END) as total_visitors,
      COALESCE(SUM(CASE WHEN status != 'cancelled' AND (deferred_payment IS NULL OR deferred_payment = 0) THEN final_price - COALESCE(refund_amount, 0) ELSE 0 END), 0) as total_sales,
      COUNT(CASE WHEN cancelled = 1 THEN 1 END) as cancellations,
      COALESCE(SUM(CASE WHEN option_type IN ('discount', 'custom') AND status != 'cancelled' THEN option_amount ELSE 0 END), 0) as total_discount,
      COUNT(CASE WHEN option_type = 'foreigner' AND status != 'cancelled' AND (is_staff IS NULL OR is_staff = 0) THEN 1 END) as foreigner_count,
      COALESCE(SUM(CASE WHEN option_type = 'foreigner' AND status != 'cancelled' AND (deferred_payment IS NULL OR deferred_payment = 0) AND (is_staff IS NULL OR is_staff = 0) THEN final_price - COALESCE(refund_amount, 0) ELSE 0 END), 0) as foreigner_sales,
      COUNT(CASE WHEN time_type = '주간' AND status != 'cancelled' AND (is_staff IS NULL OR is_staff = 0) THEN 1 END) as day_visitors,
      COUNT(CASE WHEN time_type = '야간' AND status != 'cancelled' AND (is_staff IS NULL OR is_staff = 0) THEN 1 END) as night_visitors
    FROM locker_logs
    WHERE business_day = ?`,
    [businessDay]
  );

  if (result.length === 0 || result[0].values.length === 0) return;

  const [totalVisitors, baseSales, cancellations, totalDiscount, foreignerCount, foreignerSales, dayVisitors, nightVisitors] = result[0].values[0];

  // Get additional fee events for this business day (fees recorded at checkout time)
  // 참고: 이것은 퇴실 시 발생하는 추가요금이며, 입실 시 선지급금과는 별개임
  const additionalFeeResult = db.exec(
    `SELECT COALESCE(SUM(fee_amount), 0) as additional_fee_total
     FROM additional_fee_events
     WHERE business_day = ?`,
    [businessDay]
  );
  
  const additionalFeeTotal = additionalFeeResult.length > 0 && additionalFeeResult[0].values.length > 0 
    ? additionalFeeResult[0].values[0][0] 
    : 0;

  // Total sales = base sales from locker_logs (선지급금 포함) + additional fees from checkout time
  const totalSales = (baseSales as number) + (additionalFeeTotal as number);

  // Insert or update
  db.run(
    `INSERT INTO locker_daily_summaries 
     (business_day, total_visitors, total_sales, cancellations, total_discount, foreigner_count, foreigner_sales, day_visitors, night_visitors)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(business_day) DO UPDATE SET
       total_visitors = excluded.total_visitors,
       total_sales = excluded.total_sales,
       cancellations = excluded.cancellations,
       total_discount = excluded.total_discount,
       foreigner_count = excluded.foreigner_count,
       foreigner_sales = excluded.foreigner_sales,
       day_visitors = excluded.day_visitors,
       night_visitors = excluded.night_visitors`,
    [businessDay, totalVisitors, totalSales, cancellations, totalDiscount, foreignerCount, foreignerSales, dayVisitors, nightVisitors]
  );
}

// Get all daily summaries for sales reports
export function getAllDailySummaries() {
  if (!db) throw new Error('Database not initialized');

  const result = db.exec(
    'SELECT * FROM locker_daily_summaries ORDER BY business_day DESC'
  );

  if (result.length === 0) return [];

  return rowsToObjects(result[0]);
}

// 진단 함수: 데이터베이스 상태 확인
export function debugDatabaseStatus() {
  if (!db) {
    console.error('[DEBUG] Database not initialized!');
    return { error: 'Database not initialized' };
  }
  
  // locker_logs 테이블 상태
  const logsResult = db.exec(`
    SELECT 
      COUNT(*) as total,
      COUNT(CASE WHEN status = 'in_use' THEN 1 END) as in_use,
      COUNT(CASE WHEN status = 'checked_out' THEN 1 END) as checked_out,
      COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled
    FROM locker_logs
  `);
  
  // locker_daily_summaries 테이블 상태
  const summariesResult = db.exec(`
    SELECT COUNT(*) as total, 
           COALESCE(SUM(total_sales), 0) as total_sales,
           MIN(business_day) as oldest_day,
           MAX(business_day) as newest_day
    FROM locker_daily_summaries
  `);
  
  // 최근 7일 요약 데이터
  const recentSummaries = db.exec(`
    SELECT business_day, total_visitors, total_sales 
    FROM locker_daily_summaries 
    ORDER BY business_day DESC 
    LIMIT 10
  `);
  
  const logs = logsResult.length > 0 ? logsResult[0].values[0] : [];
  const summaries = summariesResult.length > 0 ? summariesResult[0].values[0] : [];
  
  console.log('='.repeat(60));
  console.log('[DEBUG] 데이터베이스 상태 확인');
  console.log('='.repeat(60));
  console.log('\n📋 locker_logs 테이블:');
  console.log(`  - 전체 레코드: ${logs[0]}건`);
  console.log(`  - 사용중(in_use): ${logs[1]}건`);
  console.log(`  - 퇴실완료(checked_out): ${logs[2]}건`);
  console.log(`  - 취소(cancelled): ${logs[3]}건`);
  
  console.log('\n📊 locker_daily_summaries 테이블:');
  console.log(`  - 전체 레코드: ${summaries[0]}건`);
  console.log(`  - 총 매출: ${summaries[1]}원`);
  console.log(`  - 가장 오래된 날: ${summaries[2]}`);
  console.log(`  - 가장 최근 날: ${summaries[3]}`);
  
  console.log('\n📅 최근 10일 요약:');
  if (recentSummaries.length > 0 && recentSummaries[0].values.length > 0) {
    recentSummaries[0].values.forEach((row: any) => {
      console.log(`  - ${row[0]}: 방문 ${row[1]}명, 매출 ${row[2]}원`);
    });
  } else {
    console.log('  (데이터 없음)');
  }
  console.log('='.repeat(60));
  
  return {
    locker_logs: {
      total: logs[0],
      in_use: logs[1],
      checked_out: logs[2],
      cancelled: logs[3]
    },
    daily_summaries: {
      total: summaries[0],
      total_sales: summaries[1],
      oldest_day: summaries[2],
      newest_day: summaries[3]
    },
    recent_summaries: recentSummaries.length > 0 ? rowsToObjects(recentSummaries[0]) : []
  };
}

// Get daily summaries for a specific year-month (YYYY-MM)
export function getDailySummariesByMonth(yearMonth: string) {
  if (!db) throw new Error('Database not initialized');

  const result = db.exec(
    `SELECT * FROM locker_daily_summaries 
     WHERE business_day LIKE ?
     ORDER BY business_day ASC`,
    [yearMonth + '%']
  );

  console.log(`[getDailySummariesByMonth] 쿼리: ${yearMonth}%, 결과 rows:`, result.length > 0 ? result[0].values?.length : 0);

  if (result.length === 0) return [];

  const data = rowsToObjects(result[0]);
  console.log(`[getDailySummariesByMonth] 변환 후 데이터:`, data.length, '건', data.slice(0, 3));
  return data;
}

// Get locker logs by business day for hourly analysis
export function getLockerLogsByBusinessDay(businessDay: string) {
  if (!db) throw new Error('Database not initialized');

  const result = db.exec(
    `SELECT * FROM locker_logs 
     WHERE business_day = ? AND status != 'cancelled'
     ORDER BY entry_time ASC`,
    [businessDay]
  );

  if (result.length === 0) return [];

  return rowsToObjects(result[0]);
}

// Get visitor statistics by month (총방문수, 실제방문수, 취소, 무료입장)
export function getVisitorStatsByMonth(yearMonth: string) {
  if (!db) throw new Error('Database not initialized');

  const result = db.exec(
    `SELECT 
      business_day,
      COUNT(CASE WHEN (is_staff IS NULL OR is_staff = 0) THEN 1 END) as total_visitors,
      COUNT(CASE WHEN cancelled = 0 AND (option_type IS NULL OR option_type != 'free') AND parent_locker IS NULL AND (is_staff IS NULL OR is_staff = 0) THEN 1 END) as actual_visitors,
      COUNT(CASE WHEN cancelled = 1 THEN 1 END) as cancelled_visitors,
      COUNT(CASE WHEN cancelled = 0 AND option_type = 'free' AND (is_staff IS NULL OR is_staff = 0) THEN 1 END) as free_visitors
     FROM locker_logs 
     WHERE business_day LIKE ? AND parent_locker IS NULL
     GROUP BY business_day
     ORDER BY business_day ASC`,
    [yearMonth + '%']
  );

  if (result.length === 0) return [];

  return rowsToObjects(result[0]);
}

// Get daily payment breakdown by month (cash, card, transfer)
export function getDailyPaymentBreakdownByMonth(yearMonth: string) {
  if (!db) throw new Error('Database not initialized');

  const result = db.exec(
    `SELECT 
      business_day,
      COALESCE(SUM(CASE WHEN status != 'cancelled' THEN COALESCE(payment_cash, 0) ELSE 0 END), 0) as cash,
      COALESCE(SUM(CASE WHEN status != 'cancelled' THEN COALESCE(payment_card, 0) ELSE 0 END), 0) as card,
      COALESCE(SUM(CASE WHEN status != 'cancelled' THEN COALESCE(payment_transfer, 0) ELSE 0 END), 0) as transfer
     FROM locker_logs 
     WHERE business_day LIKE ?
     GROUP BY business_day
     ORDER BY business_day ASC`,
    [yearMonth + '%']
  );

  if (result.length === 0) return [];

  return rowsToObjects(result[0]);
}

// Get cancelled sales amount for a specific month (YYYY-MM)
export function getCancelledSalesByMonth(yearMonth: string) {
  if (!db) throw new Error('Database not initialized');

  const result = db.exec(
    `SELECT 
      business_day,
      COALESCE(SUM(final_price), 0) as cancelled_amount,
      COUNT(*) as cancelled_count
     FROM locker_logs 
     WHERE business_day LIKE ? AND (status = 'cancelled' OR cancelled = 1)
     GROUP BY business_day
     ORDER BY business_day ASC`,
    [yearMonth + '%']
  );

  if (result.length === 0) return [];

  return rowsToObjects(result[0]);
}

// Get locker logs for a date range (for reports)
export function getLockerLogsByDateRange(startDate: string, endDate: string) {
  if (!db) throw new Error('Database not initialized');

  const result = db.exec(
    `SELECT * FROM locker_logs 
     WHERE business_day >= ? AND business_day <= ? AND status != 'cancelled'
     ORDER BY entry_time ASC`,
    [startDate, endDate]
  );

  if (result.length === 0) return [];

  return rowsToObjects(result[0]);
}

// Locker Groups operations
export function getLockerGroups() {
  if (!db) throw new Error('Database not initialized');

  const result = db.exec('SELECT * FROM locker_groups ORDER BY sort_order ASC');

  if (result.length === 0) return [];

  return rowsToObjects(result[0]);
}

export function createLockerGroup(group: {
  name: string;
  startNumber: number;
  endNumber: number;
  sortOrder?: number;
}): string {
  if (!db) throw new Error('Database not initialized');

  const id = generateId();
  const sortOrder = group.sortOrder ?? 0;

  db.run(
    `INSERT INTO locker_groups (id, name, start_number, end_number, sort_order)
     VALUES (?, ?, ?, ?, ?)`,
    [id, group.name, group.startNumber, group.endNumber, sortOrder]
  );

  saveDatabaseDebounced();
  return id;
}

export function updateLockerGroup(id: string, updates: {
  name?: string;
  startNumber?: number;
  endNumber?: number;
  sortOrder?: number;
}) {
  if (!db) throw new Error('Database not initialized');

  const sets: string[] = [];
  const values: any[] = [];

  if (updates.name !== undefined) {
    sets.push('name = ?');
    values.push(updates.name);
  }
  if (updates.startNumber !== undefined) {
    sets.push('start_number = ?');
    values.push(updates.startNumber);
  }
  if (updates.endNumber !== undefined) {
    sets.push('end_number = ?');
    values.push(updates.endNumber);
  }
  if (updates.sortOrder !== undefined) {
    sets.push('sort_order = ?');
    values.push(updates.sortOrder);
  }

  if (sets.length > 0) {
    values.push(id);
    db.run(
      `UPDATE locker_groups SET ${sets.join(', ')} WHERE id = ?`,
      values
    );
    saveDatabaseDebounced();
  }
}

export function deleteLockerGroup(id: string) {
  if (!db) throw new Error('Database not initialized');

  db.run('DELETE FROM locker_groups WHERE id = ?', [id]);
  saveDatabaseDebounced();
}

// Helper function to convert SQL result rows to objects
function rowsToObjects(result: { columns: string[]; values: any[][] }): any[] {
  return result.values.map(row => {
    const obj: any = {};
    result.columns.forEach((col, idx) => {
      let value = row[idx];
      
      // Convert camelCase column names
      const camelCol = col.replace(/_([a-z])/g, (g) => g[1].toUpperCase());
      
      // Convert numeric strings to numbers where appropriate
      // Exclude columns ending with _method (text values like 'cash', 'card', 'transfer')
      const isMethodColumn = col.endsWith('_method');
      if (!isMethodColumn && (col.includes('number') || col.includes('price') || col.includes('amount') || col.includes('count') || col.includes('visitors') || col.includes('sales') || col.includes('order') || col.includes('fee') || col.includes('revenue'))) {
        value = typeof value === 'number' ? value : (value ? parseInt(value as string) : value);
      }
      
      // Convert boolean fields
      if (col === 'cancelled' || col === 'deferred_payment' || col === 'no_additional_fee' || col === 'is_cash_receipt' || col === 'is_outing' || col === 'is_staff') {
        value = value === 1;
      }
      
      obj[camelCol] = value;
    });
    return obj;
  });
}

// Settings operations (using localStorage)
export function getSettings() {
  const isV2 = (import.meta as any).env?.VITE_SKIN === 'v2';

  const baseDefaults = {
    businessDayStartHour: 10,
    dayPrice: 10000,
    nightPrice: 15000,
    discountAmount: 2000,
    foreignerPrice: 25000,
    domesticCheckpointHour: 1,
    foreignerAdditionalFeePeriod: 24,
    domesticAdditionalFeeMode: 'nextday' as 'nextday' | 'nightstart',
    screenWakeLock: true,
    cardPaymentAppEnabled: false,
    cardPaymentAppPackage: 'com.tossplace.app.release',
    dayStartTime: '07:00',
    nightStartTime: '19:00',
    enableDiscountOption: true,
    enableForeignerOption: true,
    enableCashReceiptVat: false,
    enableCardVat: false,
    outingTimeLimitMinutes: 0,
    outingTimeLimitWeekendMinutes: 0,
  };

  const v2Overrides = {
    businessDayStartHour: 14,
    dayPrice: 20000,
    nightPrice: 25000,
    nightStartTime: '17:00',
    enableDiscountOption: false,
    enableForeignerOption: false,
    enableCashReceiptVat: true,
    enableCardVat: true,
    cardPaymentAppPackage: 'tosspos://main',
  };

  const defaultSettings = isV2 ? { ...baseDefaults, ...v2Overrides } : baseDefaults;

  const saved = localStorage.getItem('settings');
  if (!saved) return defaultSettings;

  try {
    return { ...defaultSettings, ...JSON.parse(saved) };
  } catch {
    return defaultSettings;
  }
}

export function updateSettings(settings: any) {
  const current = getSettings();
  const updated = { ...current, ...settings };
  localStorage.setItem('settings', JSON.stringify(updated));
}

// Helper: getTimeType with settings (주간/야간 시작 시간 설정 적용)
export function getTimeTypeWithSettings(date: Date = new Date()): '주간' | '야간' {
  const settings = getSettings();
  const { dayStartTime = '07:00', nightStartTime = '19:00' } = settings;
  return getTimeType(date, dayStartTime, nightStartTime);
}

// Data management operations
export function clearAllData() {
  if (!db) throw new Error('Database not initialized');
  
  // Delete all operational data (but keep locker groups, system metadata, and master data like additional_revenue_items)
  db.run('DELETE FROM locker_logs');
  db.run('DELETE FROM locker_daily_summaries');
  db.run('DELETE FROM rental_transactions');
  db.run('DELETE FROM additional_fee_events');
  db.run('DELETE FROM expenses');
  db.run('DELETE FROM closing_days');
  
  // VACUUM: 삭제된 페이지 공간 회수 → saveDatabase() 크기/속도 정상화
  db.run('VACUUM');
  saveDatabase();
}

export function deleteOldData(cutoffDate: string) {
  if (!db) throw new Error('Database not initialized');
  
  // Delete entries older than cutoff date (1 year ago)
  db.run('DELETE FROM locker_logs WHERE business_day < ?', [cutoffDate]);
  db.run('DELETE FROM locker_daily_summaries WHERE business_day < ?', [cutoffDate]);
  
  saveDatabase();
}

export function getOldestEntryDate(): string | null {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec('SELECT MIN(business_day) as oldest FROM locker_logs');
  
  if (result.length === 0 || result[0].values.length === 0 || !result[0].values[0][0]) {
    return null;
  }
  
  return result[0].values[0][0] as string;
}

// Test data generation for time-based features
export function createTestData() {
  if (!db) throw new Error('Database not initialized');
  
  const settings = getSettings();
  const { dayPrice, nightPrice, businessDayStartHour, discountAmount, foreignerPrice, domesticCheckpointHour, foreignerAdditionalFeePeriod } = settings;
  
  // Helper function to format date for business day
  const getBusinessDay = (date: Date): string => {
    const hour = date.getHours();
    if (hour < businessDayStartHour) {
      const yesterday = new Date(date);
      yesterday.setDate(yesterday.getDate() - 1);
      return yesterday.toISOString().split('T')[0];
    }
    return date.toISOString().split('T')[0];
  };
  
  // Random helpers
  const randomInt = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;
  const randomElement = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
  const randomBoolean = (probability = 0.5) => Math.random() < probability;
  
  // Delete existing test data (locker numbers 1-80)
  db.run('DELETE FROM locker_logs WHERE locker_number BETWEEN 1 AND 80');
  
  const now = new Date();
  const currentHour = now.getHours();
  const isCurrentlyDaytime = getTimeTypeWithSettings(now) === '주간';
  
  console.log('=== 테스트 데이터 생성 시작 ===');
  console.log('현재 시각:', now.toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' }));
  console.log('현재 시간대:', getTimeTypeWithSettings(now));
  
  // 중복 방지: 각 락커당 하나의 entry만 생성
  const usedLockers = new Set<number>();
  
  const paymentMethods: Array<'card' | 'cash' | 'transfer'> = ['card', 'cash', 'transfer'];
  const optionTypes: Array<'none' | 'discount' | 'foreigner'> = ['none', 'discount', 'foreigner'];
  
  // Helper: Get unused random locker number
  const getUnusedLocker = (): number | null => {
    if (usedLockers.size >= 80) return null;
    let lockerNumber: number;
    do {
      lockerNumber = randomInt(1, 80);
    } while (usedLockers.has(lockerNumber));
    usedLockers.add(lockerNumber);
    return lockerNumber;
  };
  
  let totalGenerated = 0;
  let additionalFee1Count = 0; // 추가요금 1회 카운터
  let additionalFee2PlusCount = 0; // 추가요금 2회 이상 카운터
  const database = db;
  
  // 먼저 추가요금 발생 데이터를 제한된 개수만큼 생성
  console.log('\n추가요금 1회 데이터 2개 생성 중...');
  // 1. 추가요금 1회 데이터 (1일 전 입실, 최대 2개)
  for (let i = 0; i < 2; i++) {
    const lockerNumber = getUnusedLocker();
    if (!lockerNumber) break;
    
    const daysAgo = 1;
    const targetDate = new Date();
    targetDate.setDate(targetDate.getDate() - daysAgo);
    
    const hour = randomInt(0, 23);
    const minute = randomInt(0, 59);
    
    const entryDate = new Date(targetDate);
    entryDate.setHours(hour, minute, 0, 0);
    
    const timeType = getTimeTypeWithSettings(entryDate);
    const basePrice = timeType === '주간' ? dayPrice : nightPrice;
    
    console.log(`  락커${lockerNumber}: ${entryDate.toLocaleString('ko-KR')} (1일 전) → timeType: ${timeType}, basePrice: ${basePrice}`);
    
    const optionType = randomElement(optionTypes);
    let optionAmount = null;
    let finalPrice = basePrice;
    
    if (optionType === 'discount') {
      optionAmount = -discountAmount;
      finalPrice = basePrice - discountAmount;
    } else if (optionType === 'foreigner') {
      optionAmount = foreignerPrice - basePrice;
      finalPrice = foreignerPrice;
    }
    
    const paymentMethod = randomElement(paymentMethods);
    const id = generateId();
    const entryTime = entryDate.toISOString();
    const businessDay = getBusinessDay(entryDate);
    
    // Set payment columns based on payment method
    const paymentCash = paymentMethod === 'cash' ? finalPrice : null;
    const paymentCard = paymentMethod === 'card' ? finalPrice : null;
    const paymentTransfer = paymentMethod === 'transfer' ? finalPrice : null;
    
    database.run(
      `INSERT INTO locker_logs 
      (id, locker_number, entry_time, exit_time, business_day, time_type, base_price, 
       option_type, option_amount, final_price, status, cancelled, notes, payment_method, payment_cash, payment_card, payment_transfer, rental_items)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'in_use', 0, ?, ?, ?, ?, ?, ?)`,
      [id, lockerNumber, entryTime, null, businessDay, timeType, basePrice, optionType, optionAmount, finalPrice, '테스트: 추가요금 1회', paymentMethod, paymentCash, paymentCard, paymentTransfer, null]
    );
    
    totalGenerated++;
    additionalFee1Count++;
    updateDailySummary(businessDay);
  }
  
  // 2. 추가요금 2회 이상 데이터 (2~3일 전 입실, 최대 2개)
  console.log('\n추가요금 2회+ 데이터 2개 생성 중...');
  for (let i = 0; i < 2; i++) {
    const lockerNumber = getUnusedLocker();
    if (!lockerNumber) break;
    
    const daysAgo = randomInt(2, 3);
    const targetDate = new Date();
    targetDate.setDate(targetDate.getDate() - daysAgo);
    
    const hour = randomInt(0, 23);
    const minute = randomInt(0, 59);
    
    const entryDate = new Date(targetDate);
    entryDate.setHours(hour, minute, 0, 0);
    
    const timeType = getTimeTypeWithSettings(entryDate);
    const basePrice = timeType === '주간' ? dayPrice : nightPrice;
    
    console.log(`  락커${lockerNumber}: ${entryDate.toLocaleString('ko-KR')} (${daysAgo}일 전) → timeType: ${timeType}, basePrice: ${basePrice}`);
    
    const optionType = randomElement(optionTypes);
    let optionAmount = null;
    let finalPrice = basePrice;
    
    if (optionType === 'discount') {
      optionAmount = -discountAmount;
      finalPrice = basePrice - discountAmount;
    } else if (optionType === 'foreigner') {
      optionAmount = foreignerPrice - basePrice;
      finalPrice = foreignerPrice;
    }
    
    const paymentMethod = randomElement(paymentMethods);
    const id = generateId();
    const entryTime = entryDate.toISOString();
    const businessDay = getBusinessDay(entryDate);
    
    // Set payment columns based on payment method
    const paymentCash = paymentMethod === 'cash' ? finalPrice : null;
    const paymentCard = paymentMethod === 'card' ? finalPrice : null;
    const paymentTransfer = paymentMethod === 'transfer' ? finalPrice : null;
    
    database.run(
      `INSERT INTO locker_logs 
      (id, locker_number, entry_time, exit_time, business_day, time_type, base_price, 
       option_type, option_amount, final_price, status, cancelled, notes, payment_method, payment_cash, payment_card, payment_transfer, rental_items)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'in_use', 0, ?, ?, ?, ?, ?, ?)`,
      [id, lockerNumber, entryTime, null, businessDay, timeType, basePrice, optionType, optionAmount, finalPrice, '테스트: 추가요금 2회+', paymentMethod, paymentCash, paymentCard, paymentTransfer, null]
    );
    
    totalGenerated++;
    additionalFee2PlusCount++;
    updateDailySummary(businessDay);
  }
  
  // 3. 나머지는 오늘 데이터만 생성 (추가요금 발생하지 않도록)
  // 현재 시각 기준으로 과거 시간만 생성
  const remainingLockers = 80 - usedLockers.size;
  
  // 주간과 야간을 반반씩 생성하도록
  const dayEntries = Math.floor(remainingLockers / 2);
  const nightEntries = remainingLockers - dayEntries;
  
  // 주간 데이터 생성 (오전 7시부터 현재 시각까지만)
  console.log(`\n주간 데이터 ${dayEntries}개 생성 중...`);
  for (let i = 0; i < dayEntries; i++) {
    const lockerNumber = getUnusedLocker();
    if (!lockerNumber) break;
    
    // 현재 시각보다 이전 시간으로만 생성
    const minHour = 7;
    const maxHour = Math.min(currentHour, 18); // 현재 시각과 18시 중 작은 값
    
    // 만약 현재가 오전 7시 이전이면 주간 데이터 생성 불가
    if (maxHour < minHour) continue;
    
    const hour = randomInt(minHour, maxHour);
    const maxMinute = (hour === currentHour) ? now.getMinutes() : 59; // 현재 시각이면 현재 분까지만
    const minute = randomInt(0, maxMinute);
    
    const entryDate = new Date();
    entryDate.setHours(hour, minute, 0, 0);
    
    const timeType = getTimeTypeWithSettings(entryDate); // 실제 입실 시각으로 판단
    const basePrice = timeType === '주간' ? dayPrice : nightPrice;
    
    if (i < 3) { // 처음 3개만 로그 출력
      console.log(`  락커${lockerNumber}: ${entryDate.toLocaleString('ko-KR')} → timeType: ${timeType}, basePrice: ${basePrice}`);
    }
    
    // Random option type
    const optionType = randomElement(optionTypes);
    let optionAmount = null;
    let finalPrice = basePrice;
    
    if (optionType === 'discount') {
      optionAmount = -discountAmount;
      finalPrice = basePrice - discountAmount;
    } else if (optionType === 'foreigner') {
      optionAmount = foreignerPrice - basePrice;
      finalPrice = foreignerPrice;
    }
    
    // Random payment method
    const paymentMethod = randomElement(paymentMethods);
    
    // Set payment columns based on payment method
    const paymentCash = paymentMethod === 'cash' ? finalPrice : null;
    const paymentCard = paymentMethod === 'card' ? finalPrice : null;
    const paymentTransfer = paymentMethod === 'transfer' ? finalPrice : null;
    
    // Most are in_use (today's data)
    const status = 'in_use';
    const exitTime = null;
    
    const id = generateId();
    const entryTime = entryDate.toISOString();
    const businessDay = getBusinessDay(entryDate);
    
    database.run(
      `INSERT INTO locker_logs 
      (id, locker_number, entry_time, exit_time, business_day, time_type, base_price, 
       option_type, option_amount, final_price, status, cancelled, notes, payment_method, payment_cash, payment_card, payment_transfer, rental_items)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        lockerNumber,
        entryTime,
        exitTime,
        businessDay,
        timeType,
        basePrice,
        optionType,
        optionAmount,
        finalPrice,
        status,
        '테스트 데이터',
        paymentMethod,
        paymentCash,
        paymentCard,
        paymentTransfer,
        null
      ]
    );
    
    totalGenerated++;
    
    // Update daily summary for this business day
    updateDailySummary(businessDay);
  }
  
  // 야간 데이터 생성 (어제 저녁 19시 ~ 오늘 오전 7시)
  console.log(`\n야간 데이터 ${nightEntries}개 생성 중...`);
  for (let i = 0; i < nightEntries; i++) {
    const lockerNumber = getUnusedLocker();
    if (!lockerNumber) break;
    
    let entryDate: Date;
    let hour: number;
    let minute: number;
    
    // 50% 확률로 오늘 새벽 또는 어제 저녁
    if (randomBoolean()) {
      // 오늘 새벽 (0-6시, 현재가 7시 이전이면 현재 시각까지)
      const maxNightHour = currentHour < 7 ? currentHour : 6;
      if (maxNightHour < 0) continue; // 현재가 자정 이전이면 스킵
      
      hour = randomInt(0, maxNightHour);
      const maxMinute = (hour === currentHour && currentHour < 7) ? now.getMinutes() : 59;
      minute = randomInt(0, maxMinute);
      
      entryDate = new Date();
      entryDate.setHours(hour, minute, 0, 0);
    } else {
      // 어제 저녁 (19-23시)
      hour = randomInt(19, 23);
      minute = randomInt(0, 59);
      
      entryDate = new Date();
      entryDate.setDate(entryDate.getDate() - 1); // 어제
      entryDate.setHours(hour, minute, 0, 0);
    }
    
    const timeType = getTimeTypeWithSettings(entryDate); // 실제 입실 시각으로 판단
    const basePrice = timeType === '주간' ? dayPrice : nightPrice;
    
    if (i < 3) { // 처음 3개만 로그 출력
      console.log(`  락커${lockerNumber}: ${entryDate.toLocaleString('ko-KR')} → timeType: ${timeType}, basePrice: ${basePrice}`);
    }
    
    // Random option type
    const optionType = randomElement(optionTypes);
    let optionAmount = null;
    let finalPrice = basePrice;
    
    if (optionType === 'discount') {
      optionAmount = -discountAmount;
      finalPrice = basePrice - discountAmount;
    } else if (optionType === 'foreigner') {
      optionAmount = foreignerPrice - basePrice;
      finalPrice = foreignerPrice;
    }
    
    // Random payment method
    const paymentMethod = randomElement(paymentMethods);
    
    // Set payment columns based on payment method
    const paymentCash = paymentMethod === 'cash' ? finalPrice : null;
    const paymentCard = paymentMethod === 'card' ? finalPrice : null;
    const paymentTransfer = paymentMethod === 'transfer' ? finalPrice : null;
    
    // Most are in_use (today's data)
    const status = 'in_use';
    const exitTime = null;
    
    const id = generateId();
    const entryTime = entryDate.toISOString();
    const businessDay = getBusinessDay(entryDate);
    
    database.run(
      `INSERT INTO locker_logs 
      (id, locker_number, entry_time, exit_time, business_day, time_type, base_price, 
       option_type, option_amount, final_price, status, cancelled, notes, payment_method, payment_cash, payment_card, payment_transfer, rental_items)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        lockerNumber,
        entryTime,
        exitTime,
        businessDay,
        timeType,
        basePrice,
        optionType,
        optionAmount,
        finalPrice,
        status,
        '테스트 데이터',
        paymentMethod,
        paymentCash,
        paymentCard,
        paymentTransfer,
        null
      ]
    );
    
    totalGenerated++;
    
    // Update daily summary for this business day
    updateDailySummary(businessDay);
  }
  
  // 4. 과거 데이터는 퇴실 완료된 데이터로만 생성 (추가요금 방지)
  // 영업일 기준(10:00~익일10:00)으로 24시간 전체에 데이터 생성
  for (let pastDays = 1; pastDays <= 7; pastDays++) {
    // 영업일 기준 날짜 계산 (정오 기준)
    const baseDate = new Date();
    baseDate.setDate(baseDate.getDate() - pastDays);
    baseDate.setHours(12, 0, 0, 0); // 정오로 설정하여 영업일 확정
    
    const pastEntries = randomInt(10, 30);
    
    for (let i = 0; i < pastEntries; i++) {
      const lockerNumber = randomInt(1, 80);
      
      // 영업일 기준 24시간 범위에서 랜덤 시간 생성
      // 당일 10:00~23:59 (14시간) 또는 익일 00:00~09:59 (10시간)
      const isNextDayHour = randomBoolean(0.4); // 40% 확률로 익일 새벽 시간
      
      let entryDate: Date;
      if (isNextDayHour) {
        // 익일 00:00~09:59
        entryDate = new Date(baseDate);
        entryDate.setDate(entryDate.getDate() + 1);
        const hour = randomInt(0, 9);
        const minute = randomInt(0, 59);
        entryDate.setHours(hour, minute, 0, 0);
      } else {
        // 당일 10:00~23:59
        entryDate = new Date(baseDate);
        const hour = randomInt(10, 23);
        const minute = randomInt(0, 59);
        entryDate.setHours(hour, minute, 0, 0);
      }
      
      const timeType = getTimeTypeWithSettings(entryDate);
      const basePrice = timeType === '주간' ? dayPrice : nightPrice;
      
      const optionType = randomElement(optionTypes);
      let optionAmount = null;
      let finalPrice = basePrice;
      
      if (optionType === 'discount') {
        optionAmount = -discountAmount;
        finalPrice = basePrice - discountAmount;
      } else if (optionType === 'foreigner') {
        optionAmount = foreignerPrice - basePrice;
        finalPrice = foreignerPrice;
      }
      
      const paymentMethod = randomElement(paymentMethods);
      
      // 과거 데이터는 모두 퇴실 완료 상태
      const status = 'checked_out';
      const exitTime = new Date(entryDate.getTime() + randomInt(30, 180) * 60000).toISOString();
      
      const id = generateId();
      const entryTime = entryDate.toISOString();
      const businessDay = getBusinessDay(entryDate); // 영업일 기준으로 자동 계산
      
      database.run(
        `INSERT INTO locker_logs 
        (id, locker_number, entry_time, exit_time, business_day, time_type, base_price, 
         option_type, option_amount, final_price, status, cancelled, notes, payment_method, rental_items)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?)`,
        [
          id,
          lockerNumber,
          entryTime,
          exitTime,
          businessDay,
          timeType,
          basePrice,
          optionType,
          optionAmount,
          finalPrice,
          status,
          '테스트 데이터 (퇴실완료)',
          paymentMethod,
          null
        ]
      );
      
      totalGenerated++;
      updateDailySummary(businessDay);
    }
  }
  
  // 5. 렌탈 아이템 추가 (기존 additional_revenue_items 테이블 사용)
  // 6. 랜덤하게 사용중인 락커에 렌탈 아이템 추가 (약 30%)
  console.log('\n렌탈 아이템 추가 중...');
  const inUseLogs = db.exec(`SELECT * FROM locker_logs WHERE status = 'in_use' AND locker_number BETWEEN 1 AND 80`);
  
  if (inUseLogs.length > 0 && inUseLogs[0].values.length > 0) {
    const rentalItems = db.exec(`SELECT * FROM additional_revenue_items`);
    const items = rentalItems.length > 0 && rentalItems[0].values.length > 0 
      ? rentalItems[0].values.map((row: any) => ({
          id: row[0],
          name: row[1],
          rentalFee: row[2],
          depositAmount: row[3],
        }))
      : [];
    
    let rentalCount = 0;
    inUseLogs[0].values.forEach((row: any) => {
      // 30% 확률로 렌탈 아이템 추가
      if (randomBoolean(0.3)) {
        const logId = row[0];
        const lockerNumber = row[1];
        const entryTime = row[2];
        const businessDay = row[4];
        const paymentCash = row[14];
        const paymentCard = row[15];
        const paymentTransfer = row[16];
        
        // 랜덤하게 아이템 선택 (1-2개)
        const numItems = randomBoolean(0.5) ? 1 : 2;
        const selectedItems = [];
        const usedItemIds = new Set();
        
        for (let i = 0; i < numItems && i < items.length; i++) {
          let item;
          do {
            item = randomElement(items);
          } while (usedItemIds.has(item.id) && usedItemIds.size < items.length);
          
          usedItemIds.add(item.id);
          selectedItems.push(item);
        }
        
        // 각 아이템마다 렌탈 트랜잭션 생성
        selectedItems.forEach(item => {
          const rentalId = generateId();
          const itemRevenue = item.rentalFee + item.depositAmount; // 대여시: 렌탈비 + 보증금
          
          // 결제 방식은 현금으로 고정
          database.run(
            `INSERT INTO rental_transactions 
            (id, locker_log_id, item_id, item_name, locker_number, rental_time, return_time, business_day, 
             rental_fee, deposit_amount, payment_method, payment_cash, payment_card, payment_transfer, 
             deposit_status, revenue, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'cash', ?, ?, ?, 'received', ?, ?, ?)`,
            [
              rentalId, logId, item.id, item.name, lockerNumber, entryTime, null, businessDay,
              item.rentalFee, item.depositAmount, itemRevenue, 0, 0, 'received', itemRevenue,
              new Date().toISOString(), new Date().toISOString()
            ]
          );
        });
        
        rentalCount++;
      }
    });
    
    console.log(`  ${rentalCount}개 락커에 렌탈 아이템 추가`);
  }
  
  saveDatabaseDebounced();
  
  console.log(`\n테스트 데이터 생성 완료: 총 ${totalGenerated}건 (과거 7일치, 락커 #1~80)`);
  console.log(`- 추가요금 1회: ${additionalFee1Count}건 (오렌지)`);
  console.log(`- 추가요금 2회+: ${additionalFee2PlusCount}건 (레드)`);
}

// Create comprehensive test data with guaranteed same-business-day additional fee
export async function createAdditionalFeeTestData() {
  if (!db) throw new Error('Database not initialized');
  
  return new Promise<boolean>((resolve, reject) => {
    try {
      const settings = getSettings();
      const { dayPrice, nightPrice, businessDayStartHour, discountAmount, foreignerPrice, domesticCheckpointHour = 1, foreignerAdditionalFeePeriod = 24 } = settings;
      
      // Random helpers
      const randomInt = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;
      const randomElement = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
      const randomBoolean = (probability = 0.5) => Math.random() < probability;
      
      // Delete existing test data (locker numbers 1-80)
      db!.run('DELETE FROM additional_fee_events WHERE locker_number BETWEEN 1 AND 80');
      db!.run('DELETE FROM locker_logs WHERE locker_number BETWEEN 1 AND 80');
      
      const paymentMethods: Array<'card' | 'cash' | 'transfer'> = ['card', 'cash', 'transfer'];
      const optionTypes: Array<'none' | 'discount' | 'foreigner'> = ['none', 'discount', 'foreigner'];
      
      let totalGenerated = 0;
      console.log('=== 3일치 랜덤 테스트 데이터 생성 시작 ===');
      
      // Get current business day range
      const now = new Date();
      const currentBusinessDay = getBusinessDay(now, businessDayStartHour);
      const { start: currentBusinessDayStart } = getBusinessDayRange(now, businessDayStartHour);
      
      console.log(`📍 현재 영업일: ${currentBusinessDay}`);
      console.log(`📍 영업일 시작: ${currentBusinessDayStart.toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' })}`);
      
      // ===== CURRENT IN-USE LOCKERS: Generate 5-10 random lockers with various states =====
      console.log('\n현재 사용 중인 락커 생성 (5-10개, 다양한 상태)');
      
      const numCurrentLockers = randomInt(5, 10);
      const currentUsedLockers = new Set<number>();
      
      // Pre-determine state distribution to guarantee at least one of each color
      // 30% Green, 30% Red, 20% Yellow, 20% Blue
      const states: string[] = [];
      const greenCount = Math.max(1, Math.round(numCurrentLockers * 0.3)); // At least 1
      const redCount = Math.max(1, Math.round(numCurrentLockers * 0.3)); // At least 1
      const yellowCount = Math.max(1, Math.round(numCurrentLockers * 0.2));
      const blueCount = numCurrentLockers - greenCount - redCount - yellowCount;
      
      for (let i = 0; i < greenCount; i++) states.push('green');
      for (let i = 0; i < redCount; i++) states.push('red');
      for (let i = 0; i < yellowCount; i++) states.push('yellow');
      for (let i = 0; i < blueCount; i++) states.push('blue');
      
      // Shuffle states for randomness
      for (let i = states.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [states[i], states[j]] = [states[j], states[i]];
      }
      
      for (let i = 0; i < numCurrentLockers; i++) {
        // Get unused locker number
        let lockerNumber: number;
        do {
          lockerNumber = randomInt(1, 80);
        } while (currentUsedLockers.has(lockerNumber));
        currentUsedLockers.add(lockerNumber);
        
        const state = states[i];
        
        if (state === 'green') {
          // GREEN: Previous business day entry with NO additional fee
          // - 내국인: 이전 영업일 야간(19:00~) 입실 + 아직 첫 자정 안 넘김
          // - 외국인: 이전 영업일 입실 + 아직 24시간 안 지남
          
          const previousBusinessDayStart = new Date(currentBusinessDayStart.getTime() - 24 * 60 * 60 * 1000);
          
          // 50% 외국인, 50% 내국인
          const isForeigner = randomBoolean(0.5);
          let entryTime: Date;
          let validEntry = false;
          let attempts = 0;
          const maxAttempts = 20;
          
          while (!validEntry && attempts < maxAttempts) {
            attempts++;
            
            if (isForeigner) {
              // 외국인: 24시간 기준 → 현재 시각 - 24시간 이내 입실
              // 범위: max(previousBusinessDayStart, now - 24시간 + 1시간 버퍼) ~ currentBusinessDayStart - 1
              const twentyFourHoursAgo = now.getTime() - 24 * 60 * 60 * 1000;
              const minEntryTime = Math.max(previousBusinessDayStart.getTime(), twentyFourHoursAgo + 60 * 60 * 1000); // +1시간 버퍼
              const maxEntryTime = currentBusinessDayStart.getTime() - 1;
              
              if (minEntryTime >= maxEntryTime) {
                console.log(`  ⚠️ 락커 #${lockerNumber}: 외국인 그린 생성 불가 (유효 시간 범위 없음)`);
                break;
              }
              
              entryTime = new Date(minEntryTime + Math.random() * (maxEntryTime - minEntryTime));
            } else {
              // 내국인: 자정 기준 → 이전 영업일 야간(19:00~) + 아직 첫 자정 안 넘김
              // 첫 자정 = 입실일 다음날 00:00
              // 범위: previousBusinessDayStart + 9시간(19:00) ~ min(currentBusinessDayStart - 1, 다음날 00:00 - 1)
              
              const nineteenHoursAfterStart = previousBusinessDayStart.getTime() + 9 * 60 * 60 * 1000; // 19:00
              
              // 다음날 00:00 (첫 자정)
              const nextMidnight = new Date(previousBusinessDayStart);
              nextMidnight.setDate(nextMidnight.getDate() + 1);
              nextMidnight.setHours(0, 0, 0, 0);
              
              const minEntryTime = nineteenHoursAfterStart;
              const maxEntryTime = Math.min(currentBusinessDayStart.getTime() - 1, nextMidnight.getTime() - 1);
              
              if (minEntryTime >= maxEntryTime) {
                console.log(`  ⚠️ 락커 #${lockerNumber}: 내국인 그린 생성 불가 (현재 시각으로는 자정 안 넘긴 야간 입실 불가능)`);
                break;
              }
              
              entryTime = new Date(minEntryTime + Math.random() * (maxEntryTime - minEntryTime));
            }
            
            // 검증: 추가요금이 없는지 확인
            const businessDay = getBusinessDay(entryTime, businessDayStartHour);
            const timeType = getTimeTypeWithSettings(entryTime);
            
            const { additionalFeeCount, additionalFee } = calculateAdditionalFee(
              entryTime.toISOString(),
              timeType,
              dayPrice,
              nightPrice,
              now,
              isForeigner,
              foreignerPrice,
              domesticCheckpointHour,
              foreignerAdditionalFeePeriod
            );
            
            if (additionalFeeCount === 0) {
              validEntry = true;
              
              const basePrice = isForeigner ? foreignerPrice : (timeType === '주간' ? dayPrice : nightPrice);
              const optionType = isForeigner ? 'foreigner' : 'none';
              const paymentMethod = randomElement(paymentMethods);
              
              db!.run(
                `INSERT INTO locker_logs 
                (id, locker_number, entry_time, exit_time, business_day, time_type, base_price, 
                 option_type, option_amount, final_price, status, cancelled, notes, payment_method, 
                 payment_cash, payment_card, payment_transfer, rental_items, additional_fees)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'in_use', 0, ?, ?, ?, ?, ?, ?, 0)`,
                [generateId(), lockerNumber, entryTime.toISOString(), null, businessDay, 
                 timeType, basePrice, optionType, 0, basePrice, 
                 `이전영업일+사용중+추가요금없음(${isForeigner ? '외국인' : '내국인'})`, 
                 paymentMethod, 
                 paymentMethod === 'cash' ? basePrice : 0,
                 paymentMethod === 'card' ? basePrice : 0,
                 paymentMethod === 'transfer' ? basePrice : 0,
                 null]
              );
              
              console.log(`  🟢 락커 #${lockerNumber}: 그린 (${isForeigner ? '외국인' : '내국인'}, ${timeType}, 입실: ${entryTime.toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' })}) ✓`);
              totalGenerated++;
              updateDailySummary(businessDay);
            } else {
              console.log(`  ⚠️ 락커 #${lockerNumber}: 그린 재시도 (추가요금: ${additionalFee}원, ${attempts}/${maxAttempts})`);
            }
          }
          
          if (!validEntry) {
            console.log(`  ❌ 락커 #${lockerNumber}: 그린 생성 실패 (${maxAttempts}회 시도 후 포기)`);
          }
          
        } else if (state === 'red') {
          // RED: Previous business day entry, crossed midnight → additional fee MUST occur
          // Validate with calculateAdditionalFee to guarantee red status
          
          const previousBusinessDayStart = new Date(currentBusinessDayStart.getTime() - 24 * 60 * 60 * 1000);
          
          let validEntry = false;
          let attempts = 0;
          const maxAttempts = 20;
          let entryTime: Date;
          let optionType: 'none' | 'foreigner';
          let basePrice: number;
          let timeType: '주간' | '야간';
          let businessDay: string;
          
          while (!validEntry && attempts < maxAttempts) {
            attempts++;
            
            // 50% 외국인, 50% 내국인
            const isForeigner = randomBoolean(0.5);
            optionType = isForeigner ? 'foreigner' : 'none';
            
            if (isForeigner) {
              // 외국인: 24시간 기준 → 24시간 이상 전에 입실
              // 현재 시각 - 25~35시간 전
              const hoursAgo = randomInt(25, 35);
              entryTime = new Date(now.getTime() - hoursAgo * 60 * 60 * 1000);
              
              // Make sure entry is in previous business day range
              if (entryTime < previousBusinessDayStart) {
                entryTime = new Date(previousBusinessDayStart.getTime() + randomInt(1, 12) * 60 * 60 * 1000);
              }
            } else {
              // 내국인: 자정 기준 → 어제 주간 또는 야간 < 07:00 입실 (첫 자정에 추가요금 발생)
              // 야간 >= 19:00는 첫 자정 무료이므로 제외
              const useEarlyMorning = randomBoolean(0.5);
              
              if (useEarlyMorning) {
                // 야간 < 07:00 입실: 새벽 00:00 ~ 06:59
                const entryHour = randomInt(0, 6);
                const entryMinute = randomInt(0, 59);
                entryTime = new Date(previousBusinessDayStart);
                entryTime.setDate(entryTime.getDate() + 1); // 다음 날로 이동
                entryTime.setHours(entryHour, entryMinute, 0, 0);
              } else {
                // 주간 입실: 07:00 ~ 18:59
                const hoursAfterStart = randomInt(0, 9); // 0-9시간 (최대 19:00까지)
                entryTime = new Date(previousBusinessDayStart.getTime() + hoursAfterStart * 60 * 60 * 1000);
              }
            }
            
            businessDay = getBusinessDay(entryTime, businessDayStartHour);
            timeType = getTimeTypeWithSettings(entryTime);
            basePrice = timeType === '주간' ? dayPrice : nightPrice;
            
            // Validate: Must have additional fee
            const result = calculateAdditionalFee(
              entryTime.toISOString(),
              timeType,
              dayPrice,
              nightPrice,
              now,
              optionType === 'foreigner',
              foreignerPrice,
              domesticCheckpointHour,
              foreignerAdditionalFeePeriod
            );
            
            if (result.additionalFee > 0) {
              validEntry = true;
              
              const paymentMethod = randomElement(paymentMethods);
              
              db!.run(
                `INSERT INTO locker_logs 
                (id, locker_number, entry_time, exit_time, business_day, time_type, base_price, 
                 option_type, option_amount, final_price, status, cancelled, notes, payment_method, 
                 payment_cash, payment_card, payment_transfer, rental_items, additional_fees)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'in_use', 0, ?, ?, ?, ?, ?, ?, 0)`,
                [generateId(), lockerNumber, entryTime.toISOString(), null, businessDay, 
                 timeType, basePrice, optionType, 0, basePrice, 
                 `이전영업일+사용중+추가요금발생(${isForeigner ? '외국인' : '내국인'})`, 
                 paymentMethod,
                 paymentMethod === 'cash' ? basePrice : 0,
                 paymentMethod === 'card' ? basePrice : 0,
                 paymentMethod === 'transfer' ? basePrice : 0,
                 null]
              );
              
              console.log(`  🔴 락커 #${lockerNumber}: 레드 (${isForeigner ? '외국인' : '내국인'}, ${timeType}, 추가요금: ₩${result.additionalFee.toLocaleString()}, 입실: ${entryTime.toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' })}) ✓`);
              totalGenerated++;
              updateDailySummary(businessDay);
            } else {
              console.log(`  ⚠️ 락커 #${lockerNumber}: 레드 재시도 (추가요금: ${result.additionalFee}원, ${attempts}/${maxAttempts})`);
            }
          }
          
          if (!validEntry) {
            console.log(`  ❌ 락커 #${lockerNumber}: 레드 생성 실패 (${maxAttempts}회 시도 후 포기)`);
          }
          
        } else if (state === 'yellow') {
          // YELLOW: Today daytime entry (must be in the past)
          // Calculate max hours from business day start to current time
          const now = new Date();
          const maxHoursFromStart = Math.floor((now.getTime() - currentBusinessDayStart.getTime()) / (60 * 60 * 1000));
          const maxHours = Math.min(8, maxHoursFromStart - 1); // Cap at 8 hours, ensure past time
          
          if (maxHours < 1) {
            // Not enough time passed since business day start, skip yellow
            continue;
          }
          
          const hoursAfterStart = randomInt(1, maxHours);
          const entryTime = new Date(currentBusinessDayStart.getTime() + hoursAfterStart * 60 * 60 * 1000);
          
          const businessDay = getBusinessDay(entryTime, businessDayStartHour);
          const timeType = getTimeTypeWithSettings(entryTime);
          const basePrice = dayPrice;
          const paymentMethod = randomElement(paymentMethods);
          
          db!.run(
            `INSERT INTO locker_logs 
            (id, locker_number, entry_time, exit_time, business_day, time_type, base_price, 
             option_type, option_amount, final_price, status, cancelled, notes, payment_method, 
             payment_cash, payment_card, payment_transfer, rental_items, additional_fees)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'in_use', 0, ?, ?, ?, ?, ?, ?, 0)`,
            [generateId(), lockerNumber, entryTime.toISOString(), null, businessDay, 
             timeType, basePrice, 'none', 0, basePrice, '오늘주간입실+사용중', 
             paymentMethod,
             paymentMethod === 'cash' ? basePrice : 0,
             paymentMethod === 'card' ? basePrice : 0,
             paymentMethod === 'transfer' ? basePrice : 0,
             null]
          );
          
          console.log(`  🟡 락커 #${lockerNumber}: 옐로우 (오늘 주간 입실)`);
          totalGenerated++;
          updateDailySummary(businessDay);
          
        } else {
          // BLUE: Today nighttime entry (must be in the past)
          // Calculate max hours from business day start to current time
          const now = new Date();
          const maxHoursFromStart = Math.floor((now.getTime() - currentBusinessDayStart.getTime()) / (60 * 60 * 1000));
          const maxHours = Math.min(15, maxHoursFromStart - 1); // Cap at 15 hours, ensure past time
          
          if (maxHours < 9) {
            // Not enough time passed for nighttime entry, skip blue
            continue;
          }
          
          const hoursAfterStart = randomInt(9, maxHours);
          const entryTime = new Date(currentBusinessDayStart.getTime() + hoursAfterStart * 60 * 60 * 1000);
          
          const businessDay = getBusinessDay(entryTime, businessDayStartHour);
          const timeType = getTimeTypeWithSettings(entryTime);
          const basePrice = nightPrice;
          const paymentMethod = randomElement(paymentMethods);
          
          db!.run(
            `INSERT INTO locker_logs 
            (id, locker_number, entry_time, exit_time, business_day, time_type, base_price, 
             option_type, option_amount, final_price, status, cancelled, notes, payment_method, 
             payment_cash, payment_card, payment_transfer, rental_items, additional_fees)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'in_use', 0, ?, ?, ?, ?, ?, ?, 0)`,
            [generateId(), lockerNumber, entryTime.toISOString(), null, businessDay, 
             timeType, basePrice, 'none', 0, basePrice, '오늘야간입실+사용중', 
             paymentMethod,
             paymentMethod === 'cash' ? basePrice : 0,
             paymentMethod === 'card' ? basePrice : 0,
             paymentMethod === 'transfer' ? basePrice : 0,
             null]
          );
          
          console.log(`  🔵 락커 #${lockerNumber}: 블루 (오늘 야간 입실)`);
          totalGenerated++;
          updateDailySummary(businessDay);
        }
      }
      
      console.log(`\n✅ 현재 사용 중인 락커 ${numCurrentLockers}개 생성 완료`);
      
      // ===== NO PAST DATA: Only today's data =====
      // Past data generation removed to ensure fresh state on initial installation
      console.log('\n✅ 과거 데이터 생성 생략 (깨끗한 상태 유지)');
      
      // ===== TODAY'S DATA: More in-use entries =====
      console.log('\n추가 사용중 락커 생성 중...');
      const nowForToday = new Date();
      const todayEntries = randomInt(5, 15);
      
      // Use existing currentUsedLockers Set to avoid duplicates
      const usedLockers = currentUsedLockers;
      
      const getUnusedLocker = (): number | null => {
        if (usedLockers.size >= 80) return null;
        let lockerNumber: number;
        do {
          lockerNumber = randomInt(1, 80);
        } while (usedLockers.has(lockerNumber));
        usedLockers.add(lockerNumber);
        return lockerNumber;
      };
      
      // Calculate valid entry time range for current business day
      // If current time is before business day start (e.g., 02:00, start at 10:00)
      // → Use yesterday's business day start to now
      // If current time is after business day start
      // → Use today's business day start to now
      let entryRangeStart: Date;
      if (nowForToday < currentBusinessDayStart) {
        // Early morning (before business day start)
        entryRangeStart = new Date(currentBusinessDayStart.getTime() - 24 * 60 * 60 * 1000);
        console.log(`  ⏰ 새벽 시간 (${nowForToday.getHours()}시) → 어제 영업일 시작부터 생성`);
      } else {
        entryRangeStart = currentBusinessDayStart;
        console.log(`  ⏰ 영업일 시작 이후 → 오늘 영업일 시작부터 생성`);
      }
      
      console.log(`  📅 입실 범위: ${entryRangeStart.toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' })} ~ ${nowForToday.toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' })}`);
      
      for (let i = 0; i < todayEntries; i++) {
        const lockerNumber = getUnusedLocker();
        if (!lockerNumber) break;
        
        // Random entry time within valid range
        const timeRange = nowForToday.getTime() - entryRangeStart.getTime();
        const randomOffset = Math.floor(Math.random() * timeRange);
        const entryDate = new Date(entryRangeStart.getTime() + randomOffset);
        
        const timeType = getTimeTypeWithSettings(entryDate);
        const basePrice = timeType === '주간' ? dayPrice : nightPrice;
        
        const optionType = randomElement(optionTypes);
        let optionAmount = 0;
        let finalPrice = basePrice;
        
        if (optionType === 'discount') {
          optionAmount = -discountAmount;
          finalPrice = basePrice - discountAmount;
        } else if (optionType === 'foreigner') {
          optionAmount = foreignerPrice - basePrice;
          finalPrice = foreignerPrice;
        }
        
        const paymentMethod = randomElement(paymentMethods);
        const paymentCash = paymentMethod === 'cash' ? finalPrice : 0;
        const paymentCard = paymentMethod === 'card' ? finalPrice : 0;
        const paymentTransfer = paymentMethod === 'transfer' ? finalPrice : 0;
        
        const id = generateId();
        const businessDay = getBusinessDay(entryDate, businessDayStartHour);
        
        db!.run(
          `INSERT INTO locker_logs 
          (id, locker_number, entry_time, exit_time, business_day, time_type, base_price, 
           option_type, option_amount, final_price, status, cancelled, notes, payment_method, 
           payment_cash, payment_card, payment_transfer, rental_items, additional_fees)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'in_use', 0, ?, ?, ?, ?, ?, ?, 0)`,
          [id, lockerNumber, entryDate.toISOString(), null, businessDay, 
           timeType, basePrice, optionType, optionAmount, finalPrice, '테스트 데이터', 
           paymentMethod, paymentCash, paymentCard, paymentTransfer, null]
        );
        
        totalGenerated++;
        updateDailySummary(businessDay);
      }
      
      // ===== GENERATE PAST COMPLETED DATA (checked_out) for sales reports =====
      console.log('\n과거 퇴실 완료 데이터 생성 (매출 리포트용)');
      
      for (let pastDays = 0; pastDays <= 7; pastDays++) {
        const pastDate = new Date();
        pastDate.setDate(pastDate.getDate() - pastDays);
        
        // 과거 날짜의 데이터 개수 (오늘은 적게, 과거로 갈수록 많게)
        const pastEntries = pastDays === 0 ? randomInt(5, 15) : randomInt(20, 40);
        
        for (let i = 0; i < pastEntries; i++) {
          let lockerNumber: number;
          do {
            lockerNumber = randomInt(1, 80);
          } while (currentUsedLockers.has(lockerNumber));
          
          const hour = randomInt(10, 23);
          const minute = randomInt(0, 59);
          
          const entryDate = new Date(pastDate);
          entryDate.setHours(hour, minute, 0, 0);
          
          const timeType = getTimeTypeWithSettings(entryDate);
          const basePrice = timeType === '주간' ? dayPrice : nightPrice;
          
          const optionType = randomElement(optionTypes);
          let optionAmount = 0;
          let finalPrice = basePrice;
          
          if (optionType === 'discount') {
            optionAmount = -discountAmount;
            finalPrice = basePrice - discountAmount;
          } else if (optionType === 'foreigner') {
            optionAmount = foreignerPrice - basePrice;
            finalPrice = foreignerPrice;
          }
          
          const paymentMethod = randomElement(paymentMethods);
          const paymentCash = paymentMethod === 'cash' ? finalPrice : 0;
          const paymentCard = paymentMethod === 'card' ? finalPrice : 0;
          const paymentTransfer = paymentMethod === 'transfer' ? finalPrice : 0;
          
          const exitDate = new Date(entryDate.getTime() + randomInt(30, 180) * 60000);
          
          const id = generateId();
          const businessDay = getBusinessDay(entryDate, businessDayStartHour);
          
          db!.run(
            `INSERT INTO locker_logs 
            (id, locker_number, entry_time, exit_time, business_day, time_type, base_price, 
             option_type, option_amount, final_price, status, cancelled, notes, payment_method, 
             payment_cash, payment_card, payment_transfer, rental_items, additional_fees)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'checked_out', 0, ?, ?, ?, ?, ?, ?, 0)`,
            [id, lockerNumber, entryDate.toISOString(), exitDate.toISOString(), businessDay, 
             timeType, basePrice, optionType, optionAmount, finalPrice, '테스트 데이터 (퇴실완료)', 
             paymentMethod, paymentCash, paymentCard, paymentTransfer, null]
          );
          
          totalGenerated++;
          updateDailySummary(businessDay);
        }
        
        console.log(`  ${pastDays === 0 ? '오늘' : pastDays + '일 전'}: ${pastEntries}건 생성`);
      }
      
      saveDatabaseDebounced();
      
      // Verify additional fee pending lockers (in_use with expected fees)
      const pendingStmt = db!.prepare(`
        SELECT COUNT(*) as count 
        FROM locker_logs 
        WHERE locker_number BETWEEN 1 AND 80 
        AND status = 'in_use'
        AND notes LIKE '%추가요금%'
      `);
      const pendingResult = pendingStmt.get([]) as any;
      const pendingAdditionalFeeCount = pendingResult?.count || 0;
      pendingStmt.free();
      
      // Verify completed additional fee events
      const verifyStmt = db!.prepare('SELECT COUNT(*) as count FROM additional_fee_events WHERE locker_number BETWEEN 1 AND 80');
      const verifyResult = verifyStmt.get([]) as any;
      const completedAdditionalFeeCount = verifyResult?.count || 0;
      verifyStmt.free();
      
      console.log('\n='.repeat(60));
      console.log('✅ 테스트 데이터 생성 완료!');
      console.log('='.repeat(60));
      console.log(`📊 총 생성 건수: ${totalGenerated}건 (락커 #1~80, 3일치)`);
      console.log(`🔴 추가요금 발생 예정: ${pendingAdditionalFeeCount}건 (사용중, 퇴실 시 기록됨)`);
      console.log(`💰 추가요금 이미 처리: ${completedAdditionalFeeCount}건 (퇴실 완료)`);
      
      if (pendingAdditionalFeeCount === 0 && completedAdditionalFeeCount === 0) {
        console.warn('⚠️ 추가요금 관련 락커가 생성되지 않았습니다.');
      } else {
        console.log('🎯 Type A 시나리오: 전일 주간 입실 + 자정 넘김 + 사용중 (₩5,000 발생 예정) ✓');
        
        // Show detailed info about completed additional fees
        if (completedAdditionalFeeCount > 0) {
          const feeDetailsStmt = db!.prepare(`
            SELECT 
              afe.locker_number,
              afe.fee_amount,
              afe.payment_method,
              afe.business_day,
              ll.business_day as entry_business_day
            FROM additional_fee_events afe
            LEFT JOIN locker_logs ll ON afe.locker_log_id = ll.id
            WHERE afe.locker_number BETWEEN 1 AND 80
            ORDER BY afe.checkout_time DESC
          `);
          
          const feeDetails: Array<{
            locker_number: number;
            fee_amount: number;
            payment_method: string;
            business_day: string;
            entry_business_day: string;
          }> = [];
          
          while (feeDetailsStmt.step()) {
            const row = feeDetailsStmt.getAsObject() as any;
            feeDetails.push(row);
          }
          feeDetailsStmt.free();
          
          console.log('\n📋 퇴실 완료된 추가요금 내역:');
          feeDetails.forEach((fee, idx) => {
            const sameDay = fee.business_day === fee.entry_business_day ? '✅ 같은 영업일' : '❌ 다른 영업일';
            console.log(`  ${idx + 1}. 락커 #${fee.locker_number}: ${fee.fee_amount}원 (${fee.payment_method.toUpperCase()}) - ${sameDay}`);
          });
        }
      }
      console.log('='.repeat(60));
      
      setTimeout(() => {
        resolve(true);
      }, 100);
    } catch (error) {
      console.error('Error creating test data:', error);
      reject(error);
    }
  });
}

// ===== Stage 1: Additional Fee Events =====

export function createAdditionalFeeEvent(event: {
  lockerLogId: string;
  lockerNumber: number;
  checkoutTime: Date;
  feeAmount: number;
  originalFeeAmount?: number;
  discountAmount?: number;
  businessDay: string;
  paymentMethod: string;
  paymentCash?: number;
  paymentCard?: number;
  paymentTransfer?: number;
}): string {
  if (!db) throw new Error('Database not initialized');
  
  const id = generateId();
  const checkoutTimeStr = event.checkoutTime.toISOString();
  const createdAt = new Date().toISOString();
  
  db.run(
    `INSERT INTO additional_fee_events 
    (id, locker_log_id, locker_number, checkout_time, fee_amount, original_fee_amount, discount_amount, 
     business_day, payment_method, payment_cash, payment_card, payment_transfer, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, event.lockerLogId, event.lockerNumber, checkoutTimeStr, event.feeAmount, 
     event.originalFeeAmount || null, event.discountAmount || 0, event.businessDay, event.paymentMethod, 
     event.paymentCash || null, event.paymentCard || null, event.paymentTransfer || null, createdAt]
  );
  
  saveDatabaseDebounced();
  return id;
}

export function getAdditionalFeeEventsByBusinessDay(businessDay: string) {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(
    `SELECT * FROM additional_fee_events WHERE business_day = ? ORDER BY checkout_time DESC`,
    [businessDay]
  );
  
  if (result.length === 0 || result[0].values.length === 0) {
    return [];
  }
  
  return result[0].values.map((row: any) => ({
    id: row[0],
    lockerLogId: row[1],
    lockerNumber: row[2],
    checkoutTime: row[3],
    feeAmount: row[4],
    businessDay: row[5],
    paymentMethod: row[6],
    createdAt: row[7],
  }));
}

export function getAdditionalFeeEventsByLockerLog(lockerLogId: string) {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(
    `SELECT * FROM additional_fee_events WHERE locker_log_id = ? ORDER BY created_at DESC`,
    [lockerLogId]
  );
  
  if (result.length === 0 || result[0].values.length === 0) {
    return [];
  }
  
  return result[0].values.map((row: any) => ({
    id: row[0],
    lockerLogId: row[1],
    lockerNumber: row[2],
    checkoutTime: row[3],
    feeAmount: row[4],
    businessDay: row[5],
    paymentMethod: row[6],
    createdAt: row[7],
  }));
}

export function getTotalAdditionalFeesByBusinessDay(businessDay: string): number {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(
    `SELECT COALESCE(SUM(fee_amount), 0) as total FROM additional_fee_events WHERE business_day = ?`,
    [businessDay]
  );
  
  if (result.length === 0 || result[0].values.length === 0) {
    return 0;
  }
  
  return result[0].values[0][0] as number;
}

export function getAdditionalFeeEventsByDateRange(startDate: string, endDate: string) {
  if (!db) throw new Error('Database not initialized');
  
  // Convert dates to datetime range in local timezone, then to ISO for storage comparison
  const startDateTime = new Date(startDate + 'T00:00:00').toISOString();
  const endDateTime = new Date(endDate + 'T23:59:59.999').toISOString();
  
  const result = db.exec(
    `SELECT * FROM additional_fee_events 
     WHERE checkout_time >= ? AND checkout_time <= ?
     ORDER BY checkout_time DESC`,
    [startDateTime, endDateTime]
  );
  
  if (result.length === 0 || result[0].values.length === 0) {
    return [];
  }
  
  return result[0].values.map((row: any) => ({
    id: row[0],
    lockerLogId: row[1],
    lockerNumber: row[2],
    checkoutTime: row[3],
    feeAmount: row[4],
    businessDay: row[5],
    paymentMethod: row[6],
    createdAt: row[7],
  }));
}

export function getAdditionalFeeEventsByDateTimeRange(startDateTime: string, endDateTime: string) {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(
    `SELECT * FROM additional_fee_events 
     WHERE checkout_time >= ? AND checkout_time <= ?
     ORDER BY checkout_time DESC`,
    [startDateTime, endDateTime]
  );
  
  if (result.length === 0 || result[0].values.length === 0) {
    return [];
  }
  
  return result[0].values.map((row: any) => ({
    id: row[0],
    lockerLogId: row[1],
    lockerNumber: row[2],
    checkoutTime: row[3],
    feeAmount: row[4],
    businessDay: row[5],
    paymentMethod: row[6],
    createdAt: row[7],
  }));
}

/**
 * 특정 비즈니스 데이의 모든 추가요금 이벤트 조회
 * @param businessDay YYYY-MM-DD 형식의 비즈니스 데이
 * @param businessDayStartHour 비즈니스 데이 시작 시각 (기본값: 10)
 */
/**
 * 모든 추가요금 이벤트 조회 (전체)
 */
export function getAllAdditionalFeeEvents() {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec('SELECT * FROM additional_fee_events ORDER BY checkout_time DESC');
  
  if (result.length === 0 || result[0].values.length === 0) {
    return [];
  }
  
  return result[0].values.map((row: any) => ({
    id: row[0],
    lockerLogId: row[1],
    lockerNumber: row[2],
    checkoutTime: row[3],
    feeAmount: row[4],
    originalFeeAmount: row[5],
    discountAmount: row[6],
    businessDay: row[7],
    paymentMethod: row[8],
    paymentCash: row[9],
    paymentCard: row[10],
    paymentTransfer: row[11],
    createdAt: row[12],
  }));
}

export function getAdditionalFeeEventsByBusinessDayRange(businessDay: string, businessDayStartHour: number = 10) {
  if (!db) throw new Error('Database not initialized');
  
  // 비즈니스 데이 범위 계산 - 영업일 시작 시각을 기준 시간으로 사용 (T12:00:00 고정값은 영업일이 12시 이후 시작인 경우 오동작)
  const { start, end } = getBusinessDayRange(new Date(businessDay + 'T' + String(businessDayStartHour).padStart(2, '0') + ':00:00'), businessDayStartHour);
  
  // Convert to Unix timestamps (seconds) for reliable numeric comparison
  const startUnix = Math.floor(start.getTime() / 1000);
  const endUnix = Math.floor(end.getTime() / 1000);
  
  const result = db.exec(
    `SELECT afe.*, ll.business_day as entry_business_day 
     FROM additional_fee_events afe
     LEFT JOIN locker_logs ll ON afe.locker_log_id = ll.id
     WHERE strftime('%s', afe.checkout_time) >= ? AND strftime('%s', afe.checkout_time) <= ?
     ORDER BY afe.checkout_time DESC`,
    [startUnix.toString(), endUnix.toString()]
  );
  
  if (result.length === 0 || result[0].values.length === 0) {
    return [];
  }
  
  return result[0].values.map((row: any) => ({
    id: row[0],
    lockerLogId: row[1],
    lockerNumber: row[2],
    checkoutTime: row[3],
    feeAmount: row[4],
    originalFeeAmount: row[5],
    discountAmount: row[6],
    businessDay: row[7],
    paymentMethod: row[8],
    paymentCash: row[9],
    paymentCard: row[10],
    paymentTransfer: row[11],
    createdAt: row[12],
    entryBusinessDay: row[13], // 입실 영업일 추가
  }));
}

export function getTotalRentalRevenueByBusinessDay(businessDay: string): number {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(
    `SELECT COALESCE(SUM(revenue), 0) as total FROM rental_transactions WHERE business_day = ?`,
    [businessDay]
  );
  
  if (result.length === 0 || result[0].values.length === 0) {
    return 0;
  }
  
  return result[0].values[0][0] as number;
}

// Additional Revenue Items (rental items: 롱타올, 담요 등) operations
export function getAdditionalRevenueItems() {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec('SELECT * FROM additional_revenue_items ORDER BY sort_order ASC');
  
  if (result.length === 0) return [];
  
  return rowsToObjects(result[0]);
}

export function createAdditionalRevenueItem(item: {
  name: string;
  rentalFee: number;
  depositAmount: number;
  billingType?: 'rental' | 'simple';
  sortOrder?: number;
}): string {
  if (!db) throw new Error('Database not initialized');
  
  const id = generateId();
  const now = new Date().toISOString();
  const sortOrder = item.sortOrder ?? 999;
  const billingType = item.billingType ?? 'rental';
  
  db.run(
    `INSERT INTO additional_revenue_items (id, name, rental_fee, deposit_amount, billing_type, sort_order, is_default, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?)`,
    [id, item.name, item.rentalFee, item.depositAmount, billingType, sortOrder, now, now]
  );
  
  saveDatabaseDebounced();
  return id;
}

export function updateAdditionalRevenueItem(id: string, updates: {
  name?: string;
  rentalFee?: number;
  depositAmount?: number;
  billingType?: 'rental' | 'simple';
  sortOrder?: number;
}) {
  if (!db) throw new Error('Database not initialized');
  
  const sets: string[] = [];
  const values: any[] = [];
  
  if (updates.name !== undefined) {
    sets.push('name = ?');
    values.push(updates.name);
  }
  if (updates.rentalFee !== undefined) {
    sets.push('rental_fee = ?');
    values.push(updates.rentalFee);
  }
  if (updates.depositAmount !== undefined) {
    sets.push('deposit_amount = ?');
    values.push(updates.depositAmount);
  }
  if (updates.billingType !== undefined) {
    sets.push('billing_type = ?');
    values.push(updates.billingType);
  }
  if (updates.sortOrder !== undefined) {
    sets.push('sort_order = ?');
    values.push(updates.sortOrder);
  }
  
  if (sets.length === 0) return;
  
  sets.push('updated_at = ?');
  values.push(new Date().toISOString());
  values.push(id);
  
  db.run(
    `UPDATE additional_revenue_items SET ${sets.join(', ')} WHERE id = ?`,
    values
  );
  
  saveDatabaseDebounced();
}

export function deleteAdditionalRevenueItem(id: string) {
  if (!db) throw new Error('Database not initialized');
  
  db.run('DELETE FROM additional_revenue_items WHERE id = ? AND is_default = 0', [id]);
  saveDatabaseDebounced();
}

// Rental Transactions operations
export function createRentalTransaction(rental: {
  lockerLogId: string;
  itemId: string;
  itemName: string;
  lockerNumber: number;
  rentalTime: string | Date;
  returnTime: string | Date | null;
  businessDay: string;
  rentalFee: number;
  depositAmount: number;
  paymentMethod: 'card' | 'cash' | 'transfer';
  paymentCash?: number;
  paymentCard?: number;
  paymentTransfer?: number;
  depositStatus: 'received' | 'refunded' | 'forfeited' | 'none';
  revenue: number;
}): string {
  if (!db) throw new Error('Database not initialized');
  
  const id = generateId();
  const now = new Date().toISOString();
  
  const rentalTimeStr = rental.rentalTime instanceof Date ? rental.rentalTime.toISOString() : rental.rentalTime;
  const returnTimeStr = rental.returnTime ? (rental.returnTime instanceof Date ? rental.returnTime.toISOString() : rental.returnTime) : null;
  
  db.run(
    `INSERT INTO rental_transactions 
     (id, locker_log_id, item_id, item_name, locker_number, rental_time, return_time, business_day,
      rental_fee, deposit_amount, payment_method, payment_cash, payment_card, payment_transfer, 
      deposit_status, revenue, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      id,
      rental.lockerLogId,
      rental.itemId,
      rental.itemName,
      rental.lockerNumber,
      rentalTimeStr,
      returnTimeStr,
      rental.businessDay,
      rental.rentalFee,
      rental.depositAmount,
      rental.paymentMethod,
      rental.paymentCash || null,
      rental.paymentCard || null,
      rental.paymentTransfer || null,
      rental.depositStatus,
      rental.revenue,
      now,
      now
    ]
  );
  
  saveDatabaseDebounced();
  return id;
}

export function updateRentalTransaction(id: string, updates: {
  depositStatus?: 'received' | 'refunded' | 'forfeited' | 'none';
  returnTime?: Date;
  paymentMethod?: 'card' | 'cash' | 'transfer';
  businessDay?: string;
  paymentCash?: number;
  paymentCard?: number;
  paymentTransfer?: number;
  revenue?: number;
  returnCompleted?: boolean;
}) {
  if (!db) throw new Error('Database not initialized');
  
  // Get settings for business day calculation
  const settings = getSettings();
  const businessDayStartHour = settings.businessDayStartHour || 10;
  
  // Get current transaction to calculate new revenue and prepare updates
  const result = db.exec('SELECT rental_fee, deposit_amount, deposit_status, return_time, payment_method, business_day, payment_cash, payment_card, payment_transfer, rental_time, item_name, locker_number FROM rental_transactions WHERE id = ?', [id]);
  
  if (result.length === 0 || result[0].values.length === 0) return;
  
  const rentalFee = result[0].values[0][0] as number;
  const depositAmount = result[0].values[0][1] as number;
  const currentDepositStatus = result[0].values[0][2] as string;
  const currentReturnTime = result[0].values[0][3];
  const currentPaymentMethod = result[0].values[0][4];
  const currentBusinessDay = result[0].values[0][5];
  const currentPaymentCash = result[0].values[0][6];
  const currentPaymentCard = result[0].values[0][7];
  const currentPaymentTransfer = result[0].values[0][8];
  const rentalTime = result[0].values[0][9] as string;
  const itemName = result[0].values[0][10] as string;
  const lockerNumber = result[0].values[0][11] as number;
  
  // Determine final values
  const finalDepositStatus = updates.depositStatus || currentDepositStatus;
  const finalReturnTime = updates.returnTime ? updates.returnTime.toISOString() : currentReturnTime;
  const finalPaymentMethod = updates.paymentMethod || currentPaymentMethod;
  const finalBusinessDay = updates.businessDay || currentBusinessDay;
  const finalPaymentCash = updates.paymentCash !== undefined ? updates.paymentCash : currentPaymentCash;
  const finalPaymentCard = updates.paymentCard !== undefined ? updates.paymentCard : currentPaymentCard;
  const finalPaymentTransfer = updates.paymentTransfer !== undefined ? updates.paymentTransfer : currentPaymentTransfer;
  
  // Calculate business days for rental and return times
  const rentalBusinessDay = getBusinessDay(new Date(rentalTime as string), businessDayStartHour);
  const returnBusinessDay = finalReturnTime ? getBusinessDay(new Date(finalReturnTime as string), businessDayStartHour) : rentalBusinessDay;
  
  // Calculate revenue based on deposit status
  let revenue = updates.revenue !== undefined ? updates.revenue : rentalFee;
  let adjustedPaymentCash = finalPaymentCash;
  let adjustedPaymentCard = finalPaymentCard;
  let adjustedPaymentTransfer = finalPaymentTransfer;
  
  // Calculate target revenue if not provided
  if (updates.revenue === undefined) {
    if (finalDepositStatus === 'received') {
      revenue += depositAmount; // 대여 시: 렌탈비 + 보증금
    } else if (finalDepositStatus === 'forfeited') {
      // 몰수 시 영업일 비교 (rental_time과 return_time의 영업일 비교)
      if (rentalBusinessDay === returnBusinessDay) {
        revenue += depositAmount; // 같은 영업일: 렌탈비 + 보증금
      }
      // 다른 영업일: 렌탈비만 (보증금은 이미 대여일 매출)
    }
    // refunded: 렌탈비만
  }
  
  // Always adjust payment amounts proportionally to match revenue exactly
  // (revenue가 명시적으로 전달되어도 payment* 필드 조정)
  const cashNum = Number(currentPaymentCash) || 0;
  const cardNum = Number(currentPaymentCard) || 0;
  const transferNum = Number(currentPaymentTransfer) || 0;
  const originalTotal = cashNum + cardNum + transferNum;
  
  if (originalTotal > 0 && revenue !== originalTotal) {
    const ratio = revenue / originalTotal;
    // Floor all channels first
    adjustedPaymentCash = Math.floor(cashNum * ratio);
    adjustedPaymentCard = Math.floor(cardNum * ratio);
    adjustedPaymentTransfer = Math.floor(transferNum * ratio);
    
    // Calculate remainder and assign to channel with largest original amount
    const remainder = revenue - adjustedPaymentCash - adjustedPaymentCard - adjustedPaymentTransfer;
    if (remainder !== 0) {
      const amounts = [
        { value: cashNum, index: 'cash' as const },
        { value: cardNum, index: 'card' as const },
        { value: transferNum, index: 'transfer' as const }
      ];
      const largest = amounts.reduce((max, curr) => curr.value > max.value ? curr : max);
      
      if (largest.index === 'cash') adjustedPaymentCash += remainder;
      else if (largest.index === 'card') adjustedPaymentCard += remainder;
      else adjustedPaymentTransfer += remainder;
    }
  }
  
  // Create expense for cross-day refunds (다른 영업일 환급 시 지출 생성)
  const isRefunding = currentDepositStatus !== 'refunded' && finalDepositStatus === 'refunded';
  const isCrossDay = rentalBusinessDay !== returnBusinessDay;
  
  if (isRefunding && isCrossDay && depositAmount > 0 && finalReturnTime) {
    // 보증금환급 카테고리 찾기
    const categories = getExpenseCategories();
    const refundCategory = categories.find(c => c.name === '보증금환급');
    
    if (refundCategory) {
      const refundTime = new Date(finalReturnTime as string);
      const timeStr = refundTime.toTimeString().slice(0, 5); // HH:MM
      const paymentMethodForExpense = (finalPaymentMethod as 'cash' | 'card' | 'transfer') || 'cash';
      
      // 지출 자동 생성
      createExpense({
        date: returnBusinessDay,
        time: timeStr,
        category: refundCategory.name,
        amount: depositAmount,
        quantity: 1,
        paymentMethod: paymentMethodForExpense,
        paymentCash: paymentMethodForExpense === 'cash' ? depositAmount : undefined,
        paymentCard: paymentMethodForExpense === 'card' ? depositAmount : undefined,
        paymentTransfer: paymentMethodForExpense === 'transfer' ? depositAmount : undefined,
        businessDay: returnBusinessDay,
        notes: `${itemName} 보증금 환급 (락커 ${lockerNumber})`,
      });
    }
  }
  
  // Handle return_completed update
  const returnCompletedValue = updates.returnCompleted !== undefined ? (updates.returnCompleted ? 1 : 0) : null;
  
  if (returnCompletedValue !== null) {
    db.run(
      `UPDATE rental_transactions 
       SET deposit_status = ?, revenue = ?, return_time = ?, payment_method = ?, business_day = ?, 
           payment_cash = ?, payment_card = ?, payment_transfer = ?, return_completed = ?, updated_at = ?
       WHERE id = ?`,
      [finalDepositStatus, revenue, finalReturnTime, finalPaymentMethod, finalBusinessDay, 
       adjustedPaymentCash, adjustedPaymentCard, adjustedPaymentTransfer, returnCompletedValue, new Date().toISOString(), id]
    );
  } else {
    db.run(
      `UPDATE rental_transactions 
       SET deposit_status = ?, revenue = ?, return_time = ?, payment_method = ?, business_day = ?, 
           payment_cash = ?, payment_card = ?, payment_transfer = ?, updated_at = ?
       WHERE id = ?`,
      [finalDepositStatus, revenue, finalReturnTime, finalPaymentMethod, finalBusinessDay, 
       adjustedPaymentCash, adjustedPaymentCard, adjustedPaymentTransfer, new Date().toISOString(), id]
    );
  }
  
  saveDatabaseDebounced();
}

export function deleteRentalTransaction(id: string): void {
  if (!db) throw new Error('Database not initialized');
  db.run('DELETE FROM rental_transactions WHERE id = ?', [id]);
  saveDatabaseDebounced();
}

export function getRentalTransactionsByLockerLog(lockerLogId: string) {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(
    `SELECT * FROM rental_transactions WHERE locker_log_id = ? ORDER BY created_at DESC`,
    [lockerLogId]
  );
  
  if (result.length === 0) return [];
  
  return rowsToObjects(result[0]);
}

/**
 * 날짜 범위로 렌탈 거래 조회 (rental_time 기준)
 * 입출기록 페이지의 날짜 필터링용 - 해당 기간에 대여한 거래만 반환
 */
export function getRentalTransactionsByDateRange(startDate: string, endDate: string) {
  if (!db) throw new Error('Database not initialized');
  
  // Convert dates to datetime range in local timezone, then to ISO for storage comparison
  const startDateTime = new Date(startDate + 'T00:00:00').toISOString();
  const endDateTime = new Date(endDate + 'T23:59:59.999').toISOString();
  
  const result = db.exec(
    `SELECT * FROM rental_transactions 
     WHERE rental_time >= ? AND rental_time <= ?
     ORDER BY rental_time DESC`,
    [startDateTime, endDateTime]
  );
  
  if (result.length === 0 || result[0].values.length === 0) return [];
  
  return result[0].values.map((row: any) => ({
    id: row[0],
    lockerLogId: row[1],
    itemId: row[2],
    itemName: row[3],
    lockerNumber: row[4],
    rentalTime: row[5],
    returnTime: row[6],
    businessDay: row[7],
    rentalFee: row[8],
    depositAmount: row[9],
    paymentMethod: row[10],
    paymentCash: row[11],
    paymentCard: row[12],
    paymentTransfer: row[13],
    depositStatus: row[14],
    revenue: row[15],
  }));
}

/**
 * 시간 범위로 렌탈 거래 조회 (rental_time 기준)
 * 입출기록 페이지의 시간 필터링용 - 해당 시간대에 대여한 거래만 반환
 */
export function getRentalTransactionsByDateTimeRange(startDateTime: string, endDateTime: string) {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(
    `SELECT * FROM rental_transactions 
     WHERE rental_time >= ? AND rental_time <= ?
     ORDER BY rental_time DESC`,
    [startDateTime, endDateTime]
  );
  
  if (result.length === 0 || result[0].values.length === 0) return [];
  
  return result[0].values.map((row: any) => ({
    id: row[0],
    lockerLogId: row[1],
    itemId: row[2],
    itemName: row[3],
    lockerNumber: row[4],
    rentalTime: row[5],
    returnTime: row[6],
    businessDay: row[7],
    rentalFee: row[8],
    depositAmount: row[9],
    paymentMethod: row[10],
    paymentCash: row[11],
    paymentCard: row[12],
    paymentTransfer: row[13],
    depositStatus: row[14],
    revenue: row[15],
  }));
}

/**
 * 특정 비즈니스 데이의 모든 렌탈 거래 조회
 * @param businessDay YYYY-MM-DD 형식의 비즈니스 데이
 * @param businessDayStartHour 비즈니스 데이 시작 시각 (기본값: 10)
 */
/**
 * 모든 렌탈 거래 조회 (전체)
 */
export function getAllRentalTransactions() {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec('SELECT * FROM rental_transactions ORDER BY rental_time DESC');
  
  if (result.length === 0 || result[0].values.length === 0) return [];
  
  return result[0].values.map((row: any) => ({
    id: row[0],
    lockerLogId: row[1],
    itemId: row[2],
    itemName: row[3],
    lockerNumber: row[4],
    rentalTime: row[5],
    returnTime: row[6],
    businessDay: row[7],
    rentalFee: row[8],
    depositAmount: row[9],
    paymentMethod: row[10],
    paymentCash: row[11],
    paymentCard: row[12],
    paymentTransfer: row[13],
    depositStatus: row[14],
    revenue: row[15],
  }));
}

export function getRentalTransactionsByBusinessDayRange(businessDay: string, businessDayStartHour: number = 10) {
  if (!db) throw new Error('Database not initialized');
  
  // 비즈니스 데이 범위 계산 - 영업일 시작 시각을 기준 시간으로 사용 (T12:00:00 고정값은 영업일이 12시 이후 시작인 경우 오동작)
  const { start, end } = getBusinessDayRange(new Date(businessDay + 'T' + String(businessDayStartHour).padStart(2, '0') + ':00:00'), businessDayStartHour);
  
  // Convert to Unix timestamps (seconds) for reliable numeric comparison
  const startUnix = Math.floor(start.getTime() / 1000);
  const endUnix = Math.floor(end.getTime() / 1000);
  
  const result = db.exec(
    `SELECT * FROM rental_transactions 
     WHERE strftime('%s', rental_time) >= ? AND strftime('%s', rental_time) <= ?
     ORDER BY rental_time DESC`,
    [startUnix.toString(), endUnix.toString()]
  );
  
  if (result.length === 0 || result[0].values.length === 0) return [];
  
  return result[0].values.map((row: any) => ({
    id: row[0],
    lockerLogId: row[1],
    itemId: row[2],
    itemName: row[3],
    lockerNumber: row[4],
    rentalTime: row[5],
    returnTime: row[6],
    businessDay: row[7],
    rentalFee: row[8],
    depositAmount: row[9],
    paymentMethod: row[10],
    paymentCash: row[11],
    paymentCard: row[12],
    paymentTransfer: row[13],
    depositStatus: row[14],
    revenue: row[15],
  }));
}

// ============================================
// Expenses (지출) Functions
// ============================================

export function createExpense(data: {
  date: string;
  time: string;
  category: string;
  amount: number;
  quantity?: number;
  paymentMethod: 'card' | 'cash' | 'transfer';
  paymentCash?: number;
  paymentCard?: number;
  paymentTransfer?: number;
  businessDay: string;
  notes?: string;
}) {
  if (!db) throw new Error('Database not initialized');
  
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  
  db.run(
    `INSERT INTO expenses (id, date, time, category, amount, quantity, payment_method, 
     payment_cash, payment_card, payment_transfer, business_day, notes, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      id,
      data.date,
      data.time,
      data.category,
      data.amount,
      data.quantity || 1,
      data.paymentMethod,
      data.paymentCash || null,
      data.paymentCard || null,
      data.paymentTransfer || null,
      data.businessDay,
      data.notes || null,
      now
    ]
  );
  
  saveDatabaseDebounced();
  return id;
}

export function getExpenses() {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(`SELECT * FROM expenses ORDER BY date DESC, time DESC`);
  
  if (result.length === 0 || result[0].values.length === 0) return [];
  
  return result[0].values.map((row: any) => ({
    id: row[0],
    date: row[1],
    time: row[2],
    category: row[3],
    amount: row[4],
    quantity: row[5],
    paymentMethod: row[6],
    businessDay: row[7],
    notes: row[8],
    createdAt: row[9],
  }));
}

export function getExpensesByDateRange(startDate: string, endDate: string) {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(
    `SELECT * FROM expenses 
     WHERE date >= ? AND date <= ?
     ORDER BY date DESC, time DESC`,
    [startDate, endDate]
  );
  
  if (result.length === 0 || result[0].values.length === 0) return [];
  
  return result[0].values.map((row: any) => ({
    id: row[0],
    date: row[1],
    time: row[2],
    category: row[3],
    amount: row[4],
    quantity: row[5],
    paymentMethod: row[6],
    businessDay: row[7],
    notes: row[8],
    createdAt: row[9],
  }));
}

export function getExpensesByBusinessDay(businessDay: string) {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(
    `SELECT * FROM expenses WHERE business_day = ? ORDER BY date DESC, time DESC`,
    [businessDay]
  );
  
  if (result.length === 0 || result[0].values.length === 0) return [];
  
  return result[0].values.map((row: any) => ({
    id: row[0],
    date: row[1],
    time: row[2],
    category: row[3],
    amount: row[4],
    quantity: row[5],
    paymentMethod: row[6],
    businessDay: row[7],
    notes: row[8],
    createdAt: row[9],
  }));
}

export function getExpenseSummaryByBusinessDay(businessDay: string) {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(
    `SELECT 
       SUM(CASE WHEN payment_method = 'cash' THEN amount ELSE 0 END) as cash_total,
       SUM(CASE WHEN payment_method = 'card' THEN amount ELSE 0 END) as card_total,
       SUM(CASE WHEN payment_method = 'transfer' THEN amount ELSE 0 END) as transfer_total,
       SUM(amount) as total
     FROM expenses 
     WHERE business_day = ?`,
    [businessDay]
  );
  
  if (result.length === 0 || result[0].values.length === 0) {
    return { cashTotal: 0, cardTotal: 0, transferTotal: 0, total: 0 };
  }
  
  const row = result[0].values[0];
  return {
    cashTotal: row[0] || 0,
    cardTotal: row[1] || 0,
    transferTotal: row[2] || 0,
    total: row[3] || 0,
  };
}

export function updateExpense(id: string, updates: {
  date?: string;
  time?: string;
  category?: string;
  amount?: number;
  quantity?: number;
  paymentMethod?: 'card' | 'cash' | 'transfer';
  businessDay?: string;
  notes?: string;
}) {
  if (!db) throw new Error('Database not initialized');
  
  const fields: string[] = [];
  const values: any[] = [];
  
  if (updates.date !== undefined) {
    fields.push('date = ?');
    values.push(updates.date);
  }
  if (updates.time !== undefined) {
    fields.push('time = ?');
    values.push(updates.time);
  }
  if (updates.category !== undefined) {
    fields.push('category = ?');
    values.push(updates.category);
  }
  if (updates.amount !== undefined) {
    fields.push('amount = ?');
    values.push(updates.amount);
  }
  if (updates.quantity !== undefined) {
    fields.push('quantity = ?');
    values.push(updates.quantity);
  }
  if (updates.paymentMethod !== undefined) {
    fields.push('payment_method = ?');
    values.push(updates.paymentMethod);
  }
  if (updates.businessDay !== undefined) {
    fields.push('business_day = ?');
    values.push(updates.businessDay);
  }
  if (updates.notes !== undefined) {
    fields.push('notes = ?');
    values.push(updates.notes);
  }
  
  if (fields.length === 0) return;
  
  values.push(id);
  
  db.run(
    `UPDATE expenses SET ${fields.join(', ')} WHERE id = ?`,
    values
  );
  
  saveDatabaseDebounced();
}

export function deleteExpense(id: string) {
  if (!db) throw new Error('Database not initialized');
  
  db.run('DELETE FROM expenses WHERE id = ?', [id]);
  saveDatabaseDebounced();
}

// ============================================
// Closing Days (정산) Functions
// ============================================

export function createClosingDay(data: {
  businessDay: string;
  startTime: string;
  endTime: string;
  openingFloat: number;
  targetFloat: number;
  actualCash?: number;
  expectedCash?: number;
  discrepancy?: number;
  bankDeposit?: number;
  notes?: string;
  memo?: string;
}) {
  if (!db) throw new Error('Database not initialized');
  
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  
  db.run(
    `INSERT INTO closing_days 
     (id, business_day, start_time, end_time, opening_float, target_float, 
      actual_cash, expected_cash, discrepancy, bank_deposit, notes, memo, is_confirmed, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)`,
    [
      id,
      data.businessDay,
      data.startTime,
      data.endTime,
      data.openingFloat,
      data.targetFloat,
      data.actualCash || null,
      data.expectedCash || null,
      data.discrepancy || 0,
      data.bankDeposit || null,
      data.notes || null,
      data.memo || null,
      now,
      now
    ]
  );
  
  saveDatabaseDebounced();
  return id;
}

export function getClosingDay(businessDay: string) {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(
    `SELECT * FROM closing_days WHERE business_day = ?`,
    [businessDay]
  );
  
  if (result.length === 0 || result[0].values.length === 0) return null;
  
  const row = result[0].values[0];
  return {
    id: row[0],
    businessDay: row[1],
    startTime: row[2],
    endTime: row[3],
    openingFloat: row[4],
    targetFloat: row[5],
    actualCash: row[6],
    expectedCash: row[7],
    discrepancy: row[8],
    bankDeposit: row[9],
    notes: row[10],
    memo: row[11],
    isConfirmed: row[12] === 1,
    confirmedAt: row[13],
    createdAt: row[14],
    updatedAt: row[15],
  };
}

export function getClosingDays() {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(`SELECT * FROM closing_days ORDER BY business_day DESC`);
  
  if (result.length === 0 || result[0].values.length === 0) return [];
  
  return result[0].values.map((row: any) => ({
    id: row[0],
    businessDay: row[1],
    startTime: row[2],
    endTime: row[3],
    openingFloat: row[4],
    targetFloat: row[5],
    actualCash: row[6],
    expectedCash: row[7],
    discrepancy: row[8],
    bankDeposit: row[9],
    notes: row[10],
    isConfirmed: row[11] === 1,
    confirmedAt: row[12],
    createdAt: row[13],
    updatedAt: row[14],
  }));
}

export function getLatestClosingDay() {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(
    `SELECT * FROM closing_days ORDER BY business_day DESC LIMIT 1`
  );
  
  if (result.length === 0 || result[0].values.length === 0) return null;
  
  const row = result[0].values[0];
  return {
    id: row[0],
    businessDay: row[1],
    startTime: row[2],
    endTime: row[3],
    openingFloat: row[4],
    targetFloat: row[5],
    actualCash: row[6],
    expectedCash: row[7],
    discrepancy: row[8],
    bankDeposit: row[9],
    notes: row[10],
    memo: row[11],
    isConfirmed: row[12] === 1,
    confirmedAt: row[13],
    createdAt: row[14],
    updatedAt: row[15],
  };
}

export function updateClosingDay(businessDay: string, updates: {
  startTime?: string;
  endTime?: string;
  openingFloat?: number;
  targetFloat?: number;
  actualCash?: number;
  expectedCash?: number;
  discrepancy?: number;
  bankDeposit?: number;
  notes?: string;
  memo?: string;
}) {
  if (!db) throw new Error('Database not initialized');
  
  const fields: string[] = [];
  const values: any[] = [];

  if (updates.startTime !== undefined) {
    fields.push('start_time = ?');
    values.push(updates.startTime);
  }
  if (updates.endTime !== undefined) {
    fields.push('end_time = ?');
    values.push(updates.endTime);
  }
  if (updates.openingFloat !== undefined) {
    fields.push('opening_float = ?');
    values.push(updates.openingFloat);
  }
  if (updates.targetFloat !== undefined) {
    fields.push('target_float = ?');
    values.push(updates.targetFloat);
  }
  if (updates.actualCash !== undefined) {
    fields.push('actual_cash = ?');
    values.push(updates.actualCash);
  }
  if (updates.expectedCash !== undefined) {
    fields.push('expected_cash = ?');
    values.push(updates.expectedCash);
  }
  if (updates.discrepancy !== undefined) {
    fields.push('discrepancy = ?');
    values.push(updates.discrepancy);
  }
  if (updates.bankDeposit !== undefined) {
    fields.push('bank_deposit = ?');
    values.push(updates.bankDeposit);
  }
  if (updates.notes !== undefined) {
    fields.push('notes = ?');
    values.push(updates.notes);
  }
  if (updates.memo !== undefined) {
    fields.push('memo = ?');
    values.push(updates.memo);
  }
  
  if (fields.length === 0) return;
  
  fields.push('updated_at = ?');
  values.push(new Date().toISOString());
  
  values.push(businessDay);
  
  db.run(
    `UPDATE closing_days SET ${fields.join(', ')} WHERE business_day = ?`,
    values
  );
  
  saveDatabaseDebounced();
}

export function confirmClosingDay(businessDay: string) {
  if (!db) throw new Error('Database not initialized');
  
  const now = new Date().toISOString();
  
  db.run(
    `UPDATE closing_days 
     SET is_confirmed = 1, confirmed_at = ?, updated_at = ?
     WHERE business_day = ?`,
    [now, now, businessDay]
  );
  
  saveDatabaseDebounced();
}

// Get detailed sales breakdown by business day (using business day RANGE for accurate aggregation)
export function getDetailedSalesByBusinessDay(businessDay: string) {
  if (!db) throw new Error('Database not initialized');
  
  // Get UTC start/end timestamps for the business day range
  const settings = getSettings();
  const { start, end } = getBusinessDayRange(new Date(businessDay + 'T' + String(settings.businessDayStartHour).padStart(2, '0') + ':00:00'), settings.businessDayStartHour);
  
  // Convert to Unix timestamps (seconds) for reliable numeric comparison
  const startUnix = Math.floor(start.getTime() / 1000);
  const endUnix = Math.floor(end.getTime() / 1000);
  
  // Get base entry sales (입실 기본요금) - filter by entry_time within business day range
  const entryResult = db.exec(
    `SELECT 
      COALESCE(SUM(CASE WHEN status != 'cancelled' THEN COALESCE(payment_cash, 0) ELSE 0 END), 0) as cash_total,
      COALESCE(SUM(CASE WHEN status != 'cancelled' THEN COALESCE(payment_card, 0) ELSE 0 END), 0) as card_total,
      COALESCE(SUM(CASE WHEN status != 'cancelled' THEN COALESCE(payment_transfer, 0) ELSE 0 END), 0) as transfer_total
     FROM locker_logs
     WHERE strftime('%s', entry_time) >= ? AND strftime('%s', entry_time) <= ?`,
    [startUnix.toString(), endUnix.toString()]
  );
  
  const entrySales = {
    cash: 0,
    card: 0,
    transfer: 0,
    total: 0
  };
  
  if (entryResult.length > 0 && entryResult[0].values.length > 0) {
    const row = entryResult[0].values[0];
    entrySales.cash = row[0] as number || 0;
    entrySales.card = row[1] as number || 0;
    entrySales.transfer = row[2] as number || 0;
    entrySales.total = entrySales.cash + entrySales.card + entrySales.transfer;
  }
  
  // Get additional fee sales (추가요금) - filter by checkout_time within business day range
  const additionalResult = db.exec(
    `SELECT 
      COALESCE(SUM(COALESCE(payment_cash, 0)), 0) as cash_total,
      COALESCE(SUM(COALESCE(payment_card, 0)), 0) as card_total,
      COALESCE(SUM(COALESCE(payment_transfer, 0)), 0) as transfer_total
     FROM additional_fee_events
     WHERE strftime('%s', checkout_time) >= ? AND strftime('%s', checkout_time) <= ?`,
    [startUnix.toString(), endUnix.toString()]
  );
  
  const additionalSales = {
    cash: 0,
    card: 0,
    transfer: 0,
    total: 0
  };
  
  if (additionalResult.length > 0 && additionalResult[0].values.length > 0) {
    const row = additionalResult[0].values[0];
    additionalSales.cash = row[0] as number || 0;
    additionalSales.card = row[1] as number || 0;
    additionalSales.transfer = row[2] as number || 0;
    additionalSales.total = additionalSales.cash + additionalSales.card + additionalSales.transfer;
  }
  
  return {
    entrySales,
    additionalSales,
    totalEntrySales: {
      cash: entrySales.cash + additionalSales.cash,
      card: entrySales.card + additionalSales.card,
      transfer: entrySales.transfer + additionalSales.transfer,
      total: entrySales.total + additionalSales.total
    }
  };
}

// Get rental revenue breakdown by business day
export function getRentalRevenueBreakdownByBusinessDay(businessDay: string) {
  if (!db) throw new Error('Database not initialized');
  
  // Get all rental items
  const items = getAdditionalRevenueItems();
  
  const breakdown: {
    [itemName: string]: {
      rentalFee: { cash: number; card: number; transfer: number; total: number };
      depositForfeited: { cash: number; card: number; transfer: number; total: number };
      depositAmount: number;
    }
  } = {};
  
  items.forEach(item => {
    breakdown[item.name] = {
      rentalFee: { cash: 0, card: 0, transfer: 0, total: 0 },
      depositForfeited: { cash: 0, card: 0, transfer: 0, total: 0 },
      depositAmount: 0  // Will be set to the max deposit amount found in transactions
    };
  });
  
  // Get UTC start/end timestamps for the business day range
  const settings = getSettings();
  const { start, end } = getBusinessDayRange(new Date(businessDay + 'T' + String(settings.businessDayStartHour).padStart(2, '0') + ':00:00'), settings.businessDayStartHour);
  
  // Convert to Unix timestamps (seconds) for reliable numeric comparison
  const startUnix = Math.floor(start.getTime() / 1000);
  const endUnix = Math.floor(end.getTime() / 1000);
  
  // Get rental transactions for this business day - filter by rental_time within business day range
  const result = db.exec(
    `SELECT 
      item_name,
      rental_fee,
      deposit_amount,
      deposit_status,
      COALESCE(payment_cash, 0) as payment_cash,
      COALESCE(payment_card, 0) as payment_card,
      COALESCE(payment_transfer, 0) as payment_transfer,
      payment_method,
      rental_time,
      return_time,
      business_day
     FROM rental_transactions
     WHERE strftime('%s', rental_time) >= ? AND strftime('%s', rental_time) <= ?`,
    [startUnix.toString(), endUnix.toString()]
  );
  
  if (result.length > 0 && result[0].values.length > 0) {
    result[0].values.forEach((row: any) => {
      const itemName = row[0] as string;
      const rentalFee = row[1] as number;
      const depositAmount = row[2] as number;
      const depositStatus = row[3] as string;
      const paymentCash = row[4] as number;
      const paymentCard = row[5] as number;
      const paymentTransfer = row[6] as number;
      const paymentMethod = row[7] as string | null;
      const rentalTime = row[8] as string;
      const returnTime = row[9] as string | null;
      const rentalBusinessDay = row[10] as string;
      
      if (!breakdown[itemName]) {
        breakdown[itemName] = {
          rentalFee: { cash: 0, card: 0, transfer: 0, total: 0 },
          depositForfeited: { cash: 0, card: 0, transfer: 0, total: 0 },
          depositAmount: depositAmount
        };
      } else {
        // Update depositAmount to the maximum found (for display purposes)
        if (depositAmount > breakdown[itemName].depositAmount) {
          breakdown[itemName].depositAmount = depositAmount;
        }
      }
      
      // Calculate total revenue for this transaction
      let totalRevenue = rentalFee;
      if (depositStatus === 'received') {
        // 대여 시: 렌탈비 + 보증금
        totalRevenue += depositAmount;
      } else if (depositStatus === 'forfeited' && returnTime) {
        // 몰수 시: 영업일 비교
        const returnBusinessDay = getBusinessDay(new Date(returnTime), settings.businessDayStartHour);
        if (rentalBusinessDay === returnBusinessDay) {
          // 같은 영업일: 렌탈비 + 보증금
          totalRevenue += depositAmount;
        }
        // 다른 영업일: 렌탈비만 (보증금은 이미 대여일 매출)
      }
      
      // For refunded deposits, exclude deposit from payment calculation
      // payment_cash/card/transfer may include deposit that was refunded, so we need to subtract it
      let effectivePaymentCash = paymentCash;
      let effectivePaymentCard = paymentCard;
      let effectivePaymentTransfer = paymentTransfer;
      
      if (depositStatus === 'refunded') {
        // Original payment included deposit, but it was refunded
        // So we need to subtract deposit from the total payment to get only rental fee payment
        const totalPayment = paymentCash + paymentCard + paymentTransfer;
        if (totalPayment > 0 && depositAmount > 0) {
          // Proportionally reduce each payment method by deposit amount
          const depositRatio = depositAmount / totalPayment;
          effectivePaymentCash = Math.round(paymentCash * (1 - depositRatio));
          effectivePaymentCard = Math.round(paymentCard * (1 - depositRatio));
          effectivePaymentTransfer = Math.round(paymentTransfer * (1 - depositRatio));
        }
      }
      
      const totalPayment = effectivePaymentCash + effectivePaymentCard + effectivePaymentTransfer;
      
      if (totalRevenue > 0 && totalPayment > 0) {
        // Calculate rental fee portion
        const rentalFeeRatio = rentalFee / totalRevenue;
        breakdown[itemName].rentalFee.cash += Math.round(effectivePaymentCash * rentalFeeRatio);
        breakdown[itemName].rentalFee.card += Math.round(effectivePaymentCard * rentalFeeRatio);
        breakdown[itemName].rentalFee.transfer += Math.round(effectivePaymentTransfer * rentalFeeRatio);
        breakdown[itemName].rentalFee.total += rentalFee;
        
        // Calculate deposit portion (only when included in totalRevenue)
        const depositIncluded = (depositStatus === 'received') || 
          (depositStatus === 'forfeited' && returnTime && rentalBusinessDay === getBusinessDay(new Date(returnTime), settings.businessDayStartHour));
        
        if (depositIncluded && totalRevenue > rentalFee) {
          const depositRatio = depositAmount / totalRevenue;
          breakdown[itemName].depositForfeited.cash += Math.round(effectivePaymentCash * depositRatio);
          breakdown[itemName].depositForfeited.card += Math.round(effectivePaymentCard * depositRatio);
          breakdown[itemName].depositForfeited.transfer += Math.round(effectivePaymentTransfer * depositRatio);
          breakdown[itemName].depositForfeited.total += depositAmount;
        }
      } else if (totalRevenue > 0 && paymentMethod) {
        // Legacy data fallback: Use payment_method to allocate revenue
        // This handles old data where payment_cash/card/transfer weren't populated
        const depositIncluded = (depositStatus === 'received') || 
          (depositStatus === 'forfeited' && returnTime && rentalBusinessDay === getBusinessDay(new Date(returnTime), settings.businessDayStartHour));
        
        if (paymentMethod === 'cash') {
          breakdown[itemName].rentalFee.cash += rentalFee;
          if (depositIncluded) {
            breakdown[itemName].depositForfeited.cash += depositAmount;
          }
        } else if (paymentMethod === 'card') {
          breakdown[itemName].rentalFee.card += rentalFee;
          if (depositIncluded) {
            breakdown[itemName].depositForfeited.card += depositAmount;
          }
        } else if (paymentMethod === 'transfer') {
          breakdown[itemName].rentalFee.transfer += rentalFee;
          if (depositIncluded) {
            breakdown[itemName].depositForfeited.transfer += depositAmount;
          }
        }
        breakdown[itemName].rentalFee.total += rentalFee;
        if (depositIncluded) {
          breakdown[itemName].depositForfeited.total += depositAmount;
        }
      } else {
        // Last resort fallback: just add totals without payment method breakdown
        const depositIncluded = (depositStatus === 'received') || 
          (depositStatus === 'forfeited' && returnTime && rentalBusinessDay === getBusinessDay(new Date(returnTime), settings.businessDayStartHour));
        
        breakdown[itemName].rentalFee.total += rentalFee;
        if (depositIncluded) {
          breakdown[itemName].depositForfeited.total += depositAmount;
        }
      }
    });
  }
  
  // Calculate totals
  const totals = {
    rentalFee: { cash: 0, card: 0, transfer: 0, total: 0 },
    depositForfeited: { cash: 0, card: 0, transfer: 0, total: 0 },
    grandTotal: { cash: 0, card: 0, transfer: 0, total: 0 }
  };
  
  Object.values(breakdown).forEach(item => {
    totals.rentalFee.cash += item.rentalFee.cash;
    totals.rentalFee.card += item.rentalFee.card;
    totals.rentalFee.transfer += item.rentalFee.transfer;
    totals.rentalFee.total += item.rentalFee.total;
    
    totals.depositForfeited.cash += item.depositForfeited.cash;
    totals.depositForfeited.card += item.depositForfeited.card;
    totals.depositForfeited.transfer += item.depositForfeited.transfer;
    totals.depositForfeited.total += item.depositForfeited.total;
  });
  
  totals.grandTotal.cash = totals.rentalFee.cash + totals.depositForfeited.cash;
  totals.grandTotal.card = totals.rentalFee.card + totals.depositForfeited.card;
  totals.grandTotal.transfer = totals.rentalFee.transfer + totals.depositForfeited.transfer;
  totals.grandTotal.total = totals.rentalFee.total + totals.depositForfeited.total;
  
  return {
    breakdown,
    totals
  };
}

// Get detailed sales summary for a range of business days
export function getDetailedSalesByBusinessDayRange(startBusinessDay: string, endBusinessDay: string) {
  if (!db) throw new Error('Database not initialized');
  
  // Get UTC start/end timestamps for the business day range
  const settings = getSettings();
  const refHour = String(settings.businessDayStartHour).padStart(2, '0');
  const startDate = new Date(startBusinessDay + 'T' + refHour + ':00:00');
  const endDate = new Date(endBusinessDay + 'T' + refHour + ':00:00');
  
  const { start: rangeStart } = getBusinessDayRange(startDate, settings.businessDayStartHour);
  const { end: rangeEnd } = getBusinessDayRange(endDate, settings.businessDayStartHour);
  
  // Convert to Unix timestamps (seconds) for reliable numeric comparison
  const startUnix = Math.floor(rangeStart.getTime() / 1000);
  const endUnix = Math.floor(rangeEnd.getTime() / 1000);
  
  // Get base entry sales (입실 기본요금) - filter by entry_time within range
  const entryResult = db.exec(
    `SELECT 
      COALESCE(SUM(CASE WHEN status != 'cancelled' THEN COALESCE(payment_cash, 0) ELSE 0 END), 0) as cash_total,
      COALESCE(SUM(CASE WHEN status != 'cancelled' THEN COALESCE(payment_card, 0) ELSE 0 END), 0) as card_total,
      COALESCE(SUM(CASE WHEN status != 'cancelled' THEN COALESCE(payment_transfer, 0) ELSE 0 END), 0) as transfer_total
     FROM locker_logs
     WHERE strftime('%s', entry_time) >= ? AND strftime('%s', entry_time) <= ?`,
    [startUnix.toString(), endUnix.toString()]
  );
  
  const entrySales = {
    cash: 0,
    card: 0,
    transfer: 0,
    total: 0
  };
  
  if (entryResult.length > 0 && entryResult[0].values.length > 0) {
    const row = entryResult[0].values[0];
    entrySales.cash = row[0] as number;
    entrySales.card = row[1] as number;
    entrySales.transfer = row[2] as number;
    entrySales.total = entrySales.cash + entrySales.card + entrySales.transfer;
  }
  
  // Get additional fee sales (추가요금) - filter by checkout_time within range
  const additionalResult = db.exec(
    `SELECT 
      COALESCE(SUM(COALESCE(payment_cash, 0)), 0) as cash_total,
      COALESCE(SUM(COALESCE(payment_card, 0)), 0) as card_total,
      COALESCE(SUM(COALESCE(payment_transfer, 0)), 0) as transfer_total
     FROM additional_fee_events
     WHERE strftime('%s', checkout_time) >= ? AND strftime('%s', checkout_time) <= ?`,
    [startUnix.toString(), endUnix.toString()]
  );
  
  const additionalSales = {
    cash: 0,
    card: 0,
    transfer: 0,
    total: 0
  };
  
  if (additionalResult.length > 0 && additionalResult[0].values.length > 0) {
    const row = additionalResult[0].values[0];
    additionalSales.cash = row[0] as number;
    additionalSales.card = row[1] as number;
    additionalSales.transfer = row[2] as number;
    additionalSales.total = additionalSales.cash + additionalSales.card + additionalSales.transfer;
  }
  
  // Get rental sales (대여물품 매출) - filter by rental_time within range
  const rentalResult = db.exec(
    `SELECT 
      COALESCE(SUM(CASE WHEN deposit_status = 'received' OR deposit_status = 'refunded' THEN COALESCE(payment_cash, 0) ELSE 0 END), 0) as cash_total,
      COALESCE(SUM(CASE WHEN deposit_status = 'received' OR deposit_status = 'refunded' THEN COALESCE(payment_card, 0) ELSE 0 END), 0) as card_total,
      COALESCE(SUM(CASE WHEN deposit_status = 'received' OR deposit_status = 'refunded' THEN COALESCE(payment_transfer, 0) ELSE 0 END), 0) as transfer_total
     FROM rental_transactions
     WHERE strftime('%s', rental_time) >= ? AND strftime('%s', rental_time) <= ?`,
    [startUnix.toString(), endUnix.toString()]
  );
  
  const rentalSales = {
    cash: 0,
    card: 0,
    transfer: 0,
    total: 0
  };
  
  if (rentalResult.length > 0 && rentalResult[0].values.length > 0) {
    const row = rentalResult[0].values[0];
    rentalSales.cash = row[0] as number;
    rentalSales.card = row[1] as number;
    rentalSales.transfer = row[2] as number;
    rentalSales.total = rentalSales.cash + rentalSales.card + rentalSales.transfer;
  }
  
  return {
    entrySales,
    additionalSales,
    rentalSales,
    totalEntrySales: {
      cash: entrySales.cash + additionalSales.cash,
      card: entrySales.card + additionalSales.card,
      transfer: entrySales.transfer + additionalSales.transfer,
      total: entrySales.total + additionalSales.total
    }
  };
}

// Expense Categories operations
export function getExpenseCategories() {
  if (!db) throw new Error('Database not initialized');
  
  // Ensure expense_categories table exists
  ensureExpenseCategoriesTable();
  
  const result = db.exec('SELECT * FROM expense_categories ORDER BY sort_order ASC, name ASC');
  
  if (result.length === 0) return [];
  
  return rowsToObjects(result[0]);
}

// Helper function to ensure expense_categories table exists
function ensureExpenseCategoriesTable() {
  if (!db) return;
  
  // Create table if not exists
  db.run(`
    CREATE TABLE IF NOT EXISTS expense_categories (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL UNIQUE,
      is_default INTEGER NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL DEFAULT 999,
      created_at TEXT NOT NULL
    )
  `);
  
  // Check if table has any records
  const countResult = db.exec(`SELECT COUNT(*) FROM expense_categories`);
  const categoryCount = countResult.length > 0 && countResult[0].values.length > 0 ? countResult[0].values[0][0] : 0;
  
  // Initialize default categories if empty
  if (categoryCount === 0) {
    const now = new Date().toISOString();
    const defaultCategories = [
      { name: '인건비', sortOrder: 0 },
      { name: '공과금', sortOrder: 1 },
      { name: '식자재', sortOrder: 2 },
      { name: '소모품', sortOrder: 3 },
      { name: '수리비', sortOrder: 4 },
      { name: '통신비', sortOrder: 5 },
      { name: '보증금환급', sortOrder: 6 },
      { name: '기타', sortOrder: 999 }
    ];
    
    for (const category of defaultCategories) {
      const id = crypto.randomUUID();
      db.run(`
        INSERT INTO expense_categories (id, name, is_default, sort_order, created_at)
        VALUES (?, ?, 1, ?, ?)
      `, [id, category.name, category.sortOrder, now]);
    }
    
    saveDatabaseDebounced();
  }
}

export function createExpenseCategory(category: {
  name: string;
  sortOrder?: number;
}): string {
  if (!db) throw new Error('Database not initialized');
  
  const id = generateId();
  const now = new Date().toISOString();
  const sortOrder = category.sortOrder ?? 999;
  
  db.run(
    `INSERT INTO expense_categories (id, name, is_default, sort_order, created_at)
     VALUES (?, ?, 0, ?, ?)`,
    [id, category.name, sortOrder, now]
  );
  
  saveDatabaseDebounced();
  return id;
}

export function deleteExpenseCategory(id: string) {
  if (!db) throw new Error('Database not initialized');
  
  // Only allow deletion of non-default categories
  db.run('DELETE FROM expense_categories WHERE id = ? AND is_default = 0', [id]);
  saveDatabaseDebounced();
}

export function updateExpenseCategory(id: string, updates: {
  name?: string;
  sortOrder?: number;
}) {
  if (!db) throw new Error('Database not initialized');
  
  const sets: string[] = [];
  const values: any[] = [];
  
  if (updates.name !== undefined) {
    sets.push('name = ?');
    values.push(updates.name);
  }
  if (updates.sortOrder !== undefined) {
    sets.push('sort_order = ?');
    values.push(updates.sortOrder);
  }
  
  if (sets.length === 0) return;
  
  values.push(id);
  
  db.run(
    `UPDATE expense_categories SET ${sets.join(', ')} WHERE id = ?`,
    values
  );
  
  saveDatabaseDebounced();
}

// Recalculate business_day for all existing records
export function recalculateAllBusinessDays() {
  if (!db) throw new Error('Database not initialized');
  
  const settings = getSettings();
  const businessDayStartHour = settings.businessDayStartHour;
  
  // Import getBusinessDay from shared module
  const { getBusinessDay } = require('@shared/businessDay');
  
  let updatedCount = 0;
  
  // 1. Update locker_logs based on entry_time
  const lockerLogs = db.exec('SELECT id, entry_time FROM locker_logs');
  if (lockerLogs.length > 0 && lockerLogs[0].values.length > 0) {
    lockerLogs[0].values.forEach((row: any) => {
      const id = row[0];
      const entryTime = new Date(row[1]);
      const correctBusinessDay = getBusinessDay(entryTime, businessDayStartHour);
      
      db!.run(
        'UPDATE locker_logs SET business_day = ? WHERE id = ?',
        [correctBusinessDay, id]
      );
      updatedCount++;
    });
  }
  
  // 2. Update rental_transactions based on rental_time
  const rentalTransactions = db.exec('SELECT id, rental_time FROM rental_transactions');
  if (rentalTransactions.length > 0 && rentalTransactions[0].values.length > 0) {
    rentalTransactions[0].values.forEach((row: any) => {
      const id = row[0];
      const rentalTime = new Date(row[1]);
      const correctBusinessDay = getBusinessDay(rentalTime, businessDayStartHour);
      
      db!.run(
        'UPDATE rental_transactions SET business_day = ? WHERE id = ?',
        [correctBusinessDay, id]
      );
      updatedCount++;
    });
  }
  
  // 3. Update additional_fee_events based on checkout_time
  const additionalFeeEvents = db.exec('SELECT id, checkout_time FROM additional_fee_events');
  if (additionalFeeEvents.length > 0 && additionalFeeEvents[0].values.length > 0) {
    additionalFeeEvents[0].values.forEach((row: any) => {
      const id = row[0];
      const checkoutTime = new Date(row[1]);
      const correctBusinessDay = getBusinessDay(checkoutTime, businessDayStartHour);
      
      db!.run(
        'UPDATE additional_fee_events SET business_day = ? WHERE id = ?',
        [correctBusinessDay, id]
      );
      updatedCount++;
    });
  }
  
  // 4. Recalculate all daily summaries
  const allBusinessDays = new Set<string>();
  
  // Get all unique business days from locker_logs
  const businessDaysResult = db.exec('SELECT DISTINCT business_day FROM locker_logs');
  if (businessDaysResult.length > 0 && businessDaysResult[0].values.length > 0) {
    businessDaysResult[0].values.forEach((row: any) => {
      allBusinessDays.add(row[0]);
    });
  }
  
  // Recalculate summary for each business day
  allBusinessDays.forEach(businessDay => {
    updateDailySummary(businessDay);
  });
  
  saveDatabaseDebounced();
  
  return updatedCount;
}

// ============================================================================
// Barcode Mappings (바코드 매핑 관리)
// ============================================================================

export function saveBarcodeMapping(barcode: string, lockerNumber: number): boolean {
  if (!db) throw new Error('Database not initialized');
  
  try {
    const now = new Date().toISOString();
    const id = crypto.randomUUID();
    
    // Check if barcode already exists
    const existing = db.exec(
      'SELECT id, locker_number FROM barcode_mappings WHERE barcode = ?',
      [barcode]
    );
    
    if (existing.length > 0 && existing[0].values.length > 0) {
      // Update existing mapping
      const existingLockerNumber = existing[0].values[0][1] as number;
      
      if (existingLockerNumber === lockerNumber) {
        // Same mapping already exists
        return true;
      }
      
      // Update to new locker number
      db.run(
        'UPDATE barcode_mappings SET locker_number = ?, updated_at = ? WHERE barcode = ?',
        [lockerNumber, now, barcode]
      );
    } else {
      // Insert new mapping
      db.run(
        'INSERT INTO barcode_mappings (id, barcode, locker_number, created_at, updated_at) VALUES (?, ?, ?, ?, ?)',
        [id, barcode, lockerNumber, now, now]
      );
    }
    
    saveDatabaseDebounced();
    return true;
  } catch (error) {
    console.error('Error saving barcode mapping:', error);
    return false;
  }
}

export function getLockerNumberByBarcode(barcode: string): number | null {
  if (!db) throw new Error('Database not initialized');
  
  try {
    const result = db.exec(
      'SELECT locker_number FROM barcode_mappings WHERE barcode = ?',
      [barcode]
    );
    
    if (result.length > 0 && result[0].values.length > 0) {
      return result[0].values[0][0] as number;
    }
    
    return null;
  } catch (error) {
    console.error('Error getting locker number by barcode:', error);
    return null;
  }
}

export function getBarcodeByLockerNumber(lockerNumber: number): string | null {
  if (!db) throw new Error('Database not initialized');
  
  try {
    const result = db.exec(
      'SELECT barcode FROM barcode_mappings WHERE locker_number = ?',
      [lockerNumber]
    );
    
    if (result.length > 0 && result[0].values.length > 0) {
      return result[0].values[0][0] as string;
    }
    
    return null;
  } catch (error) {
    console.error('Error getting barcode by locker number:', error);
    return null;
  }
}

export function getAllBarcodeMappings(): Array<{
  id: string;
  barcode: string;
  lockerNumber: number;
  createdAt: string;
  updatedAt: string;
}> {
  if (!db) throw new Error('Database not initialized');
  
  try {
    const result = db.exec(
      'SELECT id, barcode, locker_number, created_at, updated_at FROM barcode_mappings ORDER BY locker_number'
    );
    
    if (result.length === 0 || result[0].values.length === 0) {
      return [];
    }
    
    return result[0].values.map((row: any) => ({
      id: row[0],
      barcode: row[1],
      lockerNumber: row[2],
      createdAt: row[3],
      updatedAt: row[4],
    }));
  } catch (error) {
    console.error('Error getting all barcode mappings:', error);
    return [];
  }
}

export function deleteBarcodeMapping(barcode: string): boolean {
  if (!db) throw new Error('Database not initialized');
  
  try {
    db.run('DELETE FROM barcode_mappings WHERE barcode = ?', [barcode]);
    saveDatabaseDebounced();
    return true;
  } catch (error) {
    console.error('Error deleting barcode mapping:', error);
    return false;
  }
}

export function deleteBarcodeMappingById(id: string): boolean {
  if (!db) throw new Error('Database not initialized');
  
  try {
    db.run('DELETE FROM barcode_mappings WHERE id = ?', [id]);
    saveDatabaseDebounced();
    return true;
  } catch (error) {
    console.error('Error deleting barcode mapping by id:', error);
    return false;
  }
}

// ============================================================================
// RFID Mappings (RFID 매핑 관리)
// ============================================================================

export function saveRfidMapping(rfidUid: string, lockerNumber: number): boolean {
  if (!db) throw new Error('Database not initialized');
  
  try {
    const now = new Date().toISOString();
    const id = crypto.randomUUID();
    
    // Check if RFID UID already exists
    const existing = db.exec(
      'SELECT id, locker_number FROM rfid_mappings WHERE rfid_uid = ?',
      [rfidUid]
    );
    
    if (existing.length > 0 && existing[0].values.length > 0) {
      // Update existing mapping
      const existingLockerNumber = existing[0].values[0][1] as number;
      
      if (existingLockerNumber === lockerNumber) {
        // Same mapping already exists
        return true;
      }
      
      // Update to new locker number
      db.run(
        'UPDATE rfid_mappings SET locker_number = ?, updated_at = ? WHERE rfid_uid = ?',
        [lockerNumber, now, rfidUid]
      );
    } else {
      // Insert new mapping
      db.run(
        'INSERT INTO rfid_mappings (id, rfid_uid, locker_number, created_at, updated_at) VALUES (?, ?, ?, ?, ?)',
        [id, rfidUid, lockerNumber, now, now]
      );
    }
    
    saveDatabaseDebounced();
    return true;
  } catch (error) {
    console.error('Error saving RFID mapping:', error);
    return false;
  }
}

export function getLockerNumberByRfid(rfidUid: string): number | null {
  if (!db) throw new Error('Database not initialized');
  
  try {
    const result = db.exec(
      'SELECT locker_number FROM rfid_mappings WHERE rfid_uid = ?',
      [rfidUid]
    );
    
    if (result.length > 0 && result[0].values.length > 0) {
      return result[0].values[0][0] as number;
    }
    
    return null;
  } catch (error) {
    console.error('Error getting locker number by RFID:', error);
    return null;
  }
}

export function getRfidByLockerNumber(lockerNumber: number): string | null {
  if (!db) throw new Error('Database not initialized');
  
  try {
    const result = db.exec(
      'SELECT rfid_uid FROM rfid_mappings WHERE locker_number = ?',
      [lockerNumber]
    );
    
    if (result.length > 0 && result[0].values.length > 0) {
      return result[0].values[0][0] as string;
    }
    
    return null;
  } catch (error) {
    console.error('Error getting RFID by locker number:', error);
    return null;
  }
}

export function getAllRfidMappings(): Array<{
  id: string;
  rfidUid: string;
  lockerNumber: number;
  createdAt: string;
  updatedAt: string;
}> {
  if (!db) throw new Error('Database not initialized');
  
  try {
    const result = db.exec(
      'SELECT id, rfid_uid, locker_number, created_at, updated_at FROM rfid_mappings ORDER BY locker_number'
    );
    
    if (result.length === 0 || result[0].values.length === 0) {
      return [];
    }
    
    return result[0].values.map((row: any) => ({
      id: row[0],
      rfidUid: row[1],
      lockerNumber: row[2],
      createdAt: row[3],
      updatedAt: row[4],
    }));
  } catch (error) {
    console.error('Error getting all RFID mappings:', error);
    return [];
  }
}

export function deleteRfidMapping(rfidUid: string): boolean {
  if (!db) throw new Error('Database not initialized');
  
  try {
    db.run('DELETE FROM rfid_mappings WHERE rfid_uid = ?', [rfidUid]);
    saveDatabaseDebounced();
    return true;
  } catch (error) {
    console.error('Error deleting RFID mapping:', error);
    return false;
  }
}

export function deleteRfidMappingById(id: string): boolean {
  if (!db) throw new Error('Database not initialized');
  
  try {
    db.run('DELETE FROM rfid_mappings WHERE id = ?', [id]);
    saveDatabaseDebounced();
    return true;
  } catch (error) {
    console.error('Error deleting RFID mapping by id:', error);
    return false;
  }
}

// ==================== Scan Logs Management ====================

export interface ScanLog {
  id: string;
  lockerNumber: number;
  scanTime: string;
  businessDay: string;
  processed: number;
}

// Add scan log when barcode is scanned
export function addScanLog(lockerNumber: number): string {
  if (!db) throw new Error('Database not initialized');
  
  const id = crypto.randomUUID();
  const now = new Date();
  const scanTime = now.toISOString();
  const businessDay = getBusinessDay(now);
  
  try {
    db.run(
      `INSERT INTO scan_logs (id, locker_number, scan_time, business_day, processed)
       VALUES (?, ?, ?, ?, 0)`,
      [id, lockerNumber, scanTime, businessDay]
    );
    // scan_log는 고빈도 쓰기이므로 debounce 저장 (바코드 연속 스캔 시 중복 저장 방지)
    saveDatabaseDebounced();
    return id;
  } catch (error) {
    console.error('Error adding scan log:', error);
    throw error;
  }
}

// Get scan logs with optional date filtering
export function getScanLogs(startDate?: string, endDate?: string): ScanLog[] {
  if (!db) throw new Error('Database not initialized');
  
  try {
    let query = 'SELECT * FROM scan_logs';
    const params: any[] = [];
    
    if (startDate && endDate) {
      query += ' WHERE scan_time >= ? AND scan_time < ?';
      params.push(startDate, endDate);
    } else if (startDate) {
      query += ' WHERE scan_time >= ?';
      params.push(startDate);
    } else if (endDate) {
      query += ' WHERE scan_time < ?';
      params.push(endDate);
    }
    
    query += ' ORDER BY scan_time DESC';
    
    const result = db.exec(query, params);
    
    if (result.length === 0 || result[0].values.length === 0) {
      return [];
    }
    
    return result[0].values.map((row: any) => ({
      id: row[0],
      lockerNumber: row[1],
      scanTime: row[2],
      businessDay: row[3],
      processed: row[4],
    }));
  } catch (error) {
    console.error('Error getting scan logs:', error);
    return [];
  }
}

// Mark scan as processed when check-in is completed
export function markScanAsProcessed(scanId: string): boolean {
  if (!db) throw new Error('Database not initialized');
  
  try {
    db.run(
      'UPDATE scan_logs SET processed = 1 WHERE id = ?',
      [scanId]
    );
    saveDatabaseDebounced();
    return true;
  } catch (error) {
    console.error('Error marking scan as processed:', error);
    return false;
  }
}

// Get unprocessed scans (scans without check-in)
export function getUnprocessedScans(businessDay?: string): ScanLog[] {
  if (!db) throw new Error('Database not initialized');
  
  try {
    let query = 'SELECT * FROM scan_logs WHERE processed = 0';
    const params: any[] = [];
    
    if (businessDay) {
      query += ' AND business_day = ?';
      params.push(businessDay);
    }
    
    query += ' ORDER BY scan_time DESC';
    
    const result = db.exec(query, params);
    
    if (result.length === 0 || result[0].values.length === 0) {
      return [];
    }
    
    return result[0].values.map((row: any) => ({
      id: row[0],
      lockerNumber: row[1],
      scanTime: row[2],
      businessDay: row[3],
      processed: row[4],
    }));
  } catch (error) {
    console.error('Error getting unprocessed scans:', error);
    return [];
  }
}

// Get scan statistics for a business day
export function getScanStats(businessDay: string): {
  totalScans: number;
  processedScans: number;
  unprocessedScans: number;
} {
  if (!db) throw new Error('Database not initialized');
  
  try {
    const result = db.exec(
      `SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN processed = 1 THEN 1 ELSE 0 END) as processed,
        SUM(CASE WHEN processed = 0 THEN 1 ELSE 0 END) as unprocessed
       FROM scan_logs
       WHERE business_day = ?`,
      [businessDay]
    );
    
    if (result.length === 0 || result[0].values.length === 0) {
      return { totalScans: 0, processedScans: 0, unprocessedScans: 0 };
    }
    
    const row = result[0].values[0];
    return {
      totalScans: row[0] as number,
      processedScans: row[1] as number,
      unprocessedScans: row[2] as number,
    };
  } catch (error) {
    console.error('Error getting scan stats:', error);
    return { totalScans: 0, processedScans: 0, unprocessedScans: 0 };
  }
}

// Get the scan time of the most recent unprocessed scan for a locker
// This is used to record the entry time as the time the dialog was opened (scan time)
// instead of the time the check-in button was pressed
export function getLatestUnprocessedScanTime(lockerNumber: number): Date | null {
  if (!db) throw new Error('Database not initialized');
  
  try {
    const result = db.exec(
      `SELECT scan_time FROM scan_logs 
       WHERE locker_number = ? AND processed = 0 
       ORDER BY scan_time DESC 
       LIMIT 1`,
      [lockerNumber]
    );
    
    if (result.length === 0 || result[0].values.length === 0) {
      return null;
    }
    
    const scanTimeStr = result[0].values[0][0] as string;
    return new Date(scanTimeStr);
  } catch (error) {
    console.error('Error getting latest unprocessed scan time:', error);
    return null;
  }
}

// Mark the most recent unprocessed scan for a locker as processed
export function markLatestScanAsProcessedByLocker(lockerNumber: number): boolean {
  if (!db) throw new Error('Database not initialized');
  
  try {
    // Find the most recent unprocessed scan for this locker
    const result = db.exec(
      `SELECT id FROM scan_logs 
       WHERE locker_number = ? AND processed = 0 
       ORDER BY scan_time DESC 
       LIMIT 1`,
      [lockerNumber]
    );
    
    if (result.length === 0 || result[0].values.length === 0) {
      // No unprocessed scan found - this is normal (e.g., manual locker click without barcode scan)
      return false;
    }
    
    const scanId = result[0].values[0][0] as string;
    
    // Mark it as processed
    db.run(
      'UPDATE scan_logs SET processed = 1 WHERE id = ?',
      [scanId]
    );
    saveDatabaseDebounced();
    return true;
  } catch (error) {
    console.error('Error marking latest scan as processed:', error);
    return false;
  }
}

// Export all database tables and localStorage settings to JSON
export function updateLockerLogMemo(logId: string, memo: string): boolean {
  if (!db) throw new Error('Database not initialized');
  
  db.run(
    `UPDATE locker_logs SET customer_memo = ? WHERE id = ?`,
    [memo || null, logId]
  );
  
  saveDatabaseDebounced();
  return true;
}

export function updateLockerOuting(logId: string, isOuting: boolean): boolean {
  if (!db) throw new Error('Database not initialized');
  
  // is_outing 컬럼이 없으면 자동으로 추가 (마이그레이션 누락 대비)
  try {
    db.run(`ALTER TABLE locker_logs ADD COLUMN is_outing INTEGER DEFAULT 0`);
    console.log('[updateLockerOuting] is_outing 컬럼 자동 추가 완료');
  } catch (_e) {
    // 이미 존재하면 무시
  }
  
  // outing_started_at 컬럼이 없으면 자동으로 추가
  try {
    db.run(`ALTER TABLE locker_logs ADD COLUMN outing_started_at TEXT`);
    console.log('[updateLockerOuting] outing_started_at 컬럼 자동 추가 완료');
  } catch (_e) {
    // 이미 존재하면 무시
  }
  
  const val = isOuting ? 1 : 0;
  if (isOuting) {
    // 외출 ON: 이미 외출 중이면 outing_started_at을 보존 (수정저장으로 인한 리셋 방지)
    // COALESCE(outing_started_at, ?) → 기존 값이 있으면 유지, NULL이면 현재 시각으로 설정
    const now = new Date().toISOString();
    db.run(
      `UPDATE locker_logs SET is_outing = 1, outing_started_at = COALESCE(outing_started_at, ?) WHERE id = ?`,
      [now, logId]
    );
  } else {
    // 외출 OFF: outing_started_at 초기화
    db.run(`UPDATE locker_logs SET is_outing = 0, outing_started_at = NULL WHERE id = ?`, [logId]);
  }
  saveDatabaseDebounced();
  return true;
}

// Update additional_fee_paid status and paid amount for a locker log
export function updateLockerLogAdditionalFeePaid(logId: string, paid: boolean, paidAmount?: number): boolean {
  if (!db) throw new Error('Database not initialized');
  
  if (paidAmount !== undefined) {
    db.run(
      `UPDATE locker_logs SET additional_fee_paid = ?, additional_fee_paid_amount = ? WHERE id = ?`,
      [paid ? 1 : 0, paidAmount, logId]
    );
  } else {
    db.run(
      `UPDATE locker_logs SET additional_fee_paid = ? WHERE id = ?`,
      [paid ? 1 : 0, logId]
    );
  }
  
  saveDatabaseDebounced();
  return true;
}

// Get additional_fee_paid status for a locker log (returns paid amount for comparison)
export function getLockerLogAdditionalFeePaid(logId: string): boolean {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(
    `SELECT additional_fee_paid FROM locker_logs WHERE id = ?`,
    [logId]
  );
  
  if (result.length === 0 || result[0].values.length === 0) {
    return false;
  }
  
  return result[0].values[0][0] === 1;
}

// Get additional_fee_paid_amount for a locker log
export function getLockerLogAdditionalFeePaidAmount(logId: string): number {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(
    `SELECT additional_fee_paid_amount FROM locker_logs WHERE id = ?`,
    [logId]
  );
  
  if (result.length === 0 || result[0].values.length === 0) {
    return 0;
  }
  
  return (result[0].values[0][0] as number) || 0;
}

// Get prepaid_additional_fee for a locker log (선지급 추가요금)
export function getLockerLogPrepaidAdditionalFee(logId: string): number {
  if (!db) throw new Error('Database not initialized');
  
  const result = db.exec(
    `SELECT prepaid_additional_fee FROM locker_logs WHERE id = ?`,
    [logId]
  );
  
  if (result.length === 0 || result[0].values.length === 0) {
    return 0;
  }
  
  return (result[0].values[0][0] as number) || 0;
}

// Update prepaid_additional_fee for a locker log (선지급 추가요금 업데이트)
export function updateLockerLogPrepaidAdditionalFee(logId: string, amount: number): boolean {
  if (!db) throw new Error('Database not initialized');
  
  db.run(
    `UPDATE locker_logs SET prepaid_additional_fee = ? WHERE id = ?`,
    [amount, logId]
  );
  
  saveDatabaseDebounced();
  return true;
}

export function exportDatabase(): {
  success: boolean;
  data?: string;
  error?: string;
} {
  if (!db) {
    return { success: false, error: 'Database not initialized' };
  }
  
  try {
    const exportData: any = {
      version: '1.0',
      exportDate: new Date().toISOString(),
      appName: APP_SYSTEM_NAME,
      tables: {},
      localStorage: {}
    };
    
    // Helper function to export a table
    const exportTable = (tableName: string) => {
      const result = db!.exec(`SELECT * FROM ${tableName}`);
      if (result.length === 0 || result[0].values.length === 0) {
        return [];
      }
      
      const columns = result[0].columns;
      return result[0].values.map((row: any) => {
        const obj: any = {};
        columns.forEach((col, idx) => {
          obj[col] = row[idx];
        });
        return obj;
      });
    };
    
    // Export all tables (including user-defined settings like pricing_options)
    const tables = [
      'locker_logs',
      'locker_daily_summaries',
      'system_metadata',
      'locker_groups',
      'additional_fee_events',
      'additional_revenue_items',
      'rental_transactions',
      'expenses',
      'closing_days',
      'expense_categories',
      'barcode_mappings',
      'rfid_mappings',
      'scan_logs',
      'pricing_options',  // 추가 요금옵션 (사용자 정의)
      'staff',            // 직원 정보
      'staff_work_logs',  // 직원 근무·근태 기록
      'staff_ratings'     // 직원 평가 기록
    ];
    
    tables.forEach(tableName => {
      try {
        exportData.tables[tableName] = exportTable(tableName);
      } catch (error) {
        console.warn(`Failed to export table ${tableName}:`, error);
        exportData.tables[tableName] = [];
      }
    });
    
    // Export localStorage settings (excluding database itself and device-specific data)
    // Include all user settings and preferences that should persist across app updates
    const localStorageKeys = [
      // 시스템 설정
      'settings',
      // 보안 설정
      'staff_pattern',
      'staff_password',
      'security_enabled',
      'security_pattern',
      'security_today_status_enabled',
      'security_sales_tab_enabled',
      'auth_method_mode',
      'webauthn_enabled',
      'webauthn_credential_id',
      // 메뉴별 잠금 설정
      'locked_menu_routes',
      // 락카 사용설정 (사용불가 락카)
      'out_of_service_lockers',
      // 금전 관리
      'cash_register',
      'last_settlement_reminder_date',
      // 메모
      'daily_memo',
      // UI 설정
      'workspaceFloatingMode',
      'workspaceFloatingPosition',
      'workspaceFloatingSize',
      'workspaceDockedSide',
      'uiLayoutMode'
    ];
    
    localStorageKeys.forEach(key => {
      try {
        const value = localStorage.getItem(key);
        if (value !== null) {
          exportData.localStorage[key] = value;
        }
      } catch (error) {
        console.warn(`Failed to export localStorage key ${key}:`, error);
      }
    });
    
    const jsonString = JSON.stringify(exportData, null, 2);
    return { success: true, data: jsonString };
  } catch (error) {
    console.error('Error exporting database:', error);
    return { success: false, error: String(error) };
  }
}

// Import database from JSON
export function importDatabase(jsonString: string): {
  success: boolean;
  message?: string;
  error?: string;
} {
  if (!db) {
    return { success: false, error: 'Database not initialized' };
  }
  
  try {
    const importData = JSON.parse(jsonString);
    
    // Validate import data structure
    if (!importData.version || !importData.tables) {
      return { success: false, error: '유효하지 않은 백업 파일 형식입니다.' };
    }
    
    const validAppNames = ['EQUUS Hotel Management System', 'HIZZ Hotel Management System'];
    if (!validAppNames.includes(importData.appName)) {
      return { success: false, error: '이 파일은 호텔 관리 시스템 백업 파일이 아닙니다.' };
    }
    
    console.log(`Importing database backup from ${importData.exportDate}`);
    
    // Clear existing data from all tables (including user-defined settings)
    const tables = [
      'staff_ratings',    // 직원 평가 기록 (staff_work_logs 보다 먼저)
      'staff_work_logs',  // 직원 근무·근태 기록 (staff 보다 먼저)
      'staff',            // 직원 정보
      'pricing_options',  // 추가 요금옵션 (사용자 정의)
      'scan_logs',
      'rfid_mappings',
      'barcode_mappings',
      'expense_categories',
      'closing_days',
      'expenses',
      'rental_transactions',
      'additional_revenue_items',
      'additional_fee_events',
      'locker_groups',
      'locker_daily_summaries',
      'locker_logs',
      'system_metadata'
    ];
    
    // Delete in reverse order to avoid foreign key issues
    tables.forEach(tableName => {
      try {
        db!.run(`DELETE FROM ${tableName}`);
        console.log(`Cleared table: ${tableName}`);
      } catch (error) {
        console.warn(`Failed to clear table ${tableName}:`, error);
      }
    });
    
    // Clear localStorage settings (except authenticated and database)
    // Include all user settings and preferences that should persist across app updates
    const localStorageKeys = [
      // 시스템 설정
      'settings',
      // 보안 설정
      'staff_pattern',
      'staff_password',
      'security_enabled',
      'security_pattern',
      'security_today_status_enabled',
      'security_sales_tab_enabled',
      'auth_method_mode',
      'webauthn_enabled',
      'webauthn_credential_id',
      // 메뉴별 잠금 설정
      'locked_menu_routes',
      // 락카 사용설정 (사용불가 락카)
      'out_of_service_lockers',
      // 금전 관리
      'cash_register',
      'last_settlement_reminder_date',
      // 메모
      'daily_memo',
      // UI 설정
      'workspaceFloatingMode',
      'workspaceFloatingPosition',
      'workspaceFloatingSize',
      'workspaceDockedSide',
      'uiLayoutMode'
    ];
    
    localStorageKeys.forEach(key => {
      try {
        localStorage.removeItem(key);
        console.log(`Cleared localStorage key: ${key}`);
      } catch (error) {
        console.warn(`Failed to clear localStorage key ${key}:`, error);
      }
    });
    
    // Import data for each table
    const importTable = (tableName: string, data: any[]) => {
      if (!data || data.length === 0) {
        console.log(`No data to import for ${tableName}`);
        return;
      }

      // Get actual columns in current DB schema to handle version mismatches
      let currentColumns: string[] = [];
      try {
        const schemaResult = db!.exec(`PRAGMA table_info(${tableName})`);
        if (schemaResult.length > 0) {
          currentColumns = schemaResult[0].values.map((row: any) => row[1] as string);
        }
      } catch (e) {
        console.warn(`Could not read schema for ${tableName}:`, e);
      }

      const firstRow = data[0];
      const backupColumns = Object.keys(firstRow);

      // Only insert columns that exist in both backup AND current schema
      // This handles forward/backward compatibility across schema migrations
      const columns = currentColumns.length > 0
        ? backupColumns.filter(col => currentColumns.includes(col))
        : backupColumns;

      if (columns.length === 0) {
        console.warn(`No matching columns for ${tableName}, skipping`);
        return;
      }

      const placeholders = columns.map(() => '?').join(', ');
      const columnNames = columns.join(', ');
      const insertQuery = `INSERT OR IGNORE INTO ${tableName} (${columnNames}) VALUES (${placeholders})`;

      let imported = 0;
      let failed = 0;
      data.forEach((row: any) => {
        try {
          const values = columns.map(col => (row[col] !== undefined ? row[col] : null));
          db!.run(insertQuery, values);
          imported++;
        } catch (error) {
          console.warn(`Failed to import row in ${tableName}:`, error, row);
          failed++;
        }
      });

      console.log(`Imported ${imported}/${data.length} rows for ${tableName}` + (failed > 0 ? ` (${failed} failed)` : ''));
    };
    
    // Import tables in order (system_metadata first, then others, user-defined settings included)
    const importOrder = [
      'system_metadata',
      'locker_groups',
      'locker_logs',
      'locker_daily_summaries',
      'additional_fee_events',
      'additional_revenue_items',
      'rental_transactions',
      'expenses',
      'closing_days',
      'expense_categories',
      'barcode_mappings',
      'rfid_mappings',
      'scan_logs',
      'pricing_options',  // 추가 요금옵션 (사용자 정의)
      'staff',            // 직원 정보 (staff_work_logs 보다 먼저)
      'staff_work_logs',  // 직원 근무·근태 기록
      'staff_ratings'     // 직원 평가 기록
    ];
    
    // scan_logs: 최근 90일치만 가져오기 (누적 과다로 인한 DB 비대화 방지)
    const scanLogCutoff = new Date();
    scanLogCutoff.setDate(scanLogCutoff.getDate() - 90);
    const scanLogCutoffStr = scanLogCutoff.toISOString().slice(0, 10); // YYYY-MM-DD

    importOrder.forEach(tableName => {
      if (importData.tables[tableName]) {
        if (tableName === 'scan_logs') {
          const filtered = importData.tables[tableName].filter((row: any) => {
            const scanDay = (row.business_day || row.scan_time || '').slice(0, 10);
            return scanDay >= scanLogCutoffStr;
          });
          console.log(`[Import] scan_logs: ${importData.tables[tableName].length}건 중 최근 90일 ${filtered.length}건만 가져오기`);
          importTable(tableName, filtered);
        } else {
          importTable(tableName, importData.tables[tableName]);
        }
      }
    });
    
    // Import localStorage settings
    if (importData.localStorage) {
      localStorageKeys.forEach(key => {
        if (importData.localStorage[key] !== undefined) {
          try {
            localStorage.setItem(key, importData.localStorage[key]);
            console.log(`Restored localStorage key: ${key}`);
          } catch (error) {
            console.warn(`Failed to restore localStorage key ${key}:`, error);
          }
        }
      });
    }
    
    // VACUUM: 이전 데이터 삭제 후 남은 빈 페이지 공간 회수
    // → db.export() 크기 최소화 → saveDatabase() 속도 정상화 (3-7초 → 수십ms)
    console.log('[Import] Running VACUUM to reclaim freed pages...');
    db!.run('VACUUM');
    
    // Save database to localStorage (immediately after VACUUM - must persist)
    saveDatabase();
    
    const totalRows = Object.values(importData.tables).reduce(
      (sum: number, table: any) => sum + (Array.isArray(table) ? table.length : 0),
      0
    );
    
    const totalLocalStorage = importData.localStorage ? Object.keys(importData.localStorage).length : 0;
    
    return {
      success: true,
      message: `${importData.exportDate}에 백업된 데이터를 성공적으로 복원했습니다. (${totalRows}개 레코드 + ${totalLocalStorage}개 설정)`
    };
  } catch (error) {
    console.error('Error importing database:', error);
    
    // Provide more specific error messages
    if (error instanceof SyntaxError) {
      return { success: false, error: 'JSON 파일 형식이 올바르지 않습니다.' };
    }
    
    return { success: false, error: `가져오기 실패: ${String(error)}` };
  }
}

// Export RFID mappings only
export function exportRfidMappings(): {
  success: boolean;
  data?: string;
  error?: string;
} {
  if (!db) {
    return { success: false, error: 'Database not initialized' };
  }
  
  try {
    const exportData = {
      version: '1.0',
      type: 'rfid_mappings',
      exportDate: new Date().toISOString(),
      appName: APP_SYSTEM_NAME,
      mappings: [] as any[]
    };
    
    const result = db.exec(`SELECT * FROM rfid_mappings ORDER BY locker_number`);
    if (result.length > 0 && result[0].values.length > 0) {
      const columns = result[0].columns;
      exportData.mappings = result[0].values.map((row: any) => {
        const obj: any = {};
        columns.forEach((col, idx) => {
          obj[col] = row[idx];
        });
        return obj;
      });
    }
    
    return {
      success: true,
      data: JSON.stringify(exportData, null, 2)
    };
  } catch (error) {
    console.error('Error exporting RFID mappings:', error);
    return { success: false, error: String(error) };
  }
}

// Import RFID mappings only
export function importRfidMappings(jsonData: string): {
  success: boolean;
  message?: string;
  error?: string;
} {
  if (!db) {
    return { success: false, error: 'Database not initialized' };
  }
  
  try {
    const importData = JSON.parse(jsonData);
    
    if (importData.type !== 'rfid_mappings') {
      return { success: false, error: 'RFID 매핑 파일이 아닙니다.' };
    }
    
    if (!Array.isArray(importData.mappings)) {
      return { success: false, error: 'RFID 매핑 데이터가 없습니다.' };
    }
    
    let importedCount = 0;
    let skippedCount = 0;
    
    for (const mapping of importData.mappings) {
      if (!mapping.rfid_uid || !mapping.locker_number) continue;
      
      // Check if already exists
      const existing = db.exec(
        `SELECT id FROM rfid_mappings WHERE rfid_uid = ? OR locker_number = ?`,
        [mapping.rfid_uid, mapping.locker_number]
      );
      
      if (existing.length > 0 && existing[0].values.length > 0) {
        skippedCount++;
        continue;
      }
      
      const id = mapping.id || `rfid_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      db.run(
        `INSERT INTO rfid_mappings (id, rfid_uid, locker_number, created_at, updated_at) VALUES (?, ?, ?, ?, ?)`,
        [id, mapping.rfid_uid, mapping.locker_number, mapping.created_at || new Date().toISOString(), new Date().toISOString()]
      );
      importedCount++;
    }
    
    saveDatabaseDebounced();
    
    return {
      success: true,
      message: `RFID 매핑 ${importedCount}개 가져오기 완료${skippedCount > 0 ? ` (중복 ${skippedCount}개 건너뜀)` : ''}`
    };
  } catch (error) {
    console.error('Error importing RFID mappings:', error);
    return { success: false, error: `가져오기 실패: ${String(error)}` };
  }
}

// Export barcode mappings only
export function exportBarcodeMappings(): {
  success: boolean;
  data?: string;
  error?: string;
} {
  if (!db) {
    return { success: false, error: 'Database not initialized' };
  }
  
  try {
    const exportData = {
      version: '1.0',
      type: 'barcode_mappings',
      exportDate: new Date().toISOString(),
      appName: APP_SYSTEM_NAME,
      mappings: [] as any[]
    };
    
    const result = db.exec(`SELECT * FROM barcode_mappings ORDER BY locker_number`);
    if (result.length > 0 && result[0].values.length > 0) {
      const columns = result[0].columns;
      exportData.mappings = result[0].values.map((row: any) => {
        const obj: any = {};
        columns.forEach((col, idx) => {
          obj[col] = row[idx];
        });
        return obj;
      });
    }
    
    return {
      success: true,
      data: JSON.stringify(exportData, null, 2)
    };
  } catch (error) {
    console.error('Error exporting barcode mappings:', error);
    return { success: false, error: String(error) };
  }
}

// Import barcode mappings only
export function importBarcodeMappings(jsonData: string): {
  success: boolean;
  message?: string;
  error?: string;
} {
  if (!db) {
    return { success: false, error: 'Database not initialized' };
  }
  
  try {
    const importData = JSON.parse(jsonData);
    
    if (importData.type !== 'barcode_mappings') {
      return { success: false, error: '바코드 매핑 파일이 아닙니다.' };
    }
    
    if (!Array.isArray(importData.mappings)) {
      return { success: false, error: '바코드 매핑 데이터가 없습니다.' };
    }
    
    let importedCount = 0;
    let skippedCount = 0;
    
    for (const mapping of importData.mappings) {
      if (!mapping.barcode || !mapping.locker_number) continue;
      
      // Check if already exists
      const existing = db.exec(
        `SELECT id FROM barcode_mappings WHERE barcode = ? OR locker_number = ?`,
        [mapping.barcode, mapping.locker_number]
      );
      
      if (existing.length > 0 && existing[0].values.length > 0) {
        skippedCount++;
        continue;
      }
      
      const id = mapping.id || `barcode_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      db.run(
        `INSERT INTO barcode_mappings (id, barcode, locker_number, created_at, updated_at) VALUES (?, ?, ?, ?, ?)`,
        [id, mapping.barcode, mapping.locker_number, mapping.created_at || new Date().toISOString(), new Date().toISOString()]
      );
      importedCount++;
    }
    
    saveDatabaseDebounced();
    
    return {
      success: true,
      message: `바코드 매핑 ${importedCount}개 가져오기 완료${skippedCount > 0 ? ` (중복 ${skippedCount}개 건너뜀)` : ''}`
    };
  } catch (error) {
    console.error('Error importing barcode mappings:', error);
    return { success: false, error: `가져오기 실패: ${String(error)}` };
  }
}

// =========================================
// Pricing Options CRUD Operations
// =========================================

export interface PricingOption {
  id: string;
  name: string;
  optionType: 'discount' | 'surcharge' | 'fixed';
  amount: number;
  sortOrder: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export function getPricingOptions(): PricingOption[] {
  if (!db) return [];
  
  try {
    const result = db.exec(`
      SELECT id, name, option_type, amount, sort_order, is_active, created_at, updated_at
      FROM pricing_options
      ORDER BY sort_order ASC, created_at ASC
    `);
    
    if (result.length === 0) return [];
    
    return result[0].values.map(row => ({
      id: row[0] as string,
      name: row[1] as string,
      optionType: row[2] as 'discount' | 'surcharge' | 'fixed',
      amount: row[3] as number,
      sortOrder: row[4] as number,
      isActive: (row[5] as number) === 1,
      createdAt: row[6] as string,
      updatedAt: row[7] as string,
    }));
  } catch (error) {
    console.error('Error getting pricing options:', error);
    return [];
  }
}

export function getActivePricingOptions(): PricingOption[] {
  return getPricingOptions().filter(opt => opt.isActive);
}

export function createPricingOption(option: {
  name: string;
  optionType: 'discount' | 'surcharge' | 'fixed';
  amount: number;
  sortOrder?: number;
}): string {
  if (!db) throw new Error('Database not initialized');
  
  const id = `pricing_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  const now = new Date().toISOString();
  const sortOrder = option.sortOrder ?? 0;
  
  db.run(
    `INSERT INTO pricing_options (id, name, option_type, amount, sort_order, is_active, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, 1, ?, ?)`,
    [id, option.name, option.optionType, option.amount, sortOrder, now, now]
  );
  
  saveDatabaseDebounced();
  return id;
}

export function updatePricingOption(id: string, updates: {
  name?: string;
  optionType?: 'discount' | 'surcharge' | 'fixed';
  amount?: number;
  sortOrder?: number;
  isActive?: boolean;
}): boolean {
  if (!db) return false;
  
  const sets: string[] = [];
  const values: any[] = [];
  
  if (updates.name !== undefined) {
    sets.push('name = ?');
    values.push(updates.name);
  }
  if (updates.optionType !== undefined) {
    sets.push('option_type = ?');
    values.push(updates.optionType);
  }
  if (updates.amount !== undefined) {
    sets.push('amount = ?');
    values.push(updates.amount);
  }
  if (updates.sortOrder !== undefined) {
    sets.push('sort_order = ?');
    values.push(updates.sortOrder);
  }
  if (updates.isActive !== undefined) {
    sets.push('is_active = ?');
    values.push(updates.isActive ? 1 : 0);
  }
  
  if (sets.length === 0) return false;
  
  sets.push('updated_at = ?');
  values.push(new Date().toISOString());
  values.push(id);
  
  try {
    db.run(`UPDATE pricing_options SET ${sets.join(', ')} WHERE id = ?`, values);
    saveDatabaseDebounced();
    return true;
  } catch (error) {
    console.error('Error updating pricing option:', error);
    return false;
  }
}

export function deletePricingOption(id: string): boolean {
  if (!db) return false;
  
  try {
    db.run('DELETE FROM pricing_options WHERE id = ?', [id]);
    saveDatabaseDebounced();
    return true;
  } catch (error) {
    console.error('Error deleting pricing option:', error);
    return false;
  }
}

export function calculatePriceWithOption(basePrice: number, option: PricingOption): number {
  switch (option.optionType) {
    case 'discount':
      return Math.max(0, basePrice - option.amount);
    case 'surcharge':
      return basePrice + option.amount;
    case 'fixed':
      return option.amount;
    default:
      return basePrice;
  }
}

// ============================================================
// STAFF MANAGEMENT (직원관리)
// ============================================================

export interface Staff {
  id: string;
  name: string;
  phone: string;
  address: string;
  hireDate: string;
  hourlyPay: number;
  partTimeHours: number;
  pin: string;
  isActive: boolean;
  notes: string;
  createdAt: string;
  photo: string;
}

export type PayType = '주간' | '야간' | '주말' | '공휴일';

export interface StaffWorkLog {
  id: string;
  staffId: string;
  workDate: string;
  startTime: string;
  endTime: string;
  breakMinutes: number;
  workMinutes: number;
  dailyPay: number;
  notes: string;
  createdAt: string;
  updatedAt: string;
  agreedStartTime: string;
  agreedEndTime: string;
  payType: PayType;
  segmentPay: number;
  hourlyRate: number;
}

export type StaffRatingValue = '훌륭' | '좋음' | '태만' | '경고';

export interface StaffRating {
  id: string;
  staffId: string;
  ratingDate: string;
  rating: StaffRatingValue;
  note: string;
  createdAt: string;
}

function rowToStaff(r: any[]): Staff {
  return {
    id: r[0], name: r[1], phone: r[2] || '', address: r[3] || '',
    hireDate: r[4] || '', hourlyPay: r[5] || 0, partTimeHours: r[6] || 0,
    pin: r[7] || '', isActive: r[8] === 1, notes: r[9] || '', createdAt: r[10] || '',
    photo: r[11] || '',
  };
}

function rowToWorkLog(r: any[]): StaffWorkLog {
  return {
    id: r[0], staffId: r[1], workDate: r[2], startTime: r[3] || '',
    endTime: r[4] || '', breakMinutes: r[5] || 0, workMinutes: r[6] || 0,
    dailyPay: r[7] || 0, notes: r[8] || '', createdAt: r[9] || '', updatedAt: r[10] || '',
    agreedStartTime: r[11] || '', agreedEndTime: r[12] || '',
    payType: (r[13] as PayType) || '주간', segmentPay: r[14] || 0, hourlyRate: r[15] || 0,
  };
}

export function createStaff(data: Omit<Staff, 'id' | 'createdAt'>): string {
  if (!db) return '';
  const id = `staff_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const now = new Date().toISOString();
  db.run(
    `INSERT INTO staff (id, name, phone, address, hire_date, hourly_pay, part_time_hours, pin, is_active, notes, created_at, photo)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, data.name, data.phone || '', data.address || '', data.hireDate || '',
     data.hourlyPay || 0, data.partTimeHours || 0, data.pin || '',
     data.isActive ? 1 : 0, data.notes || '', now, data.photo || '']
  );
  saveDatabaseDebounced();
  return id;
}

export function getAllStaff(activeOnly = false): Staff[] {
  if (!db) return [];
  const where = activeOnly ? 'WHERE is_active = 1' : '';
  const rows = db.exec(`SELECT id, name, phone, address, hire_date, hourly_pay, part_time_hours, pin, is_active, notes, created_at, photo FROM staff ${where} ORDER BY name ASC`);
  if (!rows.length) return [];
  return rows[0].values.map(rowToStaff);
}

export function getStaffById(id: string): Staff | null {
  if (!db) return null;
  const rows = db.exec(`SELECT id, name, phone, address, hire_date, hourly_pay, part_time_hours, pin, is_active, notes, created_at, photo FROM staff WHERE id = ? LIMIT 1`, [id]);
  if (!rows.length || !rows[0].values.length) return null;
  return rowToStaff(rows[0].values[0]);
}

export function updateStaff(id: string, data: Partial<Omit<Staff, 'id' | 'createdAt'>>): boolean {
  if (!db) return false;
  const sets: string[] = [];
  const values: any[] = [];
  if (data.name !== undefined) { sets.push('name = ?'); values.push(data.name); }
  if (data.phone !== undefined) { sets.push('phone = ?'); values.push(data.phone); }
  if (data.address !== undefined) { sets.push('address = ?'); values.push(data.address); }
  if (data.hireDate !== undefined) { sets.push('hire_date = ?'); values.push(data.hireDate); }
  if (data.hourlyPay !== undefined) { sets.push('hourly_pay = ?'); values.push(data.hourlyPay); }
  if (data.partTimeHours !== undefined) { sets.push('part_time_hours = ?'); values.push(data.partTimeHours); }
  if (data.pin !== undefined) { sets.push('pin = ?'); values.push(data.pin); }
  if (data.isActive !== undefined) { sets.push('is_active = ?'); values.push(data.isActive ? 1 : 0); }
  if (data.notes !== undefined) { sets.push('notes = ?'); values.push(data.notes); }
  if (data.photo !== undefined) { sets.push('photo = ?'); values.push(data.photo); }
  if (!sets.length) return false;
  values.push(id);
  db.run(`UPDATE staff SET ${sets.join(', ')} WHERE id = ?`, values);
  saveDatabaseDebounced();
  return true;
}

export function deleteStaff(id: string): boolean {
  if (!db) return false;
  db.run('DELETE FROM staff WHERE id = ?', [id]);
  db.run('DELETE FROM staff_work_logs WHERE staff_id = ?', [id]);
  db.run('DELETE FROM staff_ratings WHERE staff_id = ?', [id]);
  saveDatabaseDebounced();
  return true;
}

const WORK_LOG_SELECT = `SELECT id, staff_id, work_date, start_time, end_time, break_minutes, work_minutes, daily_pay, notes, created_at, updated_at, agreed_start_time, agreed_end_time, pay_type, segment_pay, hourly_rate FROM staff_work_logs`;

export function createWorkLog(data: Omit<StaffWorkLog, 'id' | 'createdAt' | 'updatedAt'>): string {
  if (!db) return '';
  const id = `wlog_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const now = new Date().toISOString();
  db.run(
    `INSERT INTO staff_work_logs (id, staff_id, work_date, start_time, end_time, break_minutes, work_minutes, daily_pay, notes, created_at, updated_at, agreed_start_time, agreed_end_time, pay_type, segment_pay, hourly_rate)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, data.staffId, data.workDate, data.startTime || '', data.endTime || '',
     data.breakMinutes || 0, data.workMinutes || 0, data.dailyPay || 0, data.notes || '', now, now,
     data.agreedStartTime || '', data.agreedEndTime || '',
     data.payType || '주간', data.segmentPay || 0, data.hourlyRate || 0]
  );
  saveDatabaseDebounced();
  return id;
}

export function getWorkLogs(staffId?: string, from?: string, to?: string): StaffWorkLog[] {
  if (!db) return [];
  const conditions: string[] = [];
  const params: any[] = [];
  if (staffId) { conditions.push('staff_id = ?'); params.push(staffId); }
  if (from) { conditions.push('work_date >= ?'); params.push(from); }
  if (to) { conditions.push('work_date <= ?'); params.push(to); }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const rows = db.exec(`${WORK_LOG_SELECT} ${where} ORDER BY work_date DESC, created_at ASC`, params);
  if (!rows.length) return [];
  return rows[0].values.map(rowToWorkLog);
}

export function getTodayWorkLog(staffId: string, date: string): StaffWorkLog | null {
  if (!db) return null;
  const rows = db.exec(`${WORK_LOG_SELECT} WHERE staff_id = ? AND work_date = ? ORDER BY created_at ASC LIMIT 1`, [staffId, date]);
  if (!rows.length || !rows[0].values.length) return null;
  return rowToWorkLog(rows[0].values[0]);
}

export function getTodayWorkLogs(staffId: string, date: string): StaffWorkLog[] {
  if (!db) return [];
  const rows = db.exec(`${WORK_LOG_SELECT} WHERE staff_id = ? AND work_date = ? ORDER BY created_at ASC`, [staffId, date]);
  if (!rows.length) return [];
  return rows[0].values.map(rowToWorkLog);
}

export function updateWorkLog(id: string, data: Partial<Pick<StaffWorkLog, 'startTime' | 'endTime' | 'breakMinutes' | 'workMinutes' | 'dailyPay' | 'notes' | 'agreedStartTime' | 'agreedEndTime' | 'payType' | 'segmentPay'>>): boolean {
  if (!db) return false;
  const sets: string[] = [];
  const values: any[] = [];
  if (data.startTime !== undefined) { sets.push('start_time = ?'); values.push(data.startTime); }
  if (data.endTime !== undefined) { sets.push('end_time = ?'); values.push(data.endTime); }
  if (data.breakMinutes !== undefined) { sets.push('break_minutes = ?'); values.push(data.breakMinutes); }
  if (data.workMinutes !== undefined) { sets.push('work_minutes = ?'); values.push(data.workMinutes); }
  if (data.dailyPay !== undefined) { sets.push('daily_pay = ?'); values.push(data.dailyPay); }
  if (data.notes !== undefined) { sets.push('notes = ?'); values.push(data.notes); }
  if (data.agreedStartTime !== undefined) { sets.push('agreed_start_time = ?'); values.push(data.agreedStartTime); }
  if (data.agreedEndTime !== undefined) { sets.push('agreed_end_time = ?'); values.push(data.agreedEndTime); }
  if (data.payType !== undefined) { sets.push('pay_type = ?'); values.push(data.payType); }
  if (data.segmentPay !== undefined) { sets.push('segment_pay = ?'); values.push(data.segmentPay); }
  if (data.hourlyRate !== undefined) { sets.push('hourly_rate = ?'); values.push(data.hourlyRate); }
  sets.push('updated_at = ?');
  values.push(new Date().toISOString());
  values.push(id);
  db.run(`UPDATE staff_work_logs SET ${sets.join(', ')} WHERE id = ?`, values);
  saveDatabaseDebounced();
  return true;
}

export function deleteWorkLog(id: string): boolean {
  if (!db) return false;
  db.run('DELETE FROM staff_work_logs WHERE id = ?', [id]);
  saveDatabaseDebounced();
  return true;
}

export function createStaffRating(data: Omit<StaffRating, 'id' | 'createdAt'>): string {
  if (!db) return '';
  const id = `rating_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const now = new Date().toISOString();
  db.run(
    `INSERT INTO staff_ratings (id, staff_id, rating_date, rating, note, created_at) VALUES (?, ?, ?, ?, ?, ?)`,
    [id, data.staffId, data.ratingDate, data.rating, data.note || '', now]
  );
  saveDatabaseDebounced();
  return id;
}

export function getStaffRatings(staffId?: string): StaffRating[] {
  if (!db) return [];
  const where = staffId ? `WHERE staff_id = ?` : '';
  const params = staffId ? [staffId] : [];
  const rows = db.exec(
    `SELECT id, staff_id, rating_date, rating, note, created_at FROM staff_ratings ${where} ORDER BY rating_date DESC`,
    params
  );
  if (!rows.length) return [];
  return rows[0].values.map((r: any) => ({
    id: r[0], staffId: r[1], ratingDate: r[2], rating: r[3] as StaffRatingValue, note: r[4] || '', createdAt: r[5] || '',
  }));
}

export function deleteStaffRating(id: string): boolean {
  if (!db) return false;
  db.run('DELETE FROM staff_ratings WHERE id = ?', [id]);
  saveDatabaseDebounced();
  return true;
}
