import { useState } from "react";
import { formatInTimeZone } from 'date-fns-tz';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Receipt, Plus, ChevronDown, ChevronUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { createExpense, getSettings } from "@/lib/localDb";
import { getBusinessDay } from "@shared/businessDay";

const PAYMENT_METHODS = [
  { value: 'cash', label: '현금' },
  { value: 'card', label: '카드' },
  { value: 'transfer', label: '계좌이체' },
] as const;

interface SalesSummaryProps {
  date: string;
  totalVisitors: number;
  totalSales: number;
  totalRefunds?: number;
  cancellations: number;
  foreignerCount: number;
  dayVisitors: number;
  nightVisitors: number;
  additionalFeeSales: number;
  rentalRevenue: number;
  totalExpenses: number;
  onExpenseAdded?: () => void;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

export default function SalesSummary({
  date,
  totalVisitors,
  totalSales,
  totalRefunds = 0,
  cancellations,
  foreignerCount,
  dayVisitors,
  nightVisitors,
  additionalFeeSales,
  rentalRevenue,
  totalExpenses,
  onExpenseAdded,
  isCollapsed = false,
  onToggleCollapse,
}: SalesSummaryProps) {
  const { toast } = useToast();
  const entrySales = totalSales + additionalFeeSales;
  const grandTotal = entrySales + rentalRevenue;
  const netProfit = grandTotal - totalExpenses;
  
  const [isSalesOpen, setIsSalesOpen] = useState(false);
  const [expenseDialogOpen, setExpenseDialogOpen] = useState(false);
  const [expenseItem, setExpenseItem] = useState('');
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'cash' | 'transfer'>('cash');

  const handleAddExpense = () => {
    if (!expenseItem.trim()) {
      toast({
        variant: "destructive",
        title: "입력 오류",
        description: "지출항목을 입력해주세요.",
      });
      return;
    }

    if (!amount || Number(amount) <= 0) {
      toast({
        variant: "destructive",
        title: "입력 오류",
        description: "금액을 입력해주세요.",
      });
      return;
    }

    const now = new Date();
    const kstNow = formatInTimeZone(now, 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
    const expenseDate = kstNow.split(' ')[0];
    const expenseTime = kstNow.split(' ')[1].substring(0, 5);
    
    const settings = getSettings();
    const businessDay = getBusinessDay(now, settings.businessDayStartHour);

    createExpense({
      date: expenseDate,
      time: expenseTime,
      category: expenseItem.trim(),
      amount: Number(amount),
      quantity: 1,
      paymentMethod,
      businessDay,
      notes: undefined,
    });

    toast({
      title: "지출 등록 완료",
      description: `${expenseItem.trim()} ${Number(amount).toLocaleString()}원이 등록되었습니다.`,
    });

    setExpenseItem('');
    setAmount('');
    setPaymentMethod('cash');
    setExpenseDialogOpen(false);
    
    if (onExpenseAdded) {
      onExpenseAdded();
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">매출 집계</h2>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setExpenseDialogOpen(true)}
            data-testid="button-quick-add-expense"
          >
            <Receipt className="h-4 w-4 mr-2" />
            지출입력
          </Button>
          {onToggleCollapse && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onToggleCollapse}
              data-testid="button-collapse-sales"
            >
              <ChevronUp className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>
      
      <Collapsible open={isSalesOpen} onOpenChange={setIsSalesOpen}>
        <CollapsibleTrigger className="flex items-center gap-2 hover-elevate px-2 py-1 rounded-md cursor-pointer w-full" data-testid="button-toggle-sales">
          <span className="text-sm font-medium">상세 내역</span>
          {isSalesOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
        </CollapsibleTrigger>
        
        <CollapsibleContent>
          <Card className="mt-4">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-medium text-muted-foreground">
            {date}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">총 방문인원</p>
              <p className="text-2xl font-semibold" data-testid="text-total-visitors">{totalVisitors}명</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">총 수입</p>
              <p className="text-2xl font-semibold text-blue-600 dark:text-blue-400" data-testid="text-grand-total">
                {grandTotal.toLocaleString()}원
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">입실매출 (추가요금 포함)</p>
              <p className="text-lg font-medium" data-testid="text-entry-sales">
                {entrySales.toLocaleString()}원
              </p>
              {totalRefunds > 0 && (
                <span className="inline-block text-xs px-1.5 py-0.5 rounded bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 whitespace-nowrap" data-testid="badge-today-refunds">
                  환불 -{totalRefunds.toLocaleString()}원 차감 포함
                </span>
              )}
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">대여 매출</p>
              <p className="text-lg font-medium" data-testid="text-rental-revenue">
                {rentalRevenue.toLocaleString()}원
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">총 지출</p>
              <p className="text-lg font-medium text-red-600 dark:text-red-400" data-testid="text-total-expenses">
                {totalExpenses.toLocaleString()}원
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">순매출</p>
              <p className="text-lg font-medium" data-testid="text-net-profit">
                {netProfit.toLocaleString()}원
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">취소 건수</p>
              <p className="text-lg font-medium" data-testid="text-cancellations">{cancellations}건</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">외국인 수</p>
              <p className="text-lg font-medium" data-testid="text-foreigner-count">{foreignerCount}명</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">주간 방문수</p>
              <p className="text-lg font-medium" data-testid="text-day-visitors">{dayVisitors}명</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">야간 방문수</p>
              <p className="text-lg font-medium" data-testid="text-night-visitors">{nightVisitors}명</p>
            </div>
          </div>
        </CardContent>
      </Card>
        </CollapsibleContent>
      </Collapsible>

      {/* Quick Expense Input Dialog */}
      <Dialog open={expenseDialogOpen} onOpenChange={setExpenseDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Receipt className="h-5 w-5" />
              빠른 지출 입력
            </DialogTitle>
            <DialogDescription>
              현재 영업일의 지출을 빠르게 등록합니다.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="quick-expense-item">지출항목</Label>
              <Input
                id="quick-expense-item"
                type="text"
                value={expenseItem}
                onChange={(e) => setExpenseItem(e.target.value)}
                placeholder="지출항목 입력 (예: 음료수, 세제 등)"
                data-testid="input-quick-expense-item"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="quick-amount">금액 (원)</Label>
              <Input
                id="quick-amount"
                type="text"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="금액 입력"
                data-testid="input-quick-amount"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="quick-payment">결제방법</Label>
              <Select value={paymentMethod} onValueChange={(v) => setPaymentMethod(v as 'card' | 'cash' | 'transfer')}>
                <SelectTrigger id="quick-payment" data-testid="select-quick-payment">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PAYMENT_METHODS.map((method) => (
                    <SelectItem key={method.value} value={method.value}>
                      {method.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setExpenseDialogOpen(false)} data-testid="button-cancel-quick-expense">
              취소
            </Button>
            <Button onClick={handleAddExpense} data-testid="button-submit-quick-expense">
              <Plus className="h-4 w-4 mr-2" />
              등록
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
