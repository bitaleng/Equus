import { Button } from "@/components/ui/button";
import { getBusinessDayRange } from "@shared/businessDay";
import { Link2, MessageSquare } from "lucide-react";

interface LockerButtonProps {
  number: number;
  status: 'empty' | 'in-use' | 'disabled';
  additionalFeeCount?: number; // 추가요금 발생 횟수 (0: 없음, 1: 1회, 2+: 2회 이상)
  timeType?: 'day' | 'night'; // 입실 시간대 (주간/야간)
  entryTime?: Date; // 입실 시간
  businessDayStartHour?: number; // 정산시간 (기본값: 10)
  onClick: () => void;
  isExpanded?: boolean; // 패널 접힌 상태 (true = 패널 접힘, 버튼 크게)
  parentLocker?: number | null; // 부모 락카 번호 (자식 락카인 경우)
  deferredPayment?: boolean; // 후불결제 여부
  customerMemo?: string; // 손님 메모
  isOuting?: boolean; // 외출 중 여부
  outingExceeded?: boolean; // 외출 시간 초과 여부
  isStaff?: boolean; // 직원 사용 여부
  outOfService?: boolean; // 사용불가 (관리자 설정)
}

export default function LockerButton({ number, status, additionalFeeCount = 0, timeType = 'day', entryTime, businessDayStartHour = 10, onClick, isExpanded = false, parentLocker = null, deferredPayment = false, customerMemo, isOuting = false, outingExceeded = false, isStaff = false, outOfService = false }: LockerButtonProps) {
  // 후불결제 애니메이션 색상 변화 (노란색 ↔ 퍼플블루 싸이렌 효과 - blur 없이 색상만)
  const getDeferredPaymentStyles = () => {
    return `
      animate-deferred-siren 
      text-white border-2 border-white/50
    `;
  };
  
  const getButtonStyles = () => {
    if (outOfService) {
      return "bg-gray-200 text-gray-400 cursor-not-allowed border-2 border-gray-300 dark:bg-gray-700 dark:text-gray-500 dark:border-gray-600";
    }
    if (status === 'disabled') {
      return "bg-white text-white cursor-not-allowed border-2 border-muted";
    }
    if (status === 'in-use') {
      // 0순위: 외출중
      if (isOuting) {
        // 외출 시간 초과 → 다크그레이↔레드 점멸 경보
        if (outingExceeded) {
          return "animate-outing-exceeded border-2 border-red-600";
        }
        // 정상 외출중 → 다크그레이
        return "bg-[#374151] text-white border-2 border-[#1F2937]";
      }
      // 1순위: 후불결제 -> 노란색↔퍼플블루 애니메이션 (추가요금보다 우선)
      if (deferredPayment) {
        return getDeferredPaymentStyles();
      }
      
      // 1순위: 추가요금 있음 -> 무조건 레드
      if (additionalFeeCount > 0) {
        return "bg-[#FF4444] text-white border-2 border-[#CC0000]";
      }
      
      // 2순위: 이전 영업일 입실 -> 그린색
      // 입실시간이 현재 영업일 시작 시간보다 이전이면 이전 영업일 입실로 판단
      // 예: 11월 7일 14:00 입실
      //   - 11월 8일 09:50 (정산 전): businessDayStart = 11월 7일 10:00 -> entryTime > start -> 옐로우
      //   - 11월 8일 10:00 (정산 후): businessDayStart = 11월 8일 10:00 -> entryTime < start -> 그린색 ✓
      if (entryTime) {
        const now = new Date();
        const { start: businessDayStart } = getBusinessDayRange(now, businessDayStartHour);
        if (entryTime < businessDayStart) {
          return "bg-[#22C55E] text-white border-2 border-[#16A34A]";
        }
      }
      
      // 3순위: 직원 사용중 -> 핑크색
      if (isStaff) {
        return "bg-[#FF69B4] text-white border-2 border-[#FF1493]";
      }
      
      // 4순위: 추가요금 없음 -> 주간/야간 구분
      if (timeType === 'day') {
        // 주간: 노란색
        return "bg-[#FFD700] text-gray-800 border-2 border-[#FFC700]";
      } else {
        // 야간: 퍼플 블루
        return "bg-[#7B68EE] text-white border-2 border-[#6A5ACD]";
      }
    }
    // 빈 락카: 흰색
    return "bg-white text-gray-700 border-2 border-gray-300 hover-elevate active-elevate-2";
  };

  const getStatusText = () => {
    if (outOfService) return '사용불가';
    if (status === 'disabled') return '퇴실완료';
    if (status === 'in-use') {
      // 자식 락카인 경우 텍스트 숨김
      if (parentLocker) return null;
      // 외출중
      if (isOuting) return outingExceeded ? '외출경보' : '외출중';
      // 후불결제인 경우 '후불결제' 표시
      if (deferredPayment) return '후불결제';
      // 추가요금이 있으면 횟수만 표시
      if (additionalFeeCount > 0) return `추가 ${additionalFeeCount}회`;
      if (isStaff) return '직원';
      return '사용중';
    }
    return '비어있음';
  };

  const handleClick = () => {
    if (status !== 'disabled' && !outOfService) {
      const audio = new Audio('data:audio/wav;base64,UklGRhIAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQA=');
      audio.volume = 0.3;
      audio.play().catch(() => {});
      onClick();
    }
  };

  const buttonContent = (
    <Button
      onClick={handleClick}
      disabled={status === 'disabled' || outOfService}
      className={`
        aspect-square w-full rounded-lg font-semibold
        transition-all duration-100
        active:scale-95
        flex flex-col items-center justify-center gap-0.5
        relative
        ${isExpanded ? 'min-h-[80px] text-lg' : 'min-h-[56px] text-base'}
        ${getButtonStyles()}
      `}
      data-testid={`locker-${number}`}
    >
      {/* 메모 아이콘 - 우측 상단 */}
      {customerMemo && customerMemo.trim() && (
        <div className="absolute top-1 right-1">
          <MessageSquare className={`${isExpanded ? 'w-3.5 h-3.5' : 'w-2.5 h-2.5'} opacity-80`} />
        </div>
      )}
      <span className={isExpanded ? "text-3xl font-bold" : "text-2xl font-bold"}>{number}</span>
      {getStatusText() && <span className={isExpanded ? "text-xs font-normal opacity-90" : "text-[10px] font-normal opacity-90"}>{getStatusText()}</span>}
      {parentLocker && (
        <div className="flex items-center gap-1">
          <Link2 className={isExpanded ? "w-3 h-3 opacity-90" : "w-2.5 h-2.5 opacity-90"} />
          <span className={isExpanded ? "text-xs font-normal opacity-90" : "text-[10px] font-normal opacity-90"}>{parentLocker}번</span>
        </div>
      )}
    </Button>
  );

  // 메모가 있는 경우 - 버튼 클릭 시 팝오버가 열리면 경고창 오버레이와 충돌하므로
  // 버튼에 메모 아이콘만 표시하고, 메모 내용은 다이얼로그에서 확인하도록 변경
  // (기존 Popover 제거 - 경고창 오버레이와 충돌 문제 해결)
  return buttonContent;
}
